import CommandCenter from '../../components/government/CommandCenter';
export default CommandCenter;
export * from '../../components/government/CommandCenter';
