import React, { useState } from 'react';
import { useSimulation } from '../../context/SimulationContext';
import { FileStack, Users, Landmark, Target, ArrowRight, Filter, Plus, X, MapPin, Calendar, DollarSign, CheckCircle2, Clock, Zap } from 'lucide-react';

const CHALLENGES = [
  { id:'MC-1024', title:'Safe Drinking Water for Rural Jharkhand', category:'Water & Sanitation', location:'Ranchi, Khunti, Lohardaga', priority:'CRITICAL', status:'OPEN', linkedReports:642, universities:12, csr:4, budget:'8.5 Cr', timeline:'18 months', desc:'Systemic contamination of groundwater affecting 3.2 lakh citizens across 4 districts. Root cause analysis validated arsenic leaching from mining activities.', expertise:['Water Treatment','IoT Sensors','Community Health'], successCriteria:'Reduce waterborne disease cases by 70% within 12 months of deployment', districts:['Ranchi','Khunti','Lohardaga','Simdega'] },
  { id:'MC-1025', title:'Road Safety & Pothole Detection System', category:'Roads & Infrastructure', location:'Dhanbad, Bokaro', priority:'HIGH', status:'EVALUATING', linkedReports:418, universities:8, csr:3, budget:'4.2 Cr', timeline:'12 months', desc:'High-frequency pothole complaints and road accident data indicate systemic infrastructure failure. AI-powered early detection and rapid repair dispatch system needed.', expertise:['Computer Vision','GIS','Civil Engineering'], successCriteria:'Reduce road accident incidents by 40% and pothole resolution time by 60%', districts:['Dhanbad','Bokaro','Giridih'] },
  { id:'MC-1026', title:'Smart Waste Management for Urban Areas', category:'Urban Development', location:'Ranchi Municipal', priority:'HIGH', status:'APPROVED', linkedReports:289, universities:6, csr:5, budget:'3.8 Cr', timeline:'10 months', desc:'Municipal solid waste management failure leading to open dumping and health hazards. Smart bin technology with route optimization for collection vehicles proposed.', expertise:['IoT','Logistics Optimization','Environmental Science'], successCriteria:'Achieve 90% waste collection efficiency and eliminate open dumping sites', districts:['Ranchi'] },
  { id:'MC-1027', title:'Primary Healthcare Access in Tribal Blocks', category:'Health', location:'Gumla, Simdega, West Singhbhum', priority:'CRITICAL', status:'PROJECT_AWARDED', linkedReports:521, universities:9, csr:6, budget:'12.0 Cr', timeline:'24 months', desc:'Severe lack of primary healthcare in 148 tribal blocks. Mobile health units and telemedicine integration to bridge the gap.', expertise:['Telemedicine','Public Health','Mobile App Development'], successCriteria:'Provide basic healthcare access to 85% of tribal population within 20km', districts:['Gumla','Simdega','West Singhbhum','Khunti'] },
  { id:'MC-1028', title:'Farmer Income Enhancement via FPO Tech', category:'Agriculture', location:'Palamu, Garhwa, Chatra', priority:'MEDIUM', status:'DRAFT', linkedReports:167, universities:5, csr:2, budget:'2.5 Cr', timeline:'15 months', desc:'Small and marginal farmers lacking market access, causing income distress. Digital platform for Farmer Producer Organizations with market linkage and price discovery.', expertise:['AgriTech','Supply Chain','Mobile Commerce'], successCriteria:'Increase average farmer income by 30% through better market linkage', districts:['Palamu','Garhwa','Chatra','Latehar'] },
  { id:'MC-1029', title:'Land Record Digitization & Dispute Resolution', category:'Revenue', location:'State-wide', priority:'HIGH', status:'DETECTED_CLUSTERS', linkedReports:734, universities:4, csr:1, budget:'6.0 Cr', timeline:'20 months', desc:'High volume of land mutation disputes and illegal encroachments linked to outdated paper records. Blockchain-based immutable land registry proposed.', expertise:['Blockchain','GIS','Legal Tech'], successCriteria:'Reduce land disputes by 60% and mutation processing time to 7 days', districts:['All Districts'] },
  { id:'MC-1030', title:'School Dropout Prevention & Digital Learning', category:'Education', location:'Palamu, Lohardaga, Gumla', priority:'MEDIUM', status:'OPEN', linkedReports:198, universities:7, csr:4, budget:'3.2 Cr', timeline:'14 months', desc:'High school dropout rates in tribal and remote areas due to lack of quality content and infrastructure. Offline-capable digital learning platform for Eklavya schools.', expertise:['EdTech','Content Design','Offline Systems'], successCriteria:'Reduce dropout rate by 50% and improve learning outcomes by 40%', districts:['Palamu','Lohardaga','Gumla','Simdega'] },
  { id:'MC-1031', title:'Power Theft & Grid Stability in Mining Belt', category:'Electricity', location:'Dhanbad, Bokaro, East Singhbhum', priority:'HIGH', status:'EVALUATING', linkedReports:312, universities:5, csr:2, budget:'5.5 Cr', timeline:'16 months', desc:'Power theft and grid instability in mining belt causing 8-hour daily outages. Smart metering and AI-based anomaly detection for the distribution network.', expertise:['Smart Grid','AI/ML','Electrical Engineering'], successCriteria:'Reduce power theft by 70% and outage duration by 60%', districts:['Dhanbad','Bokaro','East Singhbhum'] },
];

const STATUS_CONFIG = {
  DETECTED_CLUSTERS: { label:'Detected Clusters', cls:'bg-slate-100 text-slate-700 border-slate-300' },
  DRAFT: { label:'Draft', cls:'bg-yellow-50 text-yellow-700 border-yellow-200' },
  APPROVED: { label:'Approved', cls:'bg-blue-50 text-blue-700 border-blue-200' },
  OPEN: { label:'Open for Solutions', cls:'bg-green-50 text-green-700 border-green-200' },
  EVALUATING: { label:'Evaluating', cls:'bg-purple-50 text-purple-700 border-purple-200' },
  PROJECT_AWARDED: { label:'Project Awarded', cls:'bg-emerald-50 text-emerald-700 border-emerald-200' },
};
const PRIORITY_CLS = { CRITICAL:'bg-red-100 text-red-700 border-red-300', HIGH:'bg-orange-100 text-orange-700 border-orange-200', MEDIUM:'bg-yellow-100 text-yellow-700 border-yellow-200' };
const TABS = ['ALL','DETECTED_CLUSTERS','DRAFT','APPROVED','OPEN','EVALUATING','PROJECT_AWARDED'];

export default function MasterChallenges() {
  const { state, dispatch } = useSimulation();
  const [tab, setTab] = useState('ALL');
  const [sel, setSel] = useState(null);
  const [q, setQ] = useState('');

  const list = CHALLENGES.filter(c => {
    const matchTab = tab === 'ALL' || c.status === tab;
    const matchQ = c.title.toLowerCase().includes(q.toLowerCase()) || c.id.toLowerCase().includes(q.toLowerCase());
    return matchTab && matchQ;
  });

  const counts = {
    total: CHALLENGES.length,
    open: CHALLENGES.filter(c=>c.status==='OPEN').length,
    eval: CHALLENGES.filter(c=>c.status==='EVALUATING').length,
    awarded: CHALLENGES.filter(c=>c.status==='PROJECT_AWARDED').length,
  };

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">Master Challenge Pipeline</h1>
          <p className="text-sm text-slate-500 font-medium">Transform validated problem clusters into funded government innovation challenges.</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative">
            <Filter size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"/>
            <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search challenges..." className="pl-8 pr-3 py-2 border border-slate-200 rounded-lg text-sm bg-white shadow-sm outline-none focus:border-purple-400 w-48"/>
          </div>
          <button onClick={()=>dispatch({type:'START_WORKFLOW',payload:{action:'CREATE_MASTER_CHALLENGE'}})} className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg text-sm font-bold hover:bg-purple-700 shadow-sm">
            <Plus size={16}/> Create Challenge
          </button>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4 shrink-0">
        {[
          {l:'Total Challenges',v:counts.total,icon:<FileStack size={18} className="text-purple-500"/>,sub:'Across all pipeline stages'},
          {l:'Open for Solutions',v:counts.open,icon:<CheckCircle2 size={18} className="text-green-500"/>,sub:'Accepting proposals now'},
          {l:'Under Evaluation',v:counts.eval,icon:<Clock size={18} className="text-blue-500"/>,sub:'Proposals being assessed'},
          {l:'Project Awarded',v:counts.awarded,icon:<Zap size={18} className="text-amber-500"/>,sub:'Solutions under development'},
        ].map(k=>(
          <div key={k.l} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between mb-3">{k.icon}<span className="text-[10px] font-black text-slate-500 uppercase tracking-widest text-right leading-tight">{k.l}</span></div>
            <div className="text-3xl font-black text-slate-900">{k.v}</div>
            <div className="text-[10px] text-slate-400 mt-1">{k.sub}</div>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 flex-1 flex flex-col overflow-hidden">
        <div className="flex items-center overflow-x-auto border-b border-slate-200 px-2 shrink-0 bg-slate-50">
          {TABS.map((t,i)=>(
            <React.Fragment key={t}>
              <button onClick={()=>setTab(t)} className={`px-4 py-3 text-[10px] font-black tracking-widest uppercase whitespace-nowrap border-b-2 transition-colors ${tab===t?'border-purple-500 text-purple-700':'border-transparent text-slate-500 hover:text-slate-800'}`}>
                {t.replace(/_/g,' ')}
              </button>
              {i<TABS.length-1 && <ArrowRight size={10} className="text-slate-300 shrink-0"/>}
            </React.Fragment>
          ))}
        </div>
        <div className="flex-1 overflow-auto p-5 bg-slate-50/30">
          <div className="grid grid-cols-2 gap-5">
            {list.map(c=>{
              const sc = STATUS_CONFIG[c.status];
              const pc = PRIORITY_CLS[c.priority];
              return (
                <div key={c.id} className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <div className="flex items-center gap-2 mb-2">
                        <span className="text-[10px] font-black text-purple-600 bg-purple-50 px-2 py-0.5 rounded border border-purple-100">{c.id}</span>
                        <span className={`text-[10px] font-black px-2 py-0.5 rounded border ${sc.cls}`}>{sc.label}</span>
                      </div>
                      <h3 className="text-base font-bold text-slate-900 leading-tight">{c.title}</h3>
                      <div className="flex items-center gap-1 text-xs text-slate-500 mt-1"><MapPin size={11}/>{c.location}</div>
                    </div>
                    <span className={`px-2 py-1 text-[10px] font-black rounded border shrink-0 ml-2 ${pc}`}>{c.priority}</span>
                  </div>
                  <p className="text-xs text-slate-600 mb-4 leading-relaxed line-clamp-2">{c.desc}</p>
                  <div className="grid grid-cols-4 gap-2 mb-4 bg-slate-50 p-3 rounded-lg border border-slate-100">
                    <div className="text-center"><div className="text-base font-black text-slate-800">{c.linkedReports}</div><div className="text-[9px] font-bold text-slate-500 uppercase">Reports</div></div>
                    <div className="text-center border-l border-slate-200"><div className="text-base font-black text-blue-600">{c.universities}</div><div className="text-[9px] font-bold text-slate-500 uppercase">Univs</div></div>
                    <div className="text-center border-l border-slate-200"><div className="text-base font-black text-amber-600">{c.csr}</div><div className="text-[9px] font-bold text-slate-500 uppercase">CSR</div></div>
                    <div className="text-center border-l border-slate-200"><div className="text-xs font-black text-green-600">{c.budget}</div><div className="text-[9px] font-bold text-slate-500 uppercase">Budget</div></div>
                  </div>
                  <div className="flex flex-wrap gap-1.5 mb-4">
                    {c.expertise.map(x=><span key={x} className="px-2 py-0.5 bg-blue-50 text-blue-700 border border-blue-100 rounded text-[10px] font-bold">{x}</span>)}
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={()=>setSel(c)} className="flex-1 bg-purple-50 text-purple-700 hover:bg-purple-100 font-bold text-xs py-2 rounded border border-purple-200">View Details</button>
                    <button onClick={()=>dispatch({type:'START_WORKFLOW',payload:{action:'INVITE_UNIVERSITY',challengeId:c.id}})} className="flex-1 bg-slate-900 text-white hover:bg-black font-bold text-xs py-2 rounded">Match Stakeholders</button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {sel && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm" onClick={()=>setSel(null)}>
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl mx-4 max-h-[90vh] overflow-auto" onClick={e=>e.stopPropagation()}>
            <div className="p-6 border-b border-slate-100 bg-purple-50 relative">
              <div className="absolute top-0 left-0 right-0 h-1 bg-purple-500"/>
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[10px] font-black text-purple-700 bg-purple-100 px-2 py-0.5 rounded border border-purple-200">{sel.id}</span>
                    <span className={`text-[10px] font-black px-2 py-0.5 rounded border ${STATUS_CONFIG[sel.status].cls}`}>{STATUS_CONFIG[sel.status].label}</span>
                  </div>
                  <h2 className="text-xl font-black text-slate-900">{sel.title}</h2>
                  <div className="text-xs text-slate-500 mt-1">{sel.category}</div>
                </div>
                <button onClick={()=>setSel(null)} className="p-2 hover:bg-purple-100 rounded-full"><X size={20}/></button>
              </div>
            </div>
            <div className="p-6 space-y-5">
              <div>
                <div className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-2">Challenge Description</div>
                <p className="text-sm text-slate-700 leading-relaxed">{sel.desc}</p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-50 rounded-xl p-4 border border-slate-100">
                  <div className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-3">Key Metrics</div>
                  <div className="space-y-2">
                    {[{l:'Linked Reports',v:sel.linkedReports},{l:'University Interest',v:sel.universities},{l:'CSR Partners',v:sel.csr},{l:'Budget Estimate',v:sel.budget},{l:'Timeline',v:sel.timeline}].map(m=>(
                      <div key={m.l} className="flex justify-between text-xs"><span className="text-slate-500 font-medium">{m.l}</span><span className="font-black text-slate-900">{m.v}</span></div>
                    ))}
                  </div>
                </div>
                <div className="bg-slate-50 rounded-xl p-4 border border-slate-100">
                  <div className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-2">Districts Covered</div>
                  <div className="flex flex-wrap gap-1.5 mb-4">{sel.districts.map(d=><span key={d} className="px-2 py-1 bg-blue-50 text-blue-700 border border-blue-200 rounded text-[10px] font-bold">{d}</span>)}</div>
                  <div className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-2">Required Expertise</div>
                  <div className="flex flex-wrap gap-1.5">{sel.expertise.map(x=><span key={x} className="px-2 py-1 bg-purple-50 text-purple-700 border border-purple-200 rounded text-[10px] font-bold">{x}</span>)}</div>
                </div>
              </div>
              <div className="bg-green-50 border border-green-200 rounded-xl p-4">
                <div className="text-[10px] font-black uppercase tracking-widest text-green-600 mb-1">Success Criteria</div>
                <p className="text-sm font-medium text-slate-800">{sel.successCriteria}</p>
              </div>
              <div className="grid grid-cols-3 gap-3 pt-2 border-t border-slate-100">
                <button onClick={()=>dispatch({type:'ADD_TOAST',payload:{title:'Report Exported',message:sel.id+' challenge brief exported.',type:'success'}})} className="flex items-center justify-center gap-1.5 py-2 rounded-lg border border-slate-200 text-xs font-bold text-slate-700 bg-slate-50 hover:bg-slate-100">Export Brief</button>
                <button onClick={()=>dispatch({type:'START_WORKFLOW',payload:{action:'INVITE_UNIVERSITY',challengeId:sel.id}})} className="flex items-center justify-center gap-1.5 py-2 rounded-lg border border-purple-200 text-xs font-bold text-purple-700 bg-purple-50 hover:bg-purple-100">Match Partners</button>
                <button onClick={()=>{setSel(null);dispatch({type:'ADD_TOAST',payload:{title:'Escalated to Secretary',message:sel.id+' escalated for urgent review.',type:'warning'}});}} className="flex items-center justify-center gap-1.5 py-2 rounded-lg border border-red-200 text-xs font-bold text-red-700 bg-red-50 hover:bg-red-100">Escalate</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}