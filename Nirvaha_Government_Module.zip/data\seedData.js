/**
 * NIRVAHA SEED DATASET — Comprehensive Jharkhand Civic-Tech & Governance Dataset
 * ==============================================================================
 * File: frontend/src/data/seedData.js (Proposed Drop-in Replacement)
 * Classification: State Invariants & Entity Hydration Engine
 * Target: Single Source of Truth for SimulationContext.jsx & AppContext.jsx
 *
 * Entities Covered:
 *  1. 24 Jharkhand Districts with official coordinates, census demographics & bounds
 *  2. 10 Governance Departments with SLA metrics, heads & performance metrics
 *  3. 10 Realistic Department Officers with workloads, contact details & skills
 *  4. 11 Higher Education Institutions (HEIs) & Technical Universities
 *  5. 8 Industry & PSU CSR Foundations with budgets and active commitments
 *  6. 28 Diverse Problem Cases covering ALL 10 State Progression Invariant States
 *  7. 5 Spatial & Semantic Problem Clusters (DBSCAN outputs)
 *  8. 4 Master Challenges with multi-tranche CSR & University co-funding
 *  9. 7 Active/Completed Solution Projects with milestone verification logs
 * 10. 5 Predictive Risk Alerts with probability, time windows & affected pop
 * 11. 3 Preventive Work Orders dispatched from predictive risks
 * 12. 4 Institutional Knowledge Records with reusable blueprints, BOMs & SOPs
 * 13. 10 Immutable Audit Log Entries demonstrating provenance & state tracking
 * 14. 8 Multi-Role In-App Notifications
 * 15. Initial System KPI Telemetry & Departmental Scorecards
 */

// ============================================================================
// 1. 24 JHARKHAND DISTRICTS WITH GEOGRAPHIC COORDINATES & ADMINISTRATIVE METRICS
// ============================================================================

export const JHARKHAND_DISTRICTS = [
  {
    id: "DIST-01",
    name: "Ranchi",
    division: "South Chotanagpur",
    hq: "Ranchi",
    lat: 23.3441,
    lng: 85.3096,
    population: 2914253,
    areaKm2: 5097,
    activeCases: 42,
    resolvedCases: 198,
    riskLevel: "High",
    tier: 1
  },
  {
    id: "DIST-02",
    name: "Dhanbad",
    division: "North Chotanagpur",
    hq: "Dhanbad",
    lat: 23.7957,
    lng: 86.4304,
    population: 2684487,
    areaKm2: 2040,
    activeCases: 38,
    resolvedCases: 164,
    riskLevel: "High",
    tier: 1
  },
  {
    id: "DIST-03",
    name: "Bokaro",
    division: "North Chotanagpur",
    hq: "Bokaro Steel City",
    lat: 23.6693,
    lng: 86.1511,
    population: 2062330,
    areaKm2: 2883,
    activeCases: 29,
    resolvedCases: 142,
    riskLevel: "Medium",
    tier: 1
  },
  {
    id: "DIST-04",
    name: "East Singhbhum",
    nameAlt: "Jamshedpur (East Singhbhum)",
    division: "Kolhan",
    hq: "Jamshedpur",
    lat: 22.8046,
    lng: 86.2029,
    population: 2293919,
    areaKm2: 3562,
    activeCases: 31,
    resolvedCases: 185,
    riskLevel: "Medium",
    tier: 1
  },
  {
    id: "DIST-05",
    name: "Hazaribagh",
    division: "North Chotanagpur",
    hq: "Hazaribagh",
    lat: 23.9925,
    lng: 85.3637,
    population: 1734495,
    areaKm2: 3555,
    activeCases: 24,
    resolvedCases: 119,
    riskLevel: "Medium",
    tier: 2
  },
  {
    id: "DIST-06",
    name: "Deoghar",
    division: "Santhal Pargana",
    hq: "Deoghar",
    lat: 24.4826,
    lng: 86.6997,
    population: 1492073,
    areaKm2: 2477,
    activeCases: 22,
    resolvedCases: 94,
    riskLevel: "Medium",
    tier: 2
  },
  {
    id: "DIST-07",
    name: "Dumka",
    division: "Santhal Pargana",
    hq: "Dumka",
    lat: 24.2676,
    lng: 87.2498,
    population: 1321442,
    areaKm2: 3761,
    activeCases: 19,
    resolvedCases: 86,
    riskLevel: "Low",
    tier: 2
  },
  {
    id: "DIST-08",
    name: "Giridih",
    division: "North Chotanagpur",
    hq: "Giridih",
    lat: 24.1839,
    lng: 86.3056,
    population: 2445474,
    areaKm2: 4962,
    activeCases: 27,
    resolvedCases: 108,
    riskLevel: "Medium",
    tier: 2
  },
  {
    id: "DIST-09",
    name: "Godda",
    division: "Santhal Pargana",
    hq: "Godda",
    lat: 24.8267,
    lng: 87.2144,
    population: 1313551,
    areaKm2: 2266,
    activeCases: 18,
    resolvedCases: 72,
    riskLevel: "High",
    tier: 2
  },
  {
    id: "DIST-10",
    name: "Sahebganj",
    division: "Santhal Pargana",
    hq: "Sahebganj",
    lat: 25.2425,
    lng: 87.6434,
    population: 1150567,
    areaKm2: 2063,
    activeCases: 16,
    resolvedCases: 61,
    riskLevel: "High",
    tier: 2
  },
  {
    id: "DIST-11",
    name: "Pakur",
    division: "Santhal Pargana",
    hq: "Pakur",
    lat: 24.6340,
    lng: 87.8492,
    population: 900422,
    areaKm2: 1806,
    activeCases: 14,
    resolvedCases: 53,
    riskLevel: "Medium",
    tier: 3
  },
  {
    id: "DIST-12",
    name: "Latehar",
    division: "Palamu",
    hq: "Latehar",
    lat: 23.7441,
    lng: 84.4984,
    population: 726978,
    areaKm2: 4291,
    activeCases: 15,
    resolvedCases: 48,
    riskLevel: "Medium",
    tier: 3
  },
  {
    id: "DIST-13",
    name: "Lohardaga",
    division: "South Chotanagpur",
    hq: "Lohardaga",
    lat: 23.4316,
    lng: 84.6826,
    population: 461790,
    areaKm2: 1502,
    activeCases: 11,
    resolvedCases: 49,
    riskLevel: "Low",
    tier: 3
  },
  {
    id: "DIST-14",
    name: "Gumla",
    division: "South Chotanagpur",
    hq: "Gumla",
    lat: 23.0428,
    lng: 84.5422,
    population: 1025213,
    areaKm2: 5360,
    activeCases: 17,
    resolvedCases: 65,
    riskLevel: "Medium",
    tier: 3
  },
  {
    id: "DIST-15",
    name: "Simdega",
    division: "South Chotanagpur",
    hq: "Simdega",
    lat: 22.6170,
    lng: 84.5074,
    population: 599578,
    areaKm2: 3774,
    activeCases: 13,
    resolvedCases: 42,
    riskLevel: "Low",
    tier: 3
  },
  {
    id: "DIST-16",
    name: "West Singhbhum",
    division: "Kolhan",
    hq: "Chaibasa",
    lat: 22.5539,
    lng: 85.8118,
    population: 1502338,
    areaKm2: 7224,
    activeCases: 26,
    resolvedCases: 89,
    riskLevel: "High",
    tier: 2
  },
  {
    id: "DIST-17",
    name: "Khunti",
    division: "South Chotanagpur",
    hq: "Khunti",
    lat: 23.0729,
    lng: 85.2789,
    population: 531885,
    areaKm2: 2535,
    activeCases: 12,
    resolvedCases: 57,
    riskLevel: "Low",
    tier: 3
  },
  {
    id: "DIST-18",
    name: "Ramgarh",
    division: "North Chotanagpur",
    hq: "Ramgarh Cantonment",
    lat: 23.6300,
    lng: 85.5186,
    population: 949443,
    areaKm2: 1341,
    activeCases: 19,
    resolvedCases: 76,
    riskLevel: "Medium",
    tier: 2
  },
  {
    id: "DIST-19",
    name: "Koderma",
    division: "North Chotanagpur",
    hq: "Koderma",
    lat: 24.4678,
    lng: 85.5939,
    population: 716259,
    areaKm2: 1500,
    activeCases: 14,
    resolvedCases: 58,
    riskLevel: "Low",
    tier: 3
  },
  {
    id: "DIST-20",
    name: "Chatra",
    division: "North Chotanagpur",
    hq: "Chatra",
    lat: 24.2092,
    lng: 84.8719,
    population: 1042886,
    areaKm2: 3718,
    activeCases: 16,
    resolvedCases: 64,
    riskLevel: "Medium",
    tier: 3
  },
  {
    id: "DIST-21",
    name: "Palamu",
    division: "Palamu",
    hq: "Medininagar (Daltonganj)",
    lat: 24.0378,
    lng: 84.0689,
    population: 1939869,
    areaKm2: 4393,
    activeCases: 28,
    resolvedCases: 95,
    riskLevel: "High",
    tier: 2
  },
  {
    id: "DIST-22",
    name: "Garhwa",
    division: "Palamu",
    hq: "Garhwa",
    lat: 24.1610,
    lng: 83.8052,
    population: 1322784,
    areaKm2: 4044,
    activeCases: 21,
    resolvedCases: 70,
    riskLevel: "Medium",
    tier: 2
  },
  {
    id: "DIST-23",
    name: "Saraikela-Kharsawan",
    division: "Kolhan",
    hq: "Saraikela",
    lat: 22.6994,
    lng: 85.9309,
    population: 1065056,
    areaKm2: 2657,
    activeCases: 20,
    resolvedCases: 81,
    riskLevel: "Medium",
    tier: 2
  },
  {
    id: "DIST-24",
    name: "Jamtara",
    nameAlt: "Shivpur (Nawadih)",
    division: "Santhal Pargana",
    hq: "Jamtara",
    lat: 23.9587,
    lng: 86.8016,
    population: 791042,
    areaKm2: 1811,
    activeCases: 15,
    resolvedCases: 52,
    riskLevel: "Low",
    tier: 3
  }
];

// Backwards-compatible legacy DISTRICTS array of district name strings
export const DISTRICTS = [
  "Ranchi",
  "Jamshedpur (East Singhbhum)",
  "Dhanbad",
  "Bokaro",
  "Hazaribagh",
  "Giridih",
  "Deoghar",
  "Dumka",
  "Godda",
  "Sahebganj",
  "Pakur",
  "Latehar",
  "Lohardaga",
  "Gumla",
  "Simdega",
  "West Singhbhum",
  "Khunti",
  "Ramgarh",
  "Koderma",
  "Chatra",
  "Palamu",
  "Garhwa",
  "Saraikela-Kharsawan",
  "Shivpur (Nawadih)"
];

// Map helper to find full district metadata by name
export const getDistrictMeta = (districtName) => {
  if (!districtName) return JHARKHAND_DISTRICTS[0];
  const clean = districtName.toLowerCase().replace(/[^a-z]/g, "");
  return (
    JHARKHAND_DISTRICTS.find(d => {
      const match1 = d.name.toLowerCase().replace(/[^a-z]/g, "");
      const match2 = d.nameAlt ? d.nameAlt.toLowerCase().replace(/[^a-z]/g, "") : "";
      return match1.includes(clean) || clean.includes(match1) || (match2 && (match2.includes(clean) || clean.includes(match2)));
    }) || JHARKHAND_DISTRICTS[0]
  );
};


// ============================================================================
// 2. 10 THEMATIC CIVIC CATEGORIES
// ============================================================================

export const CATEGORIES = [
  { key: "Water", label: "Drinking Water & Sanitation", icon: "💧", color: "#0ea5e9", deptCode: "PHED", slaHours: 48 },
  { key: "Sanitation", label: "Public Hygiene & Waste", icon: "🚽", color: "#8b5cf6", deptCode: "UDHD", slaHours: 48 },
  { key: "Roads", label: "Roads, Bridges & Transport", icon: "🛣️", color: "#64748b", deptCode: "PWD", slaHours: 72 },
  { key: "Agriculture", label: "Agriculture & Livelihood", icon: "🌾", color: "#84cc16", deptCode: "AGRI", slaHours: 96 },
  { key: "Education", label: "School Education & Literacy", icon: "📚", color: "#f59e0b", deptCode: "EDU", slaHours: 72 },
  { key: "Health", label: "Health & Clinical Facilities", icon: "🏥", color: "#ef4444", deptCode: "HEALTH", slaHours: 24 },
  { key: "Accessibility", label: "Divyangjan & Universal Access", icon: "♿", color: "#06b6d4", deptCode: "WCD", slaHours: 72 },
  { key: "Environment", label: "Forest, Pollution & Ecology", icon: "🌳", color: "#16a34a", deptCode: "FOREST", slaHours: 72 },
  { key: "Urban Infra", label: "Urban Utilities & Civic Infra", icon: "🏙️", color: "#475569", deptCode: "UDHD", slaHours: 48 },
  { key: "Public Service", label: "PDS, Welfare & Digital Services", icon: "🏛️", color: "#b45309", deptCode: "FCS", slaHours: 48 }
];

export const catMeta = (key) => CATEGORIES.find(c => c.key === key) || CATEGORIES[9];


// ============================================================================
// 3. 10 JHARKHAND GOVERNMENT DEPARTMENTS & TELEMETRY
// ============================================================================

export const DEPARTMENTS = [
  {
    id: "DEPT-01",
    code: "PHED",
    name: "Drinking Water & Sanitation Department (PHED)",
    shortName: "PHED (Water)",
    headOfficer: "Er. Rajeshwar Prasad",
    activeCases: 1284,
    criticalCases: 84,
    slaComplianceRate: 88.4,
    officerCount: 42,
    citizenSatisfaction: 4.1,
    budgetAllocatedCr: 420.5,
    primaryDomain: "Water"
  },
  {
    id: "DEPT-02",
    code: "PWD",
    name: "Road Construction Department (RCD / PWD)",
    shortName: "Roads & Highways",
    headOfficer: "Er. Alok Kumar Singh",
    activeCases: 1017,
    criticalCases: 112,
    slaComplianceRate: 81.2,
    officerCount: 38,
    citizenSatisfaction: 3.8,
    budgetAllocatedCr: 680.0,
    primaryDomain: "Roads"
  },
  {
    id: "DEPT-03",
    code: "HEALTH",
    name: "Health, Medical Education & Family Welfare",
    shortName: "Health & Clinics",
    headOfficer: "Dr. Sunita Soren",
    activeCases: 812,
    criticalCases: 45,
    slaComplianceRate: 94.7,
    officerCount: 65,
    citizenSatisfaction: 4.5,
    budgetAllocatedCr: 550.0,
    primaryDomain: "Health"
  },
  {
    id: "DEPT-04",
    code: "EDU",
    name: "School Education & Literacy Department",
    shortName: "School Education",
    headOfficer: "Smt. Meenakshi Toppo",
    activeCases: 628,
    criticalCases: 18,
    slaComplianceRate: 89.6,
    officerCount: 28,
    citizenSatisfaction: 4.3,
    budgetAllocatedCr: 490.0,
    primaryDomain: "Education"
  },
  {
    id: "DEPT-05",
    code: "AGRI",
    name: "Agriculture, Animal Husbandry & Co-operative",
    shortName: "Agriculture",
    headOfficer: "Sri Rameshwar Mahto",
    activeCases: 492,
    criticalCases: 22,
    slaComplianceRate: 86.5,
    officerCount: 31,
    citizenSatisfaction: 4.0,
    budgetAllocatedCr: 310.0,
    primaryDomain: "Agriculture"
  },
  {
    id: "DEPT-06",
    code: "UDHD",
    name: "Urban Development & Housing Department (UDHD)",
    shortName: "Urban Infra & Waste",
    headOfficer: "Er. Vikas Anand",
    activeCases: 741,
    criticalCases: 67,
    slaComplianceRate: 86.8,
    officerCount: 34,
    citizenSatisfaction: 4.0,
    budgetAllocatedCr: 380.0,
    primaryDomain: "Urban Infra"
  },
  {
    id: "DEPT-07",
    code: "WCD",
    name: "Women, Child Development & Social Welfare",
    shortName: "Social Welfare & Accessibility",
    headOfficer: "Smt. Priyanka Kumari",
    activeCases: 384,
    criticalCases: 14,
    slaComplianceRate: 92.1,
    officerCount: 24,
    citizenSatisfaction: 4.4,
    budgetAllocatedCr: 210.0,
    primaryDomain: "Accessibility"
  },
  {
    id: "DEPT-08",
    code: "FOREST",
    name: "Department of Forest, Environment & Climate Change",
    shortName: "Forest & Environment",
    headOfficer: "Sri Animesh Sengupta",
    activeCases: 342,
    criticalCases: 39,
    slaComplianceRate: 87.9,
    officerCount: 22,
    citizenSatisfaction: 4.2,
    budgetAllocatedCr: 180.0,
    primaryDomain: "Environment"
  },
  {
    id: "DEPT-09",
    code: "FCS",
    name: "Food, Public Distribution & Consumer Affairs",
    shortName: "PDS & Food Civil Supplies",
    headOfficer: "Sri Dilip Kumar Roy",
    activeCases: 512,
    criticalCases: 58,
    slaComplianceRate: 83.4,
    officerCount: 26,
    citizenSatisfaction: 3.9,
    budgetAllocatedCr: 290.0,
    primaryDomain: "Public Service"
  },
  {
    id: "DEPT-10",
    code: "ENERGY",
    name: "Energy Department / JUVNL (Electricity)",
    shortName: "Energy & Electricity",
    headOfficer: "Er. Sanjay K. Tirkey",
    activeCases: 942,
    criticalCases: 104,
    slaComplianceRate: 82.3,
    officerCount: 51,
    citizenSatisfaction: 3.9,
    budgetAllocatedCr: 520.0,
    primaryDomain: "Urban Infra"
  }
];


// ============================================================================
// 4. 10 REALISTIC FIELD & DEPARTMENT OFFICERS
// ============================================================================

export const OFFICERS = [
  {
    id: "O-101",
    name: "Er. Rajeshwar Prasad",
    designation: "Executive Engineer",
    dept: "PHED",
    departmentCode: "PHED",
    district: "Ranchi",
    jurisdiction: "Ranchi Urban & Bundu Sub-division",
    skill: "Drinking Water Networks & Tube-wells",
    skillDomain: "Water",
    workload: 42,
    slaRating: 94.2,
    activeCasesCount: 7,
    phone: "+91 94311 20101",
    email: "r.prasad.phed@jharkhand.gov.in",
    distance: 2,
    status: "AVAILABLE",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&fit=crop&crop=faces"
  },
  {
    id: "O-102",
    name: "Er. Alok Kumar Singh",
    designation: "Superintending Engineer",
    dept: "Roads",
    departmentCode: "PWD",
    district: "Dhanbad",
    jurisdiction: "Dhanbad Industrial Corridor & NH-33 Link",
    skill: "Bituminous Pavement & Bridges",
    skillDomain: "Roads",
    workload: 88,
    slaRating: 82.5,
    activeCasesCount: 16,
    phone: "+91 94311 20102",
    email: "ak.singh.pwd@jharkhand.gov.in",
    distance: 4,
    status: "OVERLOADED",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&fit=crop&crop=faces"
  },
  {
    id: "O-103",
    name: "Dr. Sunita Soren",
    designation: "Chief Medical Officer",
    dept: "Health",
    departmentCode: "HEALTH",
    district: "East Singhbhum",
    jurisdiction: "Jamshedpur PHCs & Chaibasa Tribal Belt",
    skill: "Epidemiology & Rural Clinic Operations",
    skillDomain: "Health",
    workload: 54,
    slaRating: 96.0,
    activeCasesCount: 9,
    phone: "+91 94311 20103",
    email: "dr.soren.health@jharkhand.gov.in",
    distance: 6,
    status: "AVAILABLE",
    avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=120&fit=crop&crop=faces"
  },
  {
    id: "O-104",
    name: "Smt. Meenakshi Toppo",
    designation: "District Superintendent of Education",
    dept: "Education",
    departmentCode: "EDU",
    district: "Hazaribagh",
    jurisdiction: "Simaria, Barhi & Hazaribagh Sadar",
    skill: "School Infrastructure & Mid-Day Meal Log",
    skillDomain: "Education",
    workload: 61,
    slaRating: 89.4,
    activeCasesCount: 11,
    phone: "+91 94311 20104",
    email: "m.toppo.edu@jharkhand.gov.in",
    distance: 8,
    status: "AVAILABLE",
    avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=120&fit=crop&crop=faces"
  },
  {
    id: "O-105",
    name: "Sri Rameshwar Mahto",
    designation: "District Agriculture Officer",
    dept: "Agriculture",
    departmentCode: "AGRI",
    district: "Chatra",
    jurisdiction: "Chatra & Ramgarh Farming Blocks",
    skill: "Soil Testing & Pest Early Detection",
    skillDomain: "Agriculture",
    workload: 35,
    slaRating: 91.8,
    activeCasesCount: 5,
    phone: "+91 94311 20105",
    email: "r.mahto.agri@jharkhand.gov.in",
    distance: 12,
    status: "AVAILABLE",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=120&fit=crop&crop=faces"
  },
  {
    id: "O-106",
    name: "Er. Vikas Anand",
    designation: "City Engineer / Municipal Commissioner",
    dept: "Urban Infra",
    departmentCode: "UDHD",
    district: "Bokaro",
    jurisdiction: "Bokaro Steel City Wards 1-14",
    skill: "Stormwater Drainage & Street Lighting Grids",
    skillDomain: "Urban Infra",
    workload: 78,
    slaRating: 84.1,
    activeCasesCount: 14,
    phone: "+91 94311 20106",
    email: "v.anand.udhd@jharkhand.gov.in",
    distance: 3,
    status: "AVAILABLE",
    avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=120&fit=crop&crop=faces"
  },
  {
    id: "O-107",
    name: "Smt. Priyanka Kumari",
    designation: "District Social Welfare Officer",
    dept: "Accessibility",
    departmentCode: "WCD",
    district: "Gumla",
    jurisdiction: "Gumla, Khunti & Lohardaga Tribal Blocks",
    skill: "Divyangjan Universal Design & Welfare Disbursal",
    skillDomain: "Accessibility",
    workload: 29,
    slaRating: 95.3,
    activeCasesCount: 4,
    phone: "+91 94311 20107",
    email: "p.kumari.wcd@jharkhand.gov.in",
    distance: 9,
    status: "AVAILABLE",
    avatar: "https://images.unsplash.com/photo-1567532939604-b6b5b0db2604?w=120&fit=crop&crop=faces"
  },
  {
    id: "O-108",
    name: "Sri Animesh Sengupta",
    designation: "Divisional Forest Officer (DFO)",
    dept: "Environment",
    departmentCode: "FOREST",
    district: "West Singhbhum",
    jurisdiction: "Saranda Forest & South Koel Basin",
    skill: "Forest Fire Modeling & Riverbank Stabilization",
    skillDomain: "Environment",
    workload: 67,
    slaRating: 90.2,
    activeCasesCount: 10,
    phone: "+91 94311 20108",
    email: "a.sengupta.forest@jharkhand.gov.in",
    distance: 14,
    status: "AVAILABLE",
    avatar: "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=120&fit=crop&crop=faces"
  },
  {
    id: "O-109",
    name: "Sri Dilip Kumar Roy",
    designation: "District Supply Officer",
    dept: "Public Service",
    departmentCode: "FCS",
    district: "Giridih",
    jurisdiction: "Giridih & Dhanbad Ration Outlets",
    skill: "Aadhaar e-POS Sync & Supply Chain Audits",
    skillDomain: "Public Service",
    workload: 83,
    slaRating: 80.7,
    activeCasesCount: 15,
    phone: "+91 94311 20109",
    email: "dk.roy.fcs@jharkhand.gov.in",
    distance: 7,
    status: "AVAILABLE",
    avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=120&fit=crop&crop=faces"
  },
  {
    id: "O-110",
    name: "Er. Sanjay K. Tirkey",
    designation: "Executive Engineer (Transmission)",
    dept: "Energy",
    departmentCode: "ENERGY",
    district: "Deoghar",
    jurisdiction: "Deoghar, Dumka & Santhal Grid",
    skill: "Rural Electrification & Solar Microgrids",
    skillDomain: "Urban Infra",
    workload: 48,
    slaRating: 88.0,
    activeCasesCount: 8,
    phone: "+91 94311 20110",
    email: "sk.tirkey.juvnl@jharkhand.gov.in",
    distance: 11,
    status: "AVAILABLE",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&fit=crop&crop=faces"
  }
];


// ============================================================================
// 5. 11 HIGHER EDUCATION INSTITUTIONS (HEIs) & UNIVERSITIES
// ============================================================================

export const UNIVERSITIES = [
  {
    id: "u1",
    name: "Birla Institute of Technology, Mesra",
    short: "BIT Mesra",
    district: "Ranchi",
    lat: 23.4124,
    lng: 85.4399,
    type: "Technical & Research",
    strength: 180,
    disciplines: ["Civil Engineering", "Remote Sensing & GIS", "Computer Science", "Renewable Energy"],
    incubatedStartups: 14,
    contactFaculty: "Dr. P. Sinha",
    email: "innovate@bitmesra.ac.in",
    activeProjectsCount: 4
  },
  {
    id: "u2",
    name: "National Institute of Technology, Jamshedpur",
    short: "NIT Jamshedpur",
    district: "East Singhbhum",
    lat: 22.7758,
    lng: 86.1438,
    type: "National Institute of Importance",
    strength: 220,
    disciplines: ["Structural Engineering", "AI & Robotics", "Metallurgy", "Hydrology"],
    incubatedStartups: 19,
    contactFaculty: "Prof. S. Bhattacharya",
    email: "research@nitjsr.ac.in",
    activeProjectsCount: 5
  },
  {
    id: "u3",
    name: "Ranchi University",
    short: "Ranchi Univ",
    district: "Ranchi",
    lat: 23.3700,
    lng: 85.3250,
    type: "State General University",
    strength: 260,
    disciplines: ["Botany & Bioremediation", "Rural Development", "Environmental Science", "Sociology"],
    incubatedStartups: 6,
    contactFaculty: "Dr. Anjali Verma",
    email: "vc@ranchiuniversity.ac.in",
    activeProjectsCount: 3
  },
  {
    id: "u4",
    name: "Indian Institute of Management, Ranchi",
    short: "IIM Ranchi",
    district: "Ranchi",
    lat: 23.3280,
    lng: 85.3120,
    type: "Management Institute",
    strength: 90,
    disciplines: ["Public Policy", "Supply Chain Management", "Social Entrepreneurship"],
    incubatedStartups: 8,
    contactFaculty: "Prof. R. Sengupta",
    email: "policy@iimranchi.ac.in",
    activeProjectsCount: 2
  },
  {
    id: "u5",
    name: "Central University of Jharkhand",
    short: "CUJ Ranchi",
    district: "Ranchi",
    lat: 23.4280,
    lng: 85.2530,
    type: "Central University",
    strength: 150,
    disciplines: ["Tribal Studies & Languages", "Energy Engineering", "Water Resource Mgmt"],
    incubatedStartups: 5,
    contactFaculty: "Dr. Arvind Kumar",
    email: "dean.research@cuj.ac.in",
    activeProjectsCount: 2
  },
  {
    id: "u6",
    name: "Vinoba Bhave University",
    short: "VBU Hazaribagh",
    district: "Hazaribagh",
    lat: 24.0080,
    lng: 85.3720,
    type: "State University",
    strength: 200,
    disciplines: ["Life Sciences", "Sanitation Engineering", "Rural Economics"],
    incubatedStartups: 4,
    contactFaculty: "Dr. R. K. Mishra",
    email: "info@vbu.ac.in",
    activeProjectsCount: 2
  },
  {
    id: "u7",
    name: "Kolhan University",
    short: "Kolhan Univ",
    district: "West Singhbhum",
    lat: 22.5620,
    lng: 85.8080,
    type: "State University",
    strength: 170,
    disciplines: ["Geology & Mining Runoff", "Ecology", "Indigenous Languages"],
    incubatedStartups: 3,
    contactFaculty: "Dr. K. Toppo",
    email: "academic@kolhanuniversity.ac.in",
    activeProjectsCount: 2
  },
  {
    id: "u8",
    name: "ICAR - Research Complex for Eastern Region",
    short: "ICAR Ranchi",
    district: "Ranchi",
    lat: 23.3150,
    lng: 85.3450,
    type: "National Agricultural Research Lab",
    strength: 60,
    disciplines: ["Drought-Tolerant Crops", "Soil Microbiome", "Precision Horticulture"],
    incubatedStartups: 7,
    contactFaculty: "Dr. S. Lakra",
    email: "head.icar@icar.gov.in",
    activeProjectsCount: 3
  },
  {
    id: "u9",
    name: "Indian Institute of Technology (ISM) Dhanbad",
    short: "IIT ISM Dhanbad",
    district: "Dhanbad",
    lat: 23.8160,
    lng: 86.4412,
    type: "National Institute of Importance",
    strength: 280,
    disciplines: ["Mining Engineering", "Environmental Geotechnology", "Hydrogeology", "Sensor IoT"],
    incubatedStartups: 26,
    contactFaculty: "Prof. D. Mukherjee",
    email: "rnd@iitism.ac.in",
    activeProjectsCount: 6
  },
  {
    id: "u10",
    name: "AIIMS Deoghar",
    short: "AIIMS Deoghar",
    district: "Deoghar",
    lat: 24.4530,
    lng: 86.6820,
    type: "National Medical Institute",
    strength: 110,
    disciplines: ["Community Medicine", "Telemedicine", "Maternal Health Epidemiology"],
    incubatedStartups: 5,
    contactFaculty: "Dr. B. K. Sharma",
    email: "research@aiimsdeoghar.edu.in",
    activeProjectsCount: 2
  },
  {
    id: "u11",
    name: "Birsa Agricultural University",
    short: "BAU Ranchi",
    district: "Ranchi",
    lat: 23.4450,
    lng: 85.3190,
    type: "Agricultural University",
    strength: 190,
    disciplines: ["Dryland Millets", "Agro-forestry", "Veterinary Sciences"],
    incubatedStartups: 9,
    contactFaculty: "Dr. M. S. Soren",
    email: "director.research@bauranchi.org",
    activeProjectsCount: 3
  }
];


// ============================================================================
// 6. 8 INDUSTRY & CORPORATE CSR FOUNDATIONS
// ============================================================================

export const INDUSTRIES = [
  {
    id: "i1",
    name: "Tata Steel CSR / Tata Steel Foundation",
    shortName: "Tata Steel CSR",
    type: "Large Industry Foundation",
    headquarters: "Jamshedpur",
    budget: 25000000, // ₹2.5 Cr
    committed: 14200000,
    disbursed: 9200000,
    focusDomains: ["Drinking Water", "Rural Education", "Sanitation Infrastructure", "Tribal Health"],
    representative: "Ms. Sharmila Sengupta",
    contactEmail: "csr@tatasteel.com"
  },
  {
    id: "i2",
    name: "Jindal Steel & Power Foundation",
    shortName: "Jindal Steel Foundation",
    type: "Large Industry Foundation",
    headquarters: "Ramgarh / Patratu",
    budget: 18000000, // ₹1.8 Cr
    committed: 8500000,
    disbursed: 4100000,
    focusDomains: ["Road Safety & Signage", "Soil Regeneration", "Women SHG Livelihoods"],
    representative: "Mr. Rajeev Nambiar",
    contactEmail: "jspl.csr@jindalsteel.com"
  },
  {
    id: "i3",
    name: "Central Coalfields Limited (CCL) CSR",
    shortName: "CCL CSR (Ranchi)",
    type: "Public Sector Undertaking (PSU)",
    headquarters: "Darbhanga House, Ranchi",
    budget: 12000000, // ₹1.2 Cr
    committed: 6400000,
    disbursed: 3800000,
    focusDomains: ["Solar Micro-grids", "Piped Potable Water", "Sports & Tribal Schools"],
    representative: "Sri B. K. Sahay",
    contactEmail: "ccl.csr@coalindia.in"
  },
  {
    id: "i4",
    name: "Bharat Coking Coal Limited (BCCL) CSR",
    shortName: "BCCL CSR (Dhanbad)",
    type: "Public Sector Undertaking (PSU)",
    headquarters: "Koyla Bhawan, Dhanbad",
    budget: 15000000, // ₹1.5 Cr
    committed: 7800000,
    disbursed: 4900000,
    focusDomains: ["Air Quality & Dust Suppression", "Mine Runoff Bioremediation", "Community Hospitals"],
    representative: "Sri A. Bhattacharya",
    contactEmail: "bccl.csr@coalindia.in"
  },
  {
    id: "i5",
    name: "SAIL Bokaro Steel Plant CSR",
    shortName: "SAIL Bokaro CSR",
    type: "Public Sector Undertaking (PSU)",
    headquarters: "Bokaro Steel City",
    budget: 9500000,
    committed: 4200000,
    disbursed: 2100000,
    focusDomains: ["Urban Lighting", "Technical Skill Labs", "Disability Equipment"],
    representative: "Sri V. P. Singh",
    contactEmail: "csr.bsl@sail.in"
  },
  {
    id: "i6",
    name: "Ranchi MSME Industrial Consortium",
    shortName: "Ranchi MSME Consortium",
    type: "MSME Industry Cluster",
    headquarters: "Tupudana Industrial Area, Ranchi",
    budget: 3500000,
    committed: 1800000,
    disbursed: 950000,
    focusDomains: ["Low-Cost Sensor IoT", "Fabrication of Bio-Digesters", "Mobile Apps"],
    representative: "Mr. Gaurav Chhabra",
    contactEmail: "consortium@ranchimsme.org"
  },
  {
    id: "i7",
    name: "Jharkhand Startup Hub / AIC-BIP Ventures",
    shortName: "Jharkhand Startup Hub",
    type: "Innovation Incubator & Angel Pool",
    headquarters: "Namkum, Ranchi",
    budget: 2000000,
    committed: 1100000,
    disbursed: 600000,
    focusDomains: ["AgriTech Drones", "Offline PDS Software", "Tele-Triage"],
    representative: "Ms. Neha Tirkey",
    contactEmail: "seed@jharkhandstartups.in"
  },
  {
    id: "i8",
    name: "Adani Foundation (Godda Power CSR)",
    shortName: "Adani Foundation",
    type: "Corporate CSR",
    headquarters: "Godda",
    budget: 14000000,
    committed: 5200000,
    disbursed: 3100000,
    focusDomains: ["Pothole Remediation", "Drinking Water Plants", "Smart Classrooms"],
    representative: "Mr. Sudhir Verma",
    contactEmail: "csr.godda@adani.com"
  }
];

export const SUBMITTER_TYPES = [
  "Individual",
  "Community Group",
  "Panchayati Raj Institution",
  "Urban Local Body",
  "Government Department"
];

export const STATUSES = [
  "NEW",
  "AI_ANALYZED",
  "VERIFICATION_PENDING",
  "VERIFIED",
  "ASSIGNED",
  "IN_PROGRESS",
  "RESOLUTION_SUBMITTED",
  "FIELD_AUDITED",
  "CITIZEN_VALIDATION_PENDING",
  "DISPUTED",
  "VERIFIED_CLOSED",
  "CLUSTERED_SYSTEMIC"
];

export const LANGUAGES = [
  { code: "en", label: "English", native: "English" },
  { code: "hi", label: "Hindi", native: "हिन्दी" },
  { code: "sat", label: "Santhali", native: "ᱥᱟᱱᱛᱟᱲᱤ" }
];


// ============================================================================
// 7. 28 REALISTIC CIVIC PROBLEM CASES (ALL 10 STATE PROGRESSION STATES)
// ============================================================================

export const SEED_PROBLEMS = [
  // --------------------------------------------------------------------------
  // STATE: CLUSTERED_SYSTEMIC (Derived into Master Challenge)
  // --------------------------------------------------------------------------
  {
    id: "NIR-2026-00001",
    aliasId: "p1",
    title: "Handpump failure in Toli village for 3 weeks",
    description: "The single community handpump serving 42 households in Toli village (block: Bundu) has been dry since 12 August. Women walk 1.8 km to the river. Children missing morning school.",
    category: "Water",
    district: "Ranchi",
    location: "Toli Village, Bundu Block",
    lat: 23.3300,
    lng: 85.3300,
    submitter: { name: "Budhram Munda", type: "Community Group", phone: "+91 94311 00101" },
    priority: "High",
    priorityScore: 92,
    aiConfidence: 94,
    severity: "Critical",
    status: "CLUSTERED_SYSTEMIC",
    assignedOfficer: "O-101",
    assignedDept: "PHED",
    escalationLevel: 0,
    evidenceVerified: true,
    reportsCount: 47,
    upvotes: 34,
    reportedOn: "2026-08-18",
    clusterId: "CLUSTER-101",
    linkedChallengeId: "MC-1024",
    resolutionProof: null,
    citizenFeedback: null,
    timeline: [
      { state: "Citizen Reported", time: "2026-08-18 09:15", actor: "Budhram Munda", done: true },
      { state: "AI Analyzed", time: "2026-08-18 09:16", actor: "NIRVAHA AI Core", remarks: "Priority 92. Geo-cluster match detected with 46 surrounding water point failures.", done: true },
      { state: "Evidence Verified", time: "2026-08-18 11:30", actor: "Er. Rajeshwar Prasad", remarks: "Hydrogeological depletion in Bundu confirmed.", done: true },
      { state: "Clustered to Systemic", time: "2026-08-20 14:00", actor: "Systemic Root Cause Engine", remarks: "Aggregated into CLUSTER-101 (Aquifer Drop & Arsenic).", done: true }
    ]
  },

  // --------------------------------------------------------------------------
  // STATE: IN_PROGRESS (Ground Inspection Initiated / Work Underway)
  // --------------------------------------------------------------------------
  {
    id: "NIR-2026-00002",
    aliasId: "p2",
    title: "Pothole cluster on NH-33 near Sikidiri",
    description: "Three major potholes on NH-33 stretch between Sikidiri and Godda have caused 4 two-wheeler accidents this monsoon. No signage, no barricades.",
    category: "Roads",
    district: "Godda",
    location: "NH-33 Mile Marker 42, Sikidiri",
    lat: 24.8400,
    lng: 87.2200,
    submitter: { name: "Anand Kishore", type: "Individual", phone: "+91 94311 00102" },
    priority: "Urgent",
    priorityScore: 89,
    aiConfidence: 91,
    severity: "High",
    status: "IN_PROGRESS",
    assignedOfficer: "O-102",
    assignedDept: "PWD",
    escalationLevel: 0,
    evidenceVerified: true,
    reportsCount: 18,
    upvotes: 89,
    reportedOn: "2026-08-02",
    clusterId: "CLUSTER-102",
    linkedChallengeId: "MC-1025",
    resolutionProof: null,
    citizenFeedback: null,
    timeline: [
      { state: "Citizen Reported", time: "2026-08-02 08:30", actor: "Anand Kishore", done: true },
      { state: "AI Analyzed", time: "2026-08-02 08:32", actor: "NIRVAHA AI Core", remarks: "Urgent safety flag: accident history on NH corridor.", done: true },
      { state: "Evidence Verified", time: "2026-08-02 10:45", actor: "Desk Officer RCD", done: true },
      { state: "Officer Assigned", time: "2026-08-02 14:00", actor: "Er. Alok Kumar Singh", remarks: "Road maintenance contractor dispatched.", done: true },
      { state: "Inspection Started", time: "2026-08-03 09:00", actor: "Er. Alok Kumar Singh", remarks: "Cold-mix asphalt patch team deployed on-site.", done: true }
    ]
  },

  // --------------------------------------------------------------------------
  // STATE: VERIFIED_CLOSED (Outcome Verified by Citizen with 5-Star Rating)
  // --------------------------------------------------------------------------
  {
    id: "NIR-2026-00003",
    aliasId: "p3",
    title: "Primary school without functional toilets since 2025",
    description: "GG+UPS Simaria has 184 students but both toilet blocks have been non-functional since October 2025. Girls' attendance dropped 28%.",
    category: "Sanitation",
    district: "Hazaribagh",
    location: "GG+UPS Simaria Block",
    lat: 23.9900,
    lng: 85.3500,
    submitter: { name: "Headmaster D. Soren", type: "Government Department", phone: "+91 94311 00103" },
    priority: "High",
    priorityScore: 88,
    aiConfidence: 95,
    severity: "High",
    status: "VERIFIED_CLOSED",
    assignedOfficer: "O-104",
    assignedDept: "EDU",
    escalationLevel: 0,
    evidenceVerified: true,
    reportsCount: 14,
    upvotes: 122,
    reportedOn: "2026-06-14",
    clusterId: "CLUSTER-103",
    linkedChallengeId: "MC-1026",
    resolutionProof: {
      beforeImage: "https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=400",
      afterImage: "https://images.unsplash.com/photo-1541829070764-84a7d30dd3f3?w=400",
      completionRemarks: "Prefab bio-digester sanitation units installed with running tap water connection and solar-powered pumping.",
      submittedAt: "2026-08-02 15:45",
      geoTag: { lat: 23.9902, lng: 85.3501, accuracyMeters: 4 },
      inspectorVerdict: "VERIFIED_SATISFACTORY",
      inspectedAt: "2026-08-05 11:20"
    },
    citizenFeedback: {
      rating: 5,
      comment: "Both girls' and boys' bio-toilets are completely operational. Attendance is back to 100%. Outstanding work!",
      validatedAt: "2026-08-08 14:10",
      disputeReason: null
    },
    timeline: [
      { state: "Citizen Reported", time: "2026-06-14 10:00", actor: "Headmaster D. Soren", done: true },
      { state: "AI Analyzed", time: "2026-06-14 10:02", actor: "NIRVAHA AI Core", done: true },
      { state: "Evidence Verified", time: "2026-06-14 14:20", actor: "Smt. Meenakshi Toppo", done: true },
      { state: "Officer Assigned", time: "2026-06-15 09:30", actor: "Smt. Meenakshi Toppo", done: true },
      { state: "Inspection Started", time: "2026-06-18 11:00", actor: "Field Engineering Unit", done: true },
      { state: "Resolution Submitted", time: "2026-08-02 15:45", actor: "Field Engineering Unit", done: true },
      { state: "Field Audited", time: "2026-08-05 11:20", actor: "District Quality Inspector", done: true },
      { state: "Citizen Validated", time: "2026-08-08 14:10", actor: "Headmaster D. Soren (5/5 Stars)", done: true },
      { state: "Archived to Knowledge Base", time: "2026-08-10 16:00", actor: "Knowledge Officer", remarks: "Recorded as KR-101", done: true }
    ]
  },

  // --------------------------------------------------------------------------
  // STATE: ASSIGNED (Officer Assigned with Response SLA Timer)
  // --------------------------------------------------------------------------
  {
    id: "NIR-2026-00004",
    aliasId: "p4",
    title: "Fallow land conversion plan needed for 12 hectares in Patratu",
    description: "12 ha of community land near Patratu has lain fallow for 5 years. Farmers request soil testing + crop planning support for millets.",
    category: "Agriculture",
    district: "Ramgarh",
    location: "Patratu Panchayat Sector 3",
    lat: 23.6400,
    lng: 85.2800,
    submitter: { name: "Panchayat Mukhiya S. Mahto", type: "Panchayati Raj Institution", phone: "+91 94311 00104" },
    priority: "Medium",
    priorityScore: 68,
    aiConfidence: 89,
    severity: "Medium",
    status: "ASSIGNED",
    assignedOfficer: "O-105",
    assignedDept: "AGRI",
    escalationLevel: 0,
    evidenceVerified: true,
    reportsCount: 6,
    upvotes: 18,
    reportedOn: "2026-08-21",
    clusterId: "CLUSTER-105",
    linkedChallengeId: null,
    resolutionProof: null,
    citizenFeedback: null,
    timeline: [
      { state: "Citizen Reported", time: "2026-08-21 11:15", actor: "Mukhiya S. Mahto", done: true },
      { state: "AI Analyzed", time: "2026-08-21 11:17", actor: "NIRVAHA AI Core", done: true },
      { state: "Evidence Verified", time: "2026-08-22 09:30", actor: "Sri Rameshwar Mahto", done: true },
      { state: "Officer Assigned", time: "2026-08-22 14:00", actor: "Sri Rameshwar Mahto", remarks: "Assigned to Block Agriculture Officer. Soil testing van scheduled.", done: true }
    ]
  },

  // --------------------------------------------------------------------------
  // STATE: VERIFICATION_PENDING (AI Analyzed, Desk Officer Confirmation Required)
  // --------------------------------------------------------------------------
  {
    id: "NIR-2026-00005",
    aliasId: "p5",
    title: "PHC Chaibasa lacks functioning ECG machine",
    description: "The 30-bed PHC at Chaibasa has a donated ECG machine that has been non-functional for 8 months. Cardiac emergencies are referred 90 km to Jamshedpur.",
    category: "Health",
    district: "West Singhbhum",
    location: "Sadar PHC, Chaibasa",
    lat: 22.5400,
    lng: 85.8000,
    submitter: { name: "Dr. K. Murmu", type: "Individual", phone: "+91 94311 00105" },
    priority: "Urgent",
    priorityScore: 94,
    aiConfidence: 96,
    severity: "Critical",
    status: "VERIFICATION_PENDING",
    assignedOfficer: null,
    assignedDept: "HEALTH",
    escalationLevel: 0,
    evidenceVerified: false,
    reportsCount: 9,
    upvotes: 67,
    reportedOn: "2026-08-26",
    clusterId: null,
    linkedChallengeId: null,
    resolutionProof: null,
    citizenFeedback: null,
    timeline: [
      { state: "Citizen Reported", time: "2026-08-26 14:30", actor: "Dr. K. Murmu", done: true },
      { state: "AI Analyzed", time: "2026-08-26 14:31", actor: "NIRVAHA AI Core", remarks: "Flagged: Critical emergency triage gap > 50km.", done: true }
    ]
  },

  // --------------------------------------------------------------------------
  // STATE: NEW (Citizen Just Registered, Pending AI Classification)
  // --------------------------------------------------------------------------
  {
    id: "NIR-2026-00006",
    aliasId: "p6",
    title: "Wheelchair-inaccessible entrance at District Hospital Gumla",
    description: "Only stairs lead to the OPD block. No ramp, no lift. Elderly and disabled patients are carried by relatives.",
    category: "Accessibility",
    district: "Gumla",
    location: "District Hospital OPD Entrance",
    lat: 23.0400,
    lng: 84.5400,
    submitter: { name: "Sudhir Tirkey", type: "Individual", phone: "+91 94311 00106" },
    priority: "High",
    priorityScore: 78,
    aiConfidence: 85,
    severity: "High",
    status: "NEW",
    assignedOfficer: null,
    assignedDept: "WCD",
    escalationLevel: 0,
    evidenceVerified: false,
    reportsCount: 3,
    upvotes: 12,
    reportedOn: "2026-08-28",
    clusterId: null,
    linkedChallengeId: null,
    resolutionProof: null,
    citizenFeedback: null,
    timeline: [
      { state: "Citizen Reported", time: "2026-08-28 09:40", actor: "Sudhir Tirkey", done: true }
    ]
  },

  // --------------------------------------------------------------------------
  // STATE: IN_PROGRESS
  // --------------------------------------------------------------------------
  {
    id: "NIR-2026-00007",
    aliasId: "p7",
    title: "Illegal mining debris blocking Koel river tributary",
    description: "Iron ore mining debris has narrowed the South Koel tributary near Bolnim. Flood risk for 3 villages upstream.",
    category: "Environment",
    district: "West Singhbhum",
    location: "Bolnim Reach, South Koel River",
    lat: 22.4800,
    lng: 85.1800,
    submitter: { name: "Bolnim Gram Vikas Samiti", type: "Community Group", phone: "+91 94311 00107" },
    priority: "Urgent",
    priorityScore: 95,
    aiConfidence: 93,
    severity: "Critical",
    status: "IN_PROGRESS",
    assignedOfficer: "O-108",
    assignedDept: "FOREST",
    escalationLevel: 0,
    evidenceVerified: true,
    reportsCount: 31,
    upvotes: 201,
    reportedOn: "2026-07-11",
    clusterId: "CLUSTER-104",
    linkedChallengeId: "MC-1027",
    resolutionProof: null,
    citizenFeedback: null,
    timeline: [
      { state: "Citizen Reported", time: "2026-07-11 07:15", actor: "Gram Vikas Samiti", done: true },
      { state: "AI Analyzed", time: "2026-07-11 07:18", actor: "NIRVAHA AI Core", done: true },
      { state: "Evidence Verified", time: "2026-07-12 10:00", actor: "Sri Animesh Sengupta", done: true },
      { state: "Officer Assigned", time: "2026-07-12 15:30", actor: "Sri Animesh Sengupta", done: true },
      { state: "Inspection Started", time: "2026-07-15 08:30", actor: "Forest Task Force", remarks: "Excavators deployed to clear tributary channel.", done: true }
    ]
  },

  // --------------------------------------------------------------------------
  // STATE: DISPUTED (Citizen Rejects Resolution Proof -> DM Escalation)
  // --------------------------------------------------------------------------
  {
    id: "NIR-2026-00008",
    aliasId: "p8",
    title: "Streetlights non-functional in 4 wards of Bokaro Steel City",
    description: "Sectors 1, 2, 4 and 5A have had non-functional streetlights for 6 weeks. Women's safety helpline received 11 complaints.",
    category: "Urban Infra",
    district: "Bokaro",
    location: "Sectors 1, 2, 4, 5A Bokaro",
    lat: 23.6700,
    lng: 86.1500,
    submitter: { name: "Bokaro Citizen Forum", type: "Urban Local Body", phone: "+91 94311 00108" },
    priority: "High",
    priorityScore: 84,
    aiConfidence: 89,
    severity: "High",
    status: "DISPUTED",
    assignedOfficer: "O-106",
    assignedDept: "UDHD",
    escalationLevel: 2,
    evidenceVerified: true,
    reportsCount: 22,
    upvotes: 156,
    reportedOn: "2026-08-14",
    clusterId: null,
    linkedChallengeId: null,
    resolutionProof: {
      beforeImage: "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=400",
      afterImage: "https://images.unsplash.com/photo-1517457373958-b7bdd4587205?w=400",
      completionRemarks: "Line maintenance carried out on Sector 1 substation.",
      submittedAt: "2026-08-25 16:30",
      geoTag: { lat: 23.6710, lng: 86.1520, accuracyMeters: 10 },
      inspectorVerdict: "VERIFIED_DEFICIENT",
      inspectedAt: "2026-08-26 14:00"
    },
    citizenFeedback: {
      rating: 1,
      comment: "Only 3 bulbs were replaced in Sector 1! Sectors 4 and 5A remain pitch dark. Unacceptable false resolution.",
      validatedAt: "2026-08-27 10:15",
      disputeReason: "Partial fix only — major stretches still dark and dangerous."
    },
    timeline: [
      { state: "Citizen Reported", time: "2026-08-14 18:20", actor: "Citizen Forum", done: true },
      { state: "AI Analyzed", time: "2026-08-14 18:22", actor: "NIRVAHA AI Core", done: true },
      { state: "Officer Assigned", time: "2026-08-15 10:00", actor: "Er. Vikas Anand", done: true },
      { state: "Resolution Submitted", time: "2026-08-25 16:30", actor: "Field Maintenance Team", done: true },
      { state: "Citizen Disputed", time: "2026-08-27 10:15", actor: "Bokaro Citizen Forum", remarks: "Dispute submitted: Sectors 4 & 5A unaddressed.", done: true },
      { state: "Escalated to District Magistrate", time: "2026-08-27 10:30", actor: "NIRVAHA Escalation Engine", remarks: "Escalation Level L2 triggered. DM review mandated.", done: true }
    ]
  },

  // --------------------------------------------------------------------------
  // STATE: IN_PROGRESS
  // --------------------------------------------------------------------------
  {
    id: "NIR-2026-00009",
    aliasId: "p9",
    title: "Ration shop PDS portal down for 18 days in Dhanbad",
    description: "Aadhaar-based PDS authentication portal at 7 ration shops in BCCL Area has been offline since 10 Aug. 1,200 families unable to collect August grain.",
    category: "Public Service",
    district: "Dhanbad",
    location: "BCCL Area Ration Outlets",
    lat: 23.8000,
    lng: 86.4400,
    submitter: { name: "Sunil Marandi", type: "Community Group", phone: "+91 94311 00109" },
    priority: "Urgent",
    priorityScore: 96,
    aiConfidence: 97,
    severity: "Critical",
    status: "IN_PROGRESS",
    assignedOfficer: "O-109",
    assignedDept: "FCS",
    escalationLevel: 1,
    evidenceVerified: true,
    reportsCount: 38,
    upvotes: 287,
    reportedOn: "2026-08-22",
    clusterId: null,
    linkedChallengeId: null,
    resolutionProof: null,
    citizenFeedback: null,
    timeline: [
      { state: "Citizen Reported", time: "2026-08-22 09:10", actor: "Sunil Marandi", done: true },
      { state: "AI Analyzed", time: "2026-08-22 09:12", actor: "NIRVAHA AI Core", remarks: "Critical public distribution food security disruption.", done: true },
      { state: "Officer Assigned", time: "2026-08-22 11:30", actor: "Sri Dilip Kumar Roy", done: true },
      { state: "Inspection Started", time: "2026-08-23 10:00", actor: "IT Cell FCS", remarks: "Offline SQLite fallback sync module being loaded onto e-POS devices.", done: true }
    ]
  },

  // --------------------------------------------------------------------------
  // STATE: VERIFIED_CLOSED
  // --------------------------------------------------------------------------
  {
    id: "NIR-2026-00010",
    aliasId: "p10",
    title: "Anganwadi in Dumka needs solar backup for mid-day meal",
    description: "Frequent power cuts (6-8 hrs/day) disrupt mid-day meal cooking at Anganwadi #42, Dumka. 68 children affected.",
    category: "Education",
    district: "Dumka",
    location: "Anganwadi Center 42, Dumka",
    lat: 24.2700,
    lng: 87.2400,
    submitter: { name: "CDPO Dumka", type: "Government Department", phone: "+91 94311 00110" },
    priority: "Medium",
    priorityScore: 71,
    aiConfidence: 91,
    severity: "Medium",
    status: "VERIFIED_CLOSED",
    assignedOfficer: "O-110",
    assignedDept: "ENERGY",
    escalationLevel: 0,
    evidenceVerified: true,
    reportsCount: 5,
    upvotes: 74,
    reportedOn: "2026-05-09",
    clusterId: null,
    linkedChallengeId: null,
    resolutionProof: {
      beforeImage: "https://images.unsplash.com/photo-1516937941344-00b4e0337589?w=400",
      afterImage: "https://images.unsplash.com/photo-1509391365360-2e959784a276?w=400",
      completionRemarks: "Installed 3 kVA rooftop solar inverter system with LiFePO4 battery pack.",
      submittedAt: "2026-07-22 17:00",
      geoTag: { lat: 24.2711, lng: 87.2405, accuracyMeters: 5 },
      inspectorVerdict: "VERIFIED_SATISFACTORY",
      inspectedAt: "2026-07-25 10:30"
    },
    citizenFeedback: {
      rating: 5,
      comment: "Children now receive warm nutritious meals without any interruption. Solar system working flawlessly.",
      validatedAt: "2026-08-10 11:30",
      disputeReason: null
    },
    timeline: [
      { state: "Citizen Reported", time: "2026-05-09 11:00", actor: "CDPO Dumka", done: true },
      { state: "AI Analyzed", time: "2026-05-09 11:02", actor: "NIRVAHA AI Core", done: true },
      { state: "Evidence Verified", time: "2026-05-11 09:30", actor: "Er. Sanjay K. Tirkey", done: true },
      { state: "Officer Assigned", time: "2026-05-15 14:00", actor: "Er. Sanjay K. Tirkey", done: true },
      { state: "Resolution Submitted", time: "2026-07-22 17:00", actor: "Solar EPC Partner", done: true },
      { state: "Citizen Validated", time: "2026-08-10 11:30", actor: "CDPO Dumka (5/5 Stars)", done: true },
      { state: "Archived to Knowledge Base", time: "2026-08-12 15:00", actor: "Knowledge Officer", remarks: "Recorded as KR-102", done: true }
    ]
  },

  // --------------------------------------------------------------------------
  // STATE: RESOLUTION_SUBMITTED (Proof Attached, Pending Field Inspector Audit)
  // --------------------------------------------------------------------------
  {
    id: "NIR-2026-00011",
    aliasId: "p11",
    title: "Arsenic contamination suspected in shallow wells of Palamu",
    description: "3 families in Hussainabad block report hair-loss and skin lesions. Neighboring wells need testing.",
    category: "Water",
    district: "Palamu",
    location: "Hussainabad Block Shallow Wells",
    lat: 24.1500,
    lng: 84.0500,
    submitter: { name: "Ram Chandra Yadav", type: "Individual", phone: "+91 94311 00111" },
    priority: "Urgent",
    priorityScore: 98,
    aiConfidence: 96,
    severity: "Critical",
    status: "RESOLUTION_SUBMITTED",
    assignedOfficer: "O-101",
    assignedDept: "PHED",
    escalationLevel: 0,
    evidenceVerified: true,
    reportsCount: 19,
    upvotes: 41,
    reportedOn: "2026-08-19",
    clusterId: "CLUSTER-101",
    linkedChallengeId: "MC-1024",
    resolutionProof: {
      beforeImage: "https://images.unsplash.com/photo-1548839140-29a749e1bc4e?w=400",
      afterImage: "https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=400",
      completionRemarks: "Water samples sent to State Water Testing Lab; temporary adsorption filter unit installed at community borewell.",
      submittedAt: "2026-09-02 11:00",
      geoTag: { lat: 24.1512, lng: 84.0520, accuracyMeters: 6 },
      inspectorVerdict: null,
      inspectedAt: null
    },
    citizenFeedback: null,
    timeline: [
      { state: "Citizen Reported", time: "2026-08-19 09:00", actor: "Ram Chandra Yadav", done: true },
      { state: "AI Analyzed", time: "2026-08-19 09:03", actor: "NIRVAHA AI Core", remarks: "Heavy metal toxicity alarm. Routed to State Lab & PHED.", done: true },
      { state: "Officer Assigned", time: "2026-08-19 12:00", actor: "Er. Rajeshwar Prasad", done: true },
      { state: "Inspection Started", time: "2026-08-21 08:30", actor: "Mobile Lab Unit", done: true },
      { state: "Resolution Submitted", time: "2026-09-02 11:00", actor: "Er. Rajeshwar Prasad", remarks: "Awaiting Field Inspector validation.", done: true }
    ]
  },

  // --------------------------------------------------------------------------
  // STATE: CLUSTERED_SYSTEMIC
  // --------------------------------------------------------------------------
  {
    id: "NIR-2026-00012",
    aliasId: "p12",
    title: "Solid waste dumping ground leaching into Damodar",
    description: "Unscientific dumping site 400m from Damodar at Topchanchi is leaching during monsoon. Downstream villages rely on this water.",
    category: "Sanitation",
    district: "Dhanbad",
    location: "Topchanchi Damodar Bank",
    lat: 23.8800,
    lng: 86.3400,
    submitter: { name: "Damodar Bachao Abhiyan", type: "Community Group", phone: "+91 94311 00112" },
    priority: "High",
    priorityScore: 91,
    aiConfidence: 93,
    severity: "High",
    status: "CLUSTERED_SYSTEMIC",
    assignedOfficer: "O-106",
    assignedDept: "UDHD",
    escalationLevel: 0,
    evidenceVerified: true,
    reportsCount: 26,
    upvotes: 178,
    reportedOn: "2026-07-22",
    clusterId: "CLUSTER-104",
    linkedChallengeId: "MC-1027",
    resolutionProof: null,
    citizenFeedback: null,
    timeline: [
      { state: "Citizen Reported", time: "2026-07-22 14:10", actor: "Damodar Bachao Abhiyan", done: true },
      { state: "AI Analyzed", time: "2026-07-22 14:12", actor: "NIRVAHA AI Core", done: true },
      { state: "Evidence Verified", time: "2026-07-24 11:00", actor: "Er. Vikas Anand", done: true },
      { state: "Clustered to Systemic", time: "2026-07-28 16:00", actor: "Systemic Root Cause Engine", remarks: "Grouped into CLUSTER-104 (Damodar-Koel Basin Leachate).", done: true }
    ]
  },

  // --------------------------------------------------------------------------
  // STATE: NEW
  // --------------------------------------------------------------------------
  {
    id: "NIR-2026-00013",
    aliasId: "p13",
    title: "Farmers need drone-based crop health survey for Kharif",
    description: "200+ paddy farmers in Chatra block request drone survey for blast disease early detection. Losses last year were 22%.",
    category: "Agriculture",
    district: "Chatra",
    location: "Chatra Block Paddy Fields",
    lat: 24.1900,
    lng: 84.8700,
    submitter: { name: "Kisan Vikas Samiti", type: "Panchayati Raj Institution", phone: "+91 94311 00113" },
    priority: "Medium",
    priorityScore: 65,
    aiConfidence: 87,
    severity: "Medium",
    status: "NEW",
    assignedOfficer: null,
    assignedDept: "AGRI",
    escalationLevel: 0,
    evidenceVerified: false,
    reportsCount: 4,
    upvotes: 29,
    reportedOn: "2026-08-27",
    clusterId: null,
    linkedChallengeId: null,
    resolutionProof: null,
    citizenFeedback: null,
    timeline: [
      { state: "Citizen Reported", time: "2026-08-27 16:20", actor: "Kisan Vikas Samiti", done: true }
    ]
  },

  // --------------------------------------------------------------------------
  // STATE: VERIFICATION_PENDING
  // --------------------------------------------------------------------------
  {
    id: "NIR-2026-00014",
    aliasId: "p14",
    title: "Mobile tower gap in 7 villages of Simdega block",
    description: "7 villages in Simdega have zero mobile coverage. Emergency calls require traveling 6 km. ASHA workers cannot upload MCTS data.",
    category: "Urban Infra",
    district: "Simdega",
    location: "Kolebira-Thethaitangar Belt, Simdega",
    lat: 22.6200,
    lng: 84.4900,
    submitter: { name: "BDO Simdega", type: "Government Department", phone: "+91 94311 00114" },
    priority: "High",
    priorityScore: 82,
    aiConfidence: 88,
    severity: "High",
    status: "VERIFICATION_PENDING",
    assignedOfficer: null,
    assignedDept: "UDHD",
    escalationLevel: 0,
    evidenceVerified: false,
    reportsCount: 7,
    upvotes: 93,
    reportedOn: "2026-08-25",
    clusterId: null,
    linkedChallengeId: null,
    resolutionProof: null,
    citizenFeedback: null,
    timeline: [
      { state: "Citizen Reported", time: "2026-08-25 10:15", actor: "BDO Simdega", done: true },
      { state: "AI Analyzed", time: "2026-08-25 10:17", actor: "NIRVAHA AI Core", done: true }
    ]
  },

  // --------------------------------------------------------------------------
  // STATE: CITIZEN_VALIDATION_PENDING (Inspector Approved, Citizen Validation Sent)
  // --------------------------------------------------------------------------
  {
    id: "NIR-2026-00015",
    aliasId: "p15",
    title: "Tribal hostel in Khunti lacks drinking water RO",
    description: "Kasturba Gandhi Balika Vidyalaya in Khunti has hard TDS-620 water. 140 tribal girls report recurring stomach issues.",
    category: "Water",
    district: "Khunti",
    location: "KGBV Hostel Campus, Khunti",
    lat: 23.0700,
    lng: 85.3300,
    submitter: { name: "Warden S. Toppo", type: "Government Department", phone: "+91 94311 00115" },
    priority: "High",
    priorityScore: 86,
    aiConfidence: 94,
    severity: "High",
    status: "CITIZEN_VALIDATION_PENDING",
    assignedOfficer: "O-101",
    assignedDept: "PHED",
    escalationLevel: 0,
    evidenceVerified: true,
    reportsCount: 11,
    upvotes: 88,
    reportedOn: "2026-08-10",
    clusterId: null,
    linkedChallengeId: null,
    resolutionProof: {
      beforeImage: "https://images.unsplash.com/photo-1548839140-29a749e1bc4e?w=400",
      afterImage: "https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=400",
      completionRemarks: "Commercial 250 LPH RO plant with UV disinfection installed and connected to hostel mess.",
      submittedAt: "2026-08-29 14:00",
      geoTag: { lat: 23.0715, lng: 85.3310, accuracyMeters: 4 },
      inspectorVerdict: "VERIFIED_SATISFACTORY",
      inspectedAt: "2026-08-31 16:30"
    },
    citizenFeedback: null, // Prompt currently open in citizen portal
    timeline: [
      { state: "Citizen Reported", time: "2026-08-10 11:00", actor: "Warden S. Toppo", done: true },
      { state: "AI Analyzed", time: "2026-08-10 11:02", actor: "NIRVAHA AI Core", done: true },
      { state: "Officer Assigned", time: "2026-08-11 10:00", actor: "Er. Rajeshwar Prasad", done: true },
      { state: "Resolution Submitted", time: "2026-08-29 14:00", actor: "Er. Rajeshwar Prasad", done: true },
      { state: "Field Audited", time: "2026-08-31 16:30", actor: "District Health Inspector", remarks: "TDS tested at 85 mg/L. Passed.", done: true },
      { state: "Citizen Validation Pending", time: "2026-09-01 09:00", actor: "NIRVAHA Verification Gateway", remarks: "Validation SMS and prompt dispatched to Warden.", done: true }
    ]
  },

  // --------------------------------------------------------------------------
  // STATE: NEW
  // --------------------------------------------------------------------------
  {
    id: "NIR-2026-00016",
    aliasId: "p16",
    title: "Bus stop without shelter at Itki road junction",
    description: "200+ daily commuters (mostly women workers) wait at Itki road junction without shelter. No bench, no lighting.",
    category: "Accessibility",
    district: "Ranchi",
    location: "Itki Road Junction, Ranchi",
    lat: 23.3100,
    lng: 85.2000,
    submitter: { name: "Sunita Minz", type: "Individual", phone: "+91 94311 00116" },
    priority: "Low",
    priorityScore: 42,
    aiConfidence: 81,
    severity: "Low",
    status: "NEW",
    assignedOfficer: null,
    assignedDept: "PWD",
    escalationLevel: 0,
    evidenceVerified: false,
    reportsCount: 2,
    upvotes: 7,
    reportedOn: "2026-08-28",
    clusterId: null,
    linkedChallengeId: null,
    resolutionProof: null,
    citizenFeedback: null,
    timeline: [
      { state: "Citizen Reported", time: "2026-08-28 17:10", actor: "Sunita Minz", done: true }
    ]
  },

  // --------------------------------------------------------------------------
  // STATE: IN_PROGRESS
  // --------------------------------------------------------------------------
  {
    id: "NIR-2026-00017",
    aliasId: "p17",
    title: "Forest fire risk mapping needed for Saranda",
    description: "Saranda forest (Asia's largest sal forest) had 3 fires last summer. Request predictive fire-risk model using satellite data.",
    category: "Environment",
    district: "West Singhbhum",
    location: "Saranda Sal Forest Range",
    lat: 22.4000,
    lng: 85.7000,
    submitter: { name: "DFO Saranda", type: "Government Department", phone: "+91 94311 00117" },
    priority: "High",
    priorityScore: 85,
    aiConfidence: 94,
    severity: "High",
    status: "IN_PROGRESS",
    assignedOfficer: "O-108",
    assignedDept: "FOREST",
    escalationLevel: 0,
    evidenceVerified: true,
    reportsCount: 8,
    upvotes: 112,
    reportedOn: "2026-07-04",
    clusterId: null,
    linkedChallengeId: null,
    resolutionProof: null,
    citizenFeedback: null,
    timeline: [
      { state: "Citizen Reported", time: "2026-07-04 09:30", actor: "DFO Saranda", done: true },
      { state: "AI Analyzed", time: "2026-07-04 09:35", actor: "NIRVAHA AI Core", done: true },
      { state: "Officer Assigned", time: "2026-07-06 11:00", actor: "Sri Animesh Sengupta", done: true },
      { state: "Inspection Started", time: "2026-07-10 10:00", actor: "CUJ / ICAR Joint Lab", remarks: "MODIS thermal anomaly stream integrated.", done: true }
    ]
  },

  // --------------------------------------------------------------------------
  // STATE: ASSIGNED
  // --------------------------------------------------------------------------
  {
    id: "NIR-2026-00018",
    aliasId: "p18",
    title: "AI-based triage for PHCs with single doctor",
    description: "PHCs in Latehar block serve 25,000 population with 1 doctor. Request AI symptom-triage tool in Hindi.",
    category: "Health",
    district: "Latehar",
    location: "Latehar Rural PHCs",
    lat: 23.7400,
    lng: 84.2000,
    submitter: { name: "Civil Surgeon Latehar", type: "Government Department", phone: "+91 94311 00118" },
    priority: "Medium",
    priorityScore: 74,
    aiConfidence: 92,
    severity: "Medium",
    status: "ASSIGNED",
    assignedOfficer: "O-103",
    assignedDept: "HEALTH",
    escalationLevel: 0,
    evidenceVerified: true,
    reportsCount: 6,
    upvotes: 56,
    reportedOn: "2026-08-20",
    clusterId: null,
    linkedChallengeId: null,
    resolutionProof: null,
    citizenFeedback: null,
    timeline: [
      { state: "Citizen Reported", time: "2026-08-20 12:00", actor: "Civil Surgeon Latehar", done: true },
      { state: "AI Analyzed", time: "2026-08-20 12:03", actor: "NIRVAHA AI Core", done: true },
      { state: "Officer Assigned", time: "2026-08-22 15:00", actor: "Dr. Sunita Soren", done: true }
    ]
  },

  // --------------------------------------------------------------------------
  // STATE: VERIFICATION_PENDING
  // --------------------------------------------------------------------------
  {
    id: "NIR-2026-00019",
    aliasId: "p19",
    title: "Open defecation returning in 3 villages of Garhwa",
    description: "Despite ODF status in 2019, 3 villages in Bardiha block have reverted to open defecation due to broken IHHL toilets.",
    category: "Sanitation",
    district: "Garhwa",
    location: "Bardiha Block Villages",
    lat: 24.1800,
    lng: 83.8100,
    submitter: { name: "Bardiha Panchayat Samiti", type: "Panchayati Raj Institution", phone: "+91 94311 00119" },
    priority: "High",
    priorityScore: 84,
    aiConfidence: 91,
    severity: "High",
    status: "VERIFICATION_PENDING",
    assignedOfficer: null,
    assignedDept: "UDHD",
    escalationLevel: 0,
    evidenceVerified: false,
    reportsCount: 12,
    upvotes: 64,
    reportedOn: "2026-08-24",
    clusterId: "CLUSTER-103",
    linkedChallengeId: null,
    resolutionProof: null,
    citizenFeedback: null,
    timeline: [
      { state: "Citizen Reported", time: "2026-08-24 15:10", actor: "Bardiha Panchayat", done: true },
      { state: "AI Analyzed", time: "2026-08-24 15:12", actor: "NIRVAHA AI Core", done: true }
    ]
  },

  // --------------------------------------------------------------------------
  // STATE: ASSIGNED
  // --------------------------------------------------------------------------
  {
    id: "NIR-2026-00020",
    aliasId: "p20",
    title: "Smart classroom setup for 5 Eklavya Model Schools",
    description: "5 EMS schools in Pakur request smart classroom kits + teacher training. Current teaching is blackboard-only.",
    category: "Education",
    district: "Pakur",
    location: "Eklavya Model Residential Schools, Pakur",
    lat: 24.6300,
    lng: 87.7700,
    submitter: { name: "Principal K. Hansda", type: "Government Department", phone: "+91 94311 00120" },
    priority: "Medium",
    priorityScore: 69,
    aiConfidence: 89,
    severity: "Medium",
    status: "ASSIGNED",
    assignedOfficer: "O-104",
    assignedDept: "EDU",
    escalationLevel: 0,
    evidenceVerified: true,
    reportsCount: 5,
    upvotes: 47,
    reportedOn: "2026-07-18",
    clusterId: null,
    linkedChallengeId: null,
    resolutionProof: null,
    citizenFeedback: null,
    timeline: [
      { state: "Citizen Reported", time: "2026-07-18 10:00", actor: "Principal K. Hansda", done: true },
      { state: "Officer Assigned", time: "2026-07-20 11:30", actor: "Smt. Meenakshi Toppo", done: true }
    ]
  },

  // --------------------------------------------------------------------------
  // STATE: CITIZEN_VALIDATION_PENDING
  // --------------------------------------------------------------------------
  {
    id: "NIR-2026-00021",
    aliasId: "p21",
    title: "Flood-resilient raised platform design for Deoghar market",
    description: "Annual flooding damages ₹40L+ goods at Deoghar main market. Need raised modular platform design.",
    category: "Urban Infra",
    district: "Deoghar",
    location: "Deoghar Main Market Area",
    lat: 24.4900,
    lng: 86.6900,
    submitter: { name: "Deoghar Vyapar Sangh", type: "Urban Local Body", phone: "+91 94311 00121" },
    priority: "Medium",
    priorityScore: 73,
    aiConfidence: 88,
    severity: "Medium",
    status: "CITIZEN_VALIDATION_PENDING",
    assignedOfficer: "O-106",
    assignedDept: "UDHD",
    escalationLevel: 0,
    evidenceVerified: true,
    reportsCount: 9,
    upvotes: 38,
    reportedOn: "2026-08-15",
    clusterId: null,
    linkedChallengeId: null,
    resolutionProof: {
      beforeImage: "https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?w=400",
      afterImage: "https://images.unsplash.com/photo-1513694203232-719a280e022f?w=400",
      completionRemarks: "Modular pre-cast concrete raised platforms with integrated drainage sluice gates completed.",
      submittedAt: "2026-08-30 16:00",
      geoTag: { lat: 24.4910, lng: 86.6912, accuracyMeters: 5 },
      inspectorVerdict: "VERIFIED_SATISFACTORY",
      inspectedAt: "2026-09-01 11:30"
    },
    citizenFeedback: null,
    timeline: [
      { state: "Citizen Reported", time: "2026-08-15 14:00", actor: "Vyapar Sangh", done: true },
      { state: "Officer Assigned", time: "2026-08-16 09:30", actor: "Er. Vikas Anand", done: true },
      { state: "Resolution Submitted", time: "2026-08-30 16:00", actor: "Municipal Works Dept", done: true },
      { state: "Field Audited", time: "2026-09-01 11:30", actor: "Urban Planning Auditor", done: true }
    ]
  },

  // --------------------------------------------------------------------------
  // STATE: VERIFICATION_PENDING
  // --------------------------------------------------------------------------
  {
    id: "NIR-2026-00022",
    aliasId: "p22",
    title: "Braille + audio ATMs needed at 12 SBI branches",
    description: "No SBI branch in Ranchi district has audio/Braille ATM. 3,400 visually-impaired account holders affected.",
    category: "Accessibility",
    district: "Ranchi",
    location: "12 SBI Branches across Ranchi District",
    lat: 23.3600,
    lng: 85.3400,
    submitter: { name: "Jharkhand Blind Welfare Union", type: "Community Group", phone: "+91 94311 00122" },
    priority: "Medium",
    priorityScore: 76,
    aiConfidence: 93,
    severity: "Medium",
    status: "VERIFICATION_PENDING",
    assignedOfficer: null,
    assignedDept: "WCD",
    escalationLevel: 0,
    evidenceVerified: false,
    reportsCount: 14,
    upvotes: 103,
    reportedOn: "2026-08-23",
    clusterId: null,
    linkedChallengeId: null,
    resolutionProof: null,
    citizenFeedback: null,
    timeline: [
      { state: "Citizen Reported", time: "2026-08-23 11:20", actor: "Blind Welfare Union", done: true },
      { state: "AI Analyzed", time: "2026-08-23 11:23", actor: "NIRVAHA AI Core", done: true }
    ]
  },

  // --------------------------------------------------------------------------
  // STATE: VERIFIED (Evidence Verified by Desk Officer, Ready for Assignment)
  // --------------------------------------------------------------------------
  {
    id: "NIR-2026-00023",
    aliasId: "p23",
    title: "Millet value-chain processing unit for tribal SHGs",
    description: "12 tribal SHGs in Lohardaga grow kodo-kutki but sell raw at ₹18/kg. Need mini processing unit design.",
    category: "Agriculture",
    district: "Lohardaga",
    location: "Kisko Block, Lohardaga",
    lat: 23.4300,
    lng: 84.6700,
    submitter: { name: "Adivasi Mahila Samiti", type: "Community Group", phone: "+91 94311 00123" },
    priority: "Medium",
    priorityScore: 72,
    aiConfidence: 91,
    severity: "Medium",
    status: "VERIFIED",
    assignedOfficer: null,
    assignedDept: "AGRI",
    escalationLevel: 0,
    evidenceVerified: true,
    reportsCount: 7,
    upvotes: 52,
    reportedOn: "2026-08-12",
    clusterId: "CLUSTER-105",
    linkedChallengeId: null,
    resolutionProof: null,
    citizenFeedback: null,
    timeline: [
      { state: "Citizen Reported", time: "2026-08-12 10:30", actor: "Adivasi Mahila Samiti", done: true },
      { state: "AI Analyzed", time: "2026-08-12 10:32", actor: "NIRVAHA AI Core", done: true },
      { state: "Evidence Verified", time: "2026-08-14 14:00", actor: "Sri Rameshwar Mahto", remarks: "Proposal conforms to National Millet Mission standards.", done: true }
    ]
  },

  // --------------------------------------------------------------------------
  // STATE: IN_PROGRESS
  // --------------------------------------------------------------------------
  {
    id: "NIR-2026-00024",
    aliasId: "p24",
    title: "Maternal mortality cluster investigation in Saraikela",
    description: "4 maternal deaths in 6 months in Saraikela block (state avg is much lower). Request epidemiological investigation.",
    category: "Health",
    district: "Saraikela-Kharsawan",
    location: "Saraikela CHC & Sub-centers",
    lat: 23.2800,
    lng: 85.9800,
    submitter: { name: "District Health Society", type: "Government Department", phone: "+91 94311 00124" },
    priority: "Urgent",
    priorityScore: 97,
    aiConfidence: 98,
    severity: "Critical",
    status: "IN_PROGRESS",
    assignedOfficer: "O-103",
    assignedDept: "HEALTH",
    escalationLevel: 1,
    evidenceVerified: true,
    reportsCount: 16,
    upvotes: 144,
    reportedOn: "2026-08-05",
    clusterId: null,
    linkedChallengeId: null,
    resolutionProof: null,
    citizenFeedback: null,
    timeline: [
      { state: "Citizen Reported", time: "2026-08-05 08:00", actor: "District Health Society", done: true },
      { state: "AI Analyzed", time: "2026-08-05 08:02", actor: "NIRVAHA AI Core", remarks: "Critical maternal mortality spike triggered.", done: true },
      { state: "Officer Assigned", time: "2026-08-05 10:00", actor: "Dr. Sunita Soren", done: true },
      { state: "Inspection Started", time: "2026-08-06 09:00", actor: "AIIMS Deoghar / State Epidemiologist Team", done: true }
    ]
  },

  // --------------------------------------------------------------------------
  // STATE: NEW
  // --------------------------------------------------------------------------
  {
    id: "NIR-2026-00025",
    aliasId: "p25",
    title: "E-waste collection & safe disposal for Ranchi",
    description: "Ranchi has no formal e-waste collection. Informal dismantling exposes workers to lead/mercury.",
    category: "Environment",
    district: "Ranchi",
    location: "Ranchi Municipal Corporation Area",
    lat: 23.3800,
    lng: 85.3600,
    submitter: { name: "Pooja Roy", type: "Individual", phone: "+91 94311 00125" },
    priority: "Medium",
    priorityScore: 64,
    aiConfidence: 86,
    severity: "Medium",
    status: "NEW",
    assignedOfficer: null,
    assignedDept: "FOREST",
    escalationLevel: 0,
    evidenceVerified: false,
    reportsCount: 3,
    upvotes: 22,
    reportedOn: "2026-08-27",
    clusterId: null,
    linkedChallengeId: null,
    resolutionProof: null,
    citizenFeedback: null,
    timeline: [
      { state: "Citizen Reported", time: "2026-08-27 18:45", actor: "Pooja Roy", done: true }
    ]
  },

  // --------------------------------------------------------------------------
  // STATE: RESOLUTION_SUBMITTED
  // --------------------------------------------------------------------------
  {
    id: "NIR-2026-00026",
    aliasId: "p26",
    title: "Offline-first attendance app for MGNREGA sites",
    description: "MGNREGA sites in Giridih have 40% attendance failure due to no network. Need offline-first app with sync.",
    category: "Public Service",
    district: "Giridih",
    location: "Tisri & Gawan Blocks, Giridih",
    lat: 24.1800,
    lng: 86.3000,
    submitter: { name: "DRDA Giridih", type: "Government Department", phone: "+91 94311 00126" },
    priority: "High",
    priorityScore: 87,
    aiConfidence: 94,
    severity: "High",
    status: "RESOLUTION_SUBMITTED",
    assignedOfficer: "O-109",
    assignedDept: "FCS",
    escalationLevel: 0,
    evidenceVerified: true,
    reportsCount: 15,
    upvotes: 71,
    reportedOn: "2026-08-17",
    clusterId: null,
    linkedChallengeId: null,
    resolutionProof: {
      beforeImage: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=400",
      afterImage: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400",
      completionRemarks: "Offline-first PWA with biometrics deployed across 18 panchayats. Real-time background sync tested.",
      submittedAt: "2026-09-01 15:20",
      geoTag: { lat: 24.1815, lng: 86.3015, accuracyMeters: 4 },
      inspectorVerdict: null,
      inspectedAt: null
    },
    citizenFeedback: null,
    timeline: [
      { state: "Citizen Reported", time: "2026-08-17 11:00", actor: "DRDA Giridih", done: true },
      { state: "Officer Assigned", time: "2026-08-18 10:00", actor: "Sri Dilip Kumar Roy", done: true },
      { state: "Inspection Started", time: "2026-08-20 09:00", actor: "BIT Mesra IT Team", done: true },
      { state: "Resolution Submitted", time: "2026-09-01 15:20", actor: "Sri Dilip Kumar Roy", done: true }
    ]
  },

  // --------------------------------------------------------------------------
  // STATE: VERIFIED
  // --------------------------------------------------------------------------
  {
    id: "NIR-2026-00027",
    aliasId: "p27",
    title: "EV charging corridor Ranchi-Jamshedpur",
    description: "Only 2 EV chargers on 130 km Ranchi-Jamshedpur corridor. Hinders EV adoption for commercial vehicles.",
    category: "Urban Infra",
    district: "Ranchi",
    location: "NH-33 Ranchi-Jamshedpur Highway",
    lat: 23.4000,
    lng: 85.5000,
    submitter: { name: "Jharkhand EV Transport Guild", type: "Individual", phone: "+91 94311 00127" },
    priority: "Low",
    priorityScore: 52,
    aiConfidence: 84,
    severity: "Low",
    status: "VERIFIED",
    assignedOfficer: null,
    assignedDept: "ENERGY",
    escalationLevel: 0,
    evidenceVerified: true,
    reportsCount: 5,
    upvotes: 14,
    reportedOn: "2026-08-26",
    clusterId: null,
    linkedChallengeId: null,
    resolutionProof: null,
    citizenFeedback: null,
    timeline: [
      { state: "Citizen Reported", time: "2026-08-26 15:00", actor: "EV Transport Guild", done: true },
      { state: "AI Analyzed", time: "2026-08-26 15:02", actor: "NIRVAHA AI Core", done: true },
      { state: "Evidence Verified", time: "2026-08-28 11:00", actor: "Er. Sanjay K. Tirkey", done: true }
    ]
  },

  // --------------------------------------------------------------------------
  // STATE: CITIZEN_VALIDATION_PENDING
  // --------------------------------------------------------------------------
  {
    id: "NIR-2026-00028",
    aliasId: "p28",
    title: "Tribal language learning app for Santhali children",
    description: "Santhali-medium children in Dumka struggle transitioning to Hindi/English in Class 3. Need bilingual learning app.",
    category: "Education",
    district: "Dumka",
    location: "Dumka Primary Education Blocks",
    lat: 24.3000,
    lng: 87.2000,
    submitter: { name: "Santhali Shiksha Samiti", type: "Community Group", phone: "+91 94311 00128" },
    priority: "Medium",
    priorityScore: 75,
    aiConfidence: 93,
    severity: "Medium",
    status: "CITIZEN_VALIDATION_PENDING",
    assignedOfficer: "O-104",
    assignedDept: "EDU",
    escalationLevel: 0,
    evidenceVerified: true,
    reportsCount: 11,
    upvotes: 66,
    reportedOn: "2026-08-08",
    clusterId: null,
    linkedChallengeId: null,
    resolutionProof: {
      beforeImage: "https://images.unsplash.com/photo-1497633762265-9d179a990aa6?w=400",
      afterImage: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=400",
      completionRemarks: "Ol Chiki - Devanagari bilingual tablet app pilot installed across 12 schools in Dumka.",
      submittedAt: "2026-08-30 14:00",
      geoTag: { lat: 24.3012, lng: 87.2015, accuracyMeters: 4 },
      inspectorVerdict: "VERIFIED_SATISFACTORY",
      inspectedAt: "2026-09-01 10:00"
    },
    citizenFeedback: null,
    timeline: [
      { state: "Citizen Reported", time: "2026-08-08 10:00", actor: "Santhali Shiksha Samiti", done: true },
      { state: "Officer Assigned", time: "2026-08-09 11:30", actor: "Smt. Meenakshi Toppo", done: true },
      { state: "Resolution Submitted", time: "2026-08-30 14:00", actor: "CUJ Tribal Tech Team", done: true },
      { state: "Field Audited", time: "2026-09-01 10:00", actor: "District Pedagogy Inspector", done: true }
    ]
  }
];


// ============================================================================
// 8. 5 SPATIAL & THEMATIC PROBLEM CLUSTERS (DBSCAN ENGINE OUTPUTS)
// ============================================================================

export const SEED_CLUSTERS = [
  {
    id: "CLUSTER-101",
    title: "Deep Aquifer Depletion & Arsenic/Fluoride Ingress",
    category: "Water",
    districts: ["Ranchi", "Palamu", "Garhwa"],
    centroidLat: 23.8500,
    centroidLng: 84.7500,
    radiusKm: 24.5,
    problemIds: ["NIR-2026-00001", "NIR-2026-00011"],
    reportCount: 47,
    severity: "Critical",
    systemicScore: 94,
    status: "CONVERTED_TO_CHALLENGE",
    masterChallengeId: "MC-1024",
    rootCauseHypothesis: "Unregulated borewell extraction dropped deep groundwater table by 14m, drawing naturally occurring arsenic layers into potable aquifers.",
    recommendedIntervention: "Autonomous solar-powered adsorption filtration plants with live telemetry.",
    capexEst: 2500000,
    opexSaved3YrEst: 7200000
  },
  {
    id: "CLUSTER-102",
    title: "Monsoon Sub-Base Washout on Heavy Freight NH-33 Corridor",
    category: "Roads",
    districts: ["Godda", "Deoghar", "Dumka"],
    centroidLat: 24.6000,
    centroidLng: 87.0000,
    radiusKm: 38.0,
    problemIds: ["NIR-2026-00002"],
    reportCount: 34,
    severity: "High",
    systemicScore: 88,
    status: "CONVERTED_TO_CHALLENGE",
    masterChallengeId: "MC-1025",
    rootCauseHypothesis: "Inadequate lateral stormwater culverts causing hydrostatic uplift beneath bituminous wear-course during heavy monsoon rain.",
    recommendedIntervention: "Geogrid-reinforced sub-base and smartphone vision early pothole radar.",
    capexEst: 1800000,
    opexSaved3YrEst: 4500000
  },
  {
    id: "CLUSTER-103",
    title: "School Hygiene Deficits & Waterless Bio-Digester Voids",
    category: "Sanitation",
    districts: ["Hazaribagh", "Garhwa", "Chatra"],
    centroidLat: 24.0500,
    centroidLng: 84.9500,
    radiusKm: 29.0,
    problemIds: ["NIR-2026-00003", "NIR-2026-00019"],
    reportCount: 26,
    severity: "High",
    systemicScore: 91,
    status: "CONVERTED_TO_CHALLENGE",
    masterChallengeId: "MC-1026",
    rootCauseHypothesis: "Standard soak-pit toilets failed due to clayey impermeable soil; absence of continuous water connection led to abandonment.",
    recommendedIntervention: "Prefabricated modular bio-digesters with greywater recycling loops.",
    capexEst: 1500000,
    opexSaved3YrEst: 3900000
  },
  {
    id: "CLUSTER-104",
    title: "Industrial Leachate & Mining Slag Runoff in Damodar-Koel Basins",
    category: "Environment",
    districts: ["Dhanbad", "West Singhbhum", "Bokaro"],
    centroidLat: 23.1500,
    centroidLng: 85.7500,
    radiusKm: 48.0,
    problemIds: ["NIR-2026-00007", "NIR-2026-00012"],
    reportCount: 57,
    severity: "Critical",
    systemicScore: 96,
    status: "CONVERTED_TO_CHALLENGE",
    masterChallengeId: "MC-1027",
    rootCauseHypothesis: "Unlined open slag dumping grounds proximate to perennial river banks producing heavy metal acid drainage during peak monsoon runoff.",
    recommendedIntervention: "Microbial inoculant bioremediation barriers and silt filtration bunds.",
    capexEst: 3200000,
    opexSaved3YrEst: 9600000
  },
  {
    id: "CLUSTER-105",
    title: "Tribal Millet Value-Chain & Post-Harvest Processing Voids",
    category: "Agriculture",
    districts: ["Lohardaga", "Ramgarh", "Gumla"],
    centroidLat: 23.4000,
    centroidLng: 84.8500,
    radiusKm: 26.0,
    problemIds: ["NIR-2026-00004", "NIR-2026-00023"],
    reportCount: 18,
    severity: "Medium",
    systemicScore: 79,
    status: "ANALYZED",
    masterChallengeId: null,
    rootCauseHypothesis: "Smallholder tribal farmers lack destoning and dehulling equipment, compelling distress raw grain sales to intermediaries at 40% value loss.",
    recommendedIntervention: "Decentralized micro-processing kiosks powered by mini-solar grids.",
    capexEst: 1100000,
    opexSaved3YrEst: 2800000
  }
];


// ============================================================================
// 9. 4 MASTER CHALLENGES WITH UNIVERSITY / CSR CO-FUNDING
// ============================================================================

export const SEED_CHALLENGES = [
  {
    id: "MC-1024",
    sourceClusterId: "CLUSTER-101",
    title: "Autonomous Solar RO Water Purification Units with Real-time TDS Telemetry",
    category: "Water",
    district: "Ranchi & Palamu",
    location: "Bundu & Hussainabad Blocks",
    lat: 23.3500,
    lng: 85.3200,
    priority: 94,
    linkedReports: 47,
    status: "OPEN_FOR_SOLUTIONS",
    fundingGoal: 2500000, // ₹25 Lakhs
    committedFunds: 1800000, // ₹18 Lakhs
    assignedUniversityId: "u9", // IIT ISM Dhanbad
    partnerIndustryId: "i1", // Tata Steel CSR
    proposalsCount: 3,
    tranches: [
      { id: "t1", title: "Tranche 1: Hydrogeological Survey & Lab Bench Prototype", amount: 600000, status: "DISBURSED" },
      { id: "t2", title: "Tranche 2: Field Pilot at 3 Contaminated Villages", amount: 1200000, status: "PLEDGED" },
      { id: "t3", title: "Tranche 3: Final Deployment & Telemetry Integration", amount: 700000, status: "PENDING" }
    ]
  },
  {
    id: "MC-1025",
    sourceClusterId: "CLUSTER-102",
    title: "Computer Vision Pothole Mapping & High-Durability Cold-Mix Asphalt",
    category: "Roads",
    district: "Godda & Deoghar",
    location: "NH-33 Godda Corridor",
    lat: 24.7500,
    lng: 87.1000,
    priority: 88,
    linkedReports: 34,
    status: "EVALUATING",
    fundingGoal: 1800000,
    committedFunds: 1800000,
    assignedUniversityId: "u2", // NIT Jamshedpur
    partnerIndustryId: "i2", // Jindal Steel Foundation
    proposalsCount: 4,
    tranches: [
      { id: "t1", title: "Tranche 1: Smartphone AI Training Dataset (500 km)", amount: 500000, status: "DISBURSED" },
      { id: "t2", title: "Tranche 2: Cold-mix Polymer Modified Asphalt Pilot", amount: 900000, status: "DISBURSED" },
      { id: "t3", title: "Tranche 3: NHAI Handover & Maintenance Dashboard", amount: 400000, status: "PLEDGED" }
    ]
  },
  {
    id: "MC-1026",
    sourceClusterId: "CLUSTER-103",
    title: "Modular Pre-cast Bio-Digester Sanitation Units for Rural Schools",
    category: "Sanitation",
    district: "Hazaribagh & Garhwa",
    location: "Simaria & Bardiha School Belts",
    lat: 24.0200,
    lng: 85.1500,
    priority: 91,
    linkedReports: 26,
    status: "PROJECT_AWARDED",
    fundingGoal: 1500000,
    committedFunds: 1500000,
    assignedUniversityId: "u3", // Ranchi University
    partnerIndustryId: "i3", // CCL CSR
    proposalsCount: 2,
    tranches: [
      { id: "t1", title: "Tranche 1: Architectural CAD & Inoculant Culture", amount: 400000, status: "DISBURSED" },
      { id: "t2", title: "Tranche 2: Pre-cast Mold Fabrication & Installation", amount: 800000, status: "DISBURSED" },
      { id: "t3", title: "Tranche 3: Student Hygiene Verification & Handover", amount: 300000, status: "DISBURSED" }
    ]
  },
  {
    id: "MC-1027",
    sourceClusterId: "CLUSTER-104",
    title: "Microbial Inoculant Bioremediation for Coal & Iron Slag Mining Leachate",
    category: "Environment",
    district: "Dhanbad & West Singhbhum",
    location: "Damodar Riverbank & Koel Tributary",
    lat: 23.3500,
    lng: 86.0500,
    priority: 96,
    linkedReports: 57,
    status: "OPEN_FOR_SOLUTIONS",
    fundingGoal: 3200000,
    committedFunds: 2400000,
    assignedUniversityId: "u7", // Kolhan University
    partnerIndustryId: "i4", // BCCL CSR
    proposalsCount: 5,
    tranches: [
      { id: "t1", title: "Tranche 1: Hydrological Sampling & Bacterial Isolation", amount: 800000, status: "DISBURSED" },
      { id: "t2", title: "Tranche 2: Bioreactor Construction at Topchanchi", amount: 1600000, status: "PLEDGED" },
      { id: "t3", title: "Tranche 3: Continuous Water Quality Sensor Stream", amount: 800000, status: "PENDING" }
    ]
  }
];

// ============================================================================
// 10. 7 SOLUTION PROJECTS (MILESTONES, TRANCHES, IP & IMPACT)
// ============================================================================

export const SEED_PROJECTS = [
  {
    id: "PROJ-001",
    aliasId: "pr1",
    challengeId: "MC-1026",
    problemId: "NIR-2026-00003",
    universityId: "u3",
    industryId: "i1",
    title: "Low-cost bio-toilet retrofit for rural schools",
    leadPartner: "Ranchi University + Tata Steel CSR",
    stage: "DEPLOYMENT",
    progress: 85,
    status: "ON_TRACK",
    milestones: [
      { id: "m1", name: "Site survey & soil percolation profiling", status: "Done", verifiedOn: "2026-07-10", proof: "percolation_report_v1.pdf" },
      { id: "m2", name: "Prototype installation at GG+UPS Simaria", status: "Done", verifiedOn: "2026-08-02", proof: "installation_photo_gps.jpg" },
      { id: "m3", name: "3-month microbiological effluent testing", status: "In Progress", dueOn: "2026-09-15" },
      { id: "m4", name: "Handover & school maintenance training", status: "To Do", dueOn: "2026-10-01" }
    ],
    funding: { ask: 180000, pledged: 180000, released: 135000 },
    ipStatus: "Disclosure Drafted",
    team: {
      faculty: "Dr. Anjali Verma",
      students: ["Riya Kumari", "Aarav Singh", "Meenakshi Oraon"]
    },
    impact: { beneficiaries: 184, costSaved: 42000, timeSavedMonths: 2 }
  },
  {
    id: "PROJ-002",
    aliasId: "pr2",
    challengeId: null,
    problemId: "NIR-2026-00010",
    universityId: "u2",
    industryId: "i3",
    title: "Solar micro-grid for Anganwadi mid-day meal",
    leadPartner: "NIT Jamshedpur + CCL CSR",
    stage: "VERIFIED_COMPLETE",
    progress: 100,
    status: "ON_TRACK",
    milestones: [
      { id: "m1", name: "Thermal and electrical load assessment", status: "Done", verifiedOn: "2026-06-01" },
      { id: "m2", name: "3 kVA rooftop solar install with LiFePO4 bank", status: "Done", verifiedOn: "2026-07-05" },
      { id: "m3", name: "Battery + hybrid inverter commissioning", status: "Done", verifiedOn: "2026-07-22" },
      { id: "m4", name: "6-month uninterrupted uptime performance report", status: "Done", verifiedOn: "2026-08-10" }
    ],
    funding: { ask: 240000, pledged: 240000, released: 240000 },
    ipStatus: "Open Source / Public Domain",
    team: {
      faculty: "Prof. S. Bhattacharya",
      students: ["Topsi Murmu", "Rohan Das", "Priya Pandey"]
    },
    impact: { beneficiaries: 68, costSaved: 31000, timeSavedMonths: 3 }
  },
  {
    id: "PROJ-003",
    aliasId: "pr3",
    challengeId: "MC-1027",
    problemId: "NIR-2026-00007",
    universityId: "u7",
    industryId: "i2",
    title: "Sediment transport model for Koel tributary",
    leadPartner: "Kolhan University + Jindal Steel Foundation",
    stage: "PILOT",
    progress: 55,
    status: "ON_TRACK",
    milestones: [
      { id: "m1", name: "Hydrological cross-section data collection", status: "Done", verifiedOn: "2026-08-01" },
      { id: "m2", name: "HEC-RAS 2D model hydraulic calibration", status: "In Progress", dueOn: "2026-09-20" },
      { id: "m3", name: "Bio-engineering gabion remediation design", status: "To Do", dueOn: "2026-10-30" },
      { id: "m4", name: "Pilot bank stabilization along 400m stretch", status: "To Do", dueOn: "2026-12-15" }
    ],
    funding: { ask: 520000, pledged: 520000, released: 260000 },
    ipStatus: "Filed",
    team: {
      faculty: "Dr. K. Toppo",
      students: ["Somra Hembram", "Lakhan Munda", "Anita Soren"]
    },
    impact: { beneficiaries: 1800, costSaved: 65000, timeSavedMonths: 0 }
  },
  {
    id: "PROJ-004",
    aliasId: "pr4",
    challengeId: "MC-1025",
    problemId: "NIR-2026-00002",
    universityId: "u2",
    industryId: "i6",
    title: "AI pothole detection using smartphone mounts",
    leadPartner: "NIT Jamshedpur + Ranchi MSME Consortium",
    stage: "PILOT",
    progress: 60,
    status: "AT_RISK",
    milestones: [
      { id: "m1", name: "Dataset collection over 500 km NH/SH corridors", status: "Done", verifiedOn: "2026-08-18" },
      { id: "m2", name: "YOLOv8 embedded edge model quantization", status: "In Progress", dueOn: "2026-09-10" },
      { id: "m3", name: "Android driver client beta deployment", status: "To Do", dueOn: "2026-10-05" },
      { id: "m4", name: "RCD / NHAI operational dashboard handover", status: "To Do", dueOn: "2026-11-15" }
    ],
    funding: { ask: 380000, pledged: 380000, released: 190000 },
    ipStatus: "Disclosure Drafted",
    team: {
      faculty: "Dr. R. Khanna",
      students: ["Dev Sharma", "Ishita Roy", "Karan Mehta"]
    },
    impact: { beneficiaries: 8500, costSaved: 110000, timeSavedMonths: 1 }
  },
  {
    id: "PROJ-005",
    aliasId: "pr5",
    challengeId: null,
    problemId: "NIR-2026-00009",
    universityId: "u1",
    industryId: "i7",
    title: "Offline-first PDS authentication sync",
    leadPartner: "BIT Mesra + Jharkhand Startup Hub",
    stage: "PILOT",
    progress: 70,
    status: "ON_TRACK",
    milestones: [
      { id: "m1", name: "Aadhaar e-KYC local offline token workflow", status: "Done", verifiedOn: "2026-08-25" },
      { id: "m2", name: "SQLite encrypted ledger on Android POS", status: "In Progress", dueOn: "2026-09-18" },
      { id: "m3", name: "Pilot testing across 2 rural fair price shops", status: "To Do", dueOn: "2026-10-10" },
      { id: "m4", name: "Full rollout across 7 BCCL mining area shops", status: "To Do", dueOn: "2026-11-05" }
    ],
    funding: { ask: 220000, pledged: 220000, released: 110000 },
    ipStatus: "Open Source Apache 2.0",
    team: {
      faculty: "Dr. P. Sinha",
      students: ["Neha Gupta", "Arjun Yadav", "Sunita Devi"]
    },
    impact: { beneficiaries: 1200, costSaved: 28000, timeSavedMonths: 0 }
  },
  {
    id: "PROJ-006",
    aliasId: "pr6",
    challengeId: "MC-1027",
    problemId: "NIR-2026-00012",
    universityId: "u3",
    industryId: "i1",
    title: "Leachate containment & bioremediation design",
    leadPartner: "Ranchi University + Tata Steel CSR",
    stage: "PROTOTYPE",
    progress: 40,
    status: "ON_TRACK",
    milestones: [
      { id: "m1", name: "Soil & heavy metal leachate lab sampling", status: "Done", verifiedOn: "2026-08-05" },
      { id: "m2", name: "Bio-char & bacterial consortia formulation", status: "In Progress", dueOn: "2026-09-28" },
      { id: "m3", name: "Field pilot permeable reactive barrier install", status: "To Do", dueOn: "2026-11-01" },
      { id: "m4", name: "State Pollution Control Board compliance audit", status: "To Do", dueOn: "2026-12-10" }
    ],
    funding: { ask: 640000, pledged: 640000, released: 320000 },
    ipStatus: "Patent Filed",
    team: {
      faculty: "Dr. M. Kerketta",
      students: ["Bina Kujur", "Ravi Tiwari", "Salma Ansari"]
    },
    impact: { beneficiaries: 4200, costSaved: 0, timeSavedMonths: 0 }
  },
  {
    id: "PROJ-007",
    aliasId: "pr7",
    challengeId: null,
    problemId: "NIR-2026-00017",
    universityId: "u8",
    industryId: "i2",
    title: "Satellite-based forest fire risk prediction",
    leadPartner: "ICAR Ranchi + Jindal Steel Foundation",
    stage: "PILOT",
    progress: 65,
    status: "ON_TRACK",
    milestones: [
      { id: "m1", name: "MODIS & VIIRS thermal anomaly data pipeline", status: "Done", verifiedOn: "2026-07-28" },
      { id: "m2", name: "Machine learning dry fuel vegetation index model", status: "In Progress", dueOn: "2026-09-25" },
      { id: "m3", name: "Forest Ranger automated WhatsApp alert bot", status: "To Do", dueOn: "2026-11-10" },
      { id: "m4", name: "Pre-fire season validation in Saranda core", status: "To Do", dueOn: "2027-02-15" }
    ],
    funding: { ask: 480000, pledged: 480000, released: 240000 },
    ipStatus: "Disclosure Drafted",
    team: {
      faculty: "Dr. S. Lakra",
      students: ["Duli Hasda", "Vikas Oraon", "Pooja Singh"]
    },
    impact: { beneficiaries: 12000, costSaved: 180000, timeSavedMonths: 4 }
  }
];


// ============================================================================
// 11. 5 PREDICTIVE RISK ALERTS (PREVENTIVE GOVERNANCE RADAR)
// ============================================================================

export const SEED_RISKS = [
  {
    id: "RISK-101",
    title: "Urban Inundation & Trunk Drain Siltation Hazard",
    type: "Urban Flooding",
    category: "Urban Infra",
    district: "Ranchi",
    location: "Lowland Wards 12, 14 & Namkum Culvert",
    lat: 23.3441,
    lng: 85.3096,
    radiusMeters: 1800,
    probability: 88,
    timeWindow: "< 7 Days",
    window: "2-3 Weeks",
    status: "ACTION_REQUIRED",
    severity: "Critical",
    affectedPopulation: 42000,
    contributingFactors: [
      "Met Office forecast of 145mm precipitation over 48 hours",
      "Namkum culvert siltation level estimated at 78% capacity",
      "14 citizen complaints of waterlogging logged in surrounding 1.2 km"
    ],
    recommendedAction: "Dispatch emergency excavator crew to clear trunk drain outlet.",
    preventiveOrderId: "PWO-501"
  },
  {
    id: "RISK-102",
    title: "Vector-Borne Dengue Surge in Unlined Industrial Pockets",
    type: "Dengue Outbreak",
    category: "Health",
    district: "Dhanbad",
    location: "BCCL Sector 4 & Katras Road Area",
    lat: 23.8100,
    lng: 86.4200,
    radiusMeters: 2500,
    probability: 76,
    timeWindow: "14 Days",
    window: "1 Month",
    status: "ACTION_REQUIRED",
    severity: "High",
    affectedPopulation: 28000,
    contributingFactors: [
      "Post-monsoon stagnant pools in abandoned open-cast quarries",
      "Ambient humidity above 82% accelerating mosquito breeding cycles",
      "PHC Chaibasa reporting 35% rise in undifferentiated febrile cases"
    ],
    recommendedAction: "Execute anti-larval fogging and chlorine distribution.",
    preventiveOrderId: "PWO-502"
  },
  {
    id: "RISK-103",
    title: "Dry Forest Canopy Fire Hazard along Rail Siding",
    type: "Forest Fire Risk",
    category: "Environment",
    district: "West Singhbhum",
    location: "Saranda Forest Sector 9 Rail Corridor",
    lat: 22.4000,
    lng: 85.7000,
    radiusMeters: 5000,
    probability: 68,
    timeWindow: "30 Days",
    window: "3-4 Weeks",
    status: "MONITORING",
    severity: "Medium",
    affectedPopulation: 6500,
    contributingFactors: [
      "Satellite dry vegetation index (NDVI) dropped 22% below seasonal mean",
      "Freight train brake sparking incidents recorded along siding",
      "Precipitation deficit of 42mm in August"
    ],
    recommendedAction: "Create 10-meter cleared firebreak lines along rail reserve.",
    preventiveOrderId: "PWO-503"
  },
  {
    id: "RISK-104",
    title: "Frost Hazard for Kharif/Rabi Transition Potato Crops",
    type: "Crop Frost Warning",
    category: "Agriculture",
    district: "Latehar",
    location: "Netarhat Plateau Fringe, Latehar",
    lat: 23.4800,
    lng: 84.2700,
    radiusMeters: 8000,
    probability: 62,
    timeWindow: "30 Days",
    window: "1 Month",
    status: "MONITORING",
    severity: "Medium",
    affectedPopulation: 14500,
    contributingFactors: [
      "IMD localized minimum temperature projection dipping to 4°C",
      "Late monsoon soil moisture depletion in upland sandy loam"
    ],
    recommendedAction: "Issue agricultural advisory for light evening furrow irrigation.",
    preventiveOrderId: null
  },
  {
    id: "RISK-105",
    title: "Structural Sub-base Scour on Subarnarekha River Bridge",
    type: "Bridge Scour Risk",
    category: "Roads",
    district: "East Singhbhum",
    location: "Old NH-33 Subarnarekha River Crossing",
    lat: 22.8200,
    lng: 86.2300,
    radiusMeters: 800,
    probability: 82,
    timeWindow: "< 7 Days",
    window: "Next 48 hrs",
    status: "ACTION_REQUIRED",
    severity: "Critical",
    affectedPopulation: 85000,
    contributingFactors: [
      "River discharge exceeded high water level by 1.1 meters",
      "Sonic echo-sounding indicated 1.8m bed scour near Pier 4",
      "Heavy commercial mineral freight traffic exceeding 40 tonnes"
    ],
    recommendedAction: "Deploy rip-rap boulder armouring around Pier 4 foundation.",
    preventiveOrderId: null
  }
];


// ============================================================================
// 12. 3 PREVENTIVE WORK ORDERS (FROM PREDICTIVE RISKS)
// ============================================================================

export const SEED_PREVENTIVE_ORDERS = [
  {
    id: "PWO-501",
    riskId: "RISK-101",
    title: "Emergency Desilting of Namkum Trunk Drainage Channel",
    department: "UDHD",
    departmentCode: "UDHD",
    assignedOfficerId: "O-106",
    assignedOfficerName: "Er. Vikas Anand",
    deadline: "2026-09-16 18:00",
    budgetAllocated: 150000, // ₹1.5 Lakhs
    status: "DISPATCHED",
    progress: 40,
    actionChecklist: [
      { step: "Deployment of 2 JCB excavators at Namkum outfall", completed: true },
      { step: "Clearing 450m culvert bottleneck", completed: true },
      { step: "Dumping silt to designated landfill", completed: false },
      { step: "Drone post-clearance cross-section verification", completed: false }
    ],
    completionReport: null
  },
  {
    id: "PWO-502",
    riskId: "RISK-102",
    title: "Targeted Anti-Larval Fogging & Chlorination in BCCL Sector 4",
    department: "HEALTH",
    departmentCode: "HEALTH",
    assignedOfficerId: "O-103",
    assignedOfficerName: "Dr. Sunita Soren",
    deadline: "2026-09-22 17:00",
    budgetAllocated: 85000,
    status: "PENDING",
    progress: 10,
    actionChecklist: [
      { step: "Issuance of 500 kg bleaching powder to ward teams", completed: true },
      { step: "Ultra-low-volume malathion fogging in quarry villages", completed: false },
      { step: "School water tank chlorination drive", completed: false }
    ],
    completionReport: null
  },
  {
    id: "PWO-503",
    riskId: "RISK-103",
    title: "Creation of 10m Firebreak Lines along Saranda Rail Reserve",
    department: "FOREST",
    departmentCode: "FOREST",
    assignedOfficerId: "O-108",
    assignedOfficerName: "Sri Animesh Sengupta",
    deadline: "2026-09-30 18:00",
    budgetAllocated: 220000,
    status: "DISPATCHED",
    progress: 65,
    actionChecklist: [
      { step: "Controlled brush clearance along 12 km railway siding", completed: true },
      { step: "Deployment of 4 local Van Samiti fire watch towers", completed: true },
      { step: "Thermal satellite telemetry test verification", completed: false }
    ],
    completionReport: null
  }
];


// ============================================================================
// 13. 4 INSTITUTIONAL KNOWLEDGE RECORDS (KNOWLEDGE REUSE ENGINE)
// ============================================================================

export const SEED_KNOWLEDGE_RECORDS = [
  {
    id: "KR-101",
    sourceProjectId: "PROJ-001",
    title: "Modular Pre-cast Bio-Toilet Retrofit for Rural Schools",
    domain: "Sanitation",
    district: "Hazaribagh",
    successRate: 98,
    timesReused: 12,
    problemBlueprint: "School attendance drop among adolescent girls caused by dilapidated, waterless soak-pit latrines in clayey soil zones.",
    solutionArchitecture: "Pre-cast RC cylindrical anaerobic bio-digester tank inoculated with DRDO microbial consortia, linked to 500L rooftop solar gravity-fed water tank.",
    implementationCostINR: 180000,
    costDisplay: "₹1.8L per 2-unit block",
    deploymentDurationDays: 14,
    impactMetrics: {
      girlsAttendanceIncreasePercent: 28,
      waterUsageReducedLpd: 450,
      maintenanceCostPerYearINR: 3500
    },
    reusableAssets: {
      cadBlueprints: "https://nirvaha.gov.in/assets/cad/bio_toilet_v2.dwg",
      billOfMaterials: "https://nirvaha.gov.in/assets/bom/bio_toilet_bom.xlsx",
      standardOperatingProcedure: "SOP-SAN-042: Monthly Inoculant Feeding & Siphon Flushing",
      testedContractors: ["Ranchi Precast Pvt Ltd", "Bokaro Modular Civil Fab"]
    },
    recommendedForKeywords: ["toilet", "school", "girls", "sanitation", "odf", "hygiene"]
  },
  {
    id: "KR-102",
    sourceProjectId: "PROJ-002",
    title: "3 kVA Rooftop Solar Micro-Grid with LiFePO4 for Anganwadi Centers",
    domain: "Education & Energy",
    district: "Dumka",
    successRate: 96,
    timesReused: 18,
    problemBlueprint: "6-8 hours daily rural power outages disrupting mid-day meal preparation and digital learning in remote preschool Anganwadis.",
    solutionArchitecture: "4x 540W Mono PERC solar panels coupled with 3 kVA MPPT hybrid inverter and 48V 100Ah LiFePO4 wall-mount battery with remote IoT telemetry.",
    implementationCostINR: 240000,
    costDisplay: "₹2.4L per center",
    deploymentDurationDays: 7,
    impactMetrics: {
      uptimePercent: 99.4,
      mealsServedOnTimePercent: 100,
      dieselAvoidedLitersPerYear: 780
    },
    reusableAssets: {
      electricalSchematics: "https://nirvaha.gov.in/assets/schematics/solar_microgrid_3kva.pdf",
      billOfMaterials: "https://nirvaha.gov.in/assets/bom/anganwadi_solar_bom.xlsx",
      standardOperatingProcedure: "SOP-ENG-019: Battery Health Telemetry & Panel Dusting Cycle",
      testedContractors: ["Jharkhand Solar Energy Corp", "Chotanagpur Green Tech"]
    },
    recommendedForKeywords: ["solar", "anganwadi", "electricity", "power cut", "mid-day meal", "energy"]
  },
  {
    id: "KR-103",
    sourceProjectId: "PROJ-004",
    title: "Smartphone Edge-AI Pothole & Road Roughness Profiling",
    domain: "Roads & Transport",
    district: "Godda",
    successRate: 91,
    timesReused: 7,
    problemBlueprint: "Delays of 45-60 days in detecting pavement sub-base deterioration on rural highways leading to fatal two-wheeler accidents.",
    solutionArchitecture: "YOLOv8 quantized model running locally on vehicle-mounted Android devices streaming GPS coordinates and pothole dimensions via lightweight MQTT.",
    implementationCostINR: 120000,
    costDisplay: "₹1.2L per district setup",
    deploymentDurationDays: 3,
    impactMetrics: {
      detectionAccuracyPercent: 92.4,
      inspectionCostReductionPercent: 68,
      speedOfRepairDays: 4
    },
    reusableAssets: {
      codeRepository: "https://github.com/nirvaha-gov/edge-pothole-vision",
      billOfMaterials: "Standard shock-absorbing motorcycle windshield clamp + OTG GPS",
      standardOperatingProcedure: "SOP-PWD-008: Pothole Priority Scoring & Contractor Auto-Dispatch",
      testedContractors: ["NIT Jamshedpur Innovation Hub", "Ranchi Analytics Labs"]
    },
    recommendedForKeywords: ["pothole", "nh-33", "road", "accident", "highway", "asphalt"]
  },
  {
    id: "KR-104",
    sourceProjectId: "PROJ-005",
    title: "SQLite Offline-First Cryptographic PDS Attendance & Grain Ledger",
    domain: "Public Service",
    district: "Dhanbad",
    successRate: 97,
    timesReused: 9,
    problemBlueprint: "Unstable cellular connectivity in mining belts causing 18-day PDS shop shutdowns and leaving vulnerable families without ration.",
    solutionArchitecture: "Progressive Web Application storing cryptographically signed offline quota tokens in SQLCipher with auto-reconciliation when 2G signal resumes.",
    implementationCostINR: 150000,
    costDisplay: "₹1.5L per block rollout",
    deploymentDurationDays: 10,
    impactMetrics: {
      transactionFailureRatePercent: 0.2,
      grainDisbursalOnTimePercent: 99.8,
      reconciliationLagHours: 1.2
    },
    reusableAssets: {
      codeRepository: "https://github.com/nirvaha-gov/pds-offline-sync",
      billOfMaterials: "OTG Biometric Sensor (STQC Certified) + Android 11+ Tablet",
      standardOperatingProcedure: "SOP-FCS-012: Offline Token Verification & End-of-Day Batch Push",
      testedContractors: ["BIT Mesra Software Incubator"]
    },
    recommendedForKeywords: ["ration", "pds", "aadhaar", "offline", "portal down", "food"]
  }
];


// ============================================================================
// 14. 10 REALISTIC AUDIT LOG ENTRIES (PROVENANCE & STATE PROGRESSION)
// ============================================================================

export const SEED_AUDIT_LOGS = [
  {
    id: "LOG-20260912-0001",
    timestamp: "2026-09-12T08:00:00.000Z",
    timeFormatted: "08:00:00 AM",
    actorId: "SYSTEM-CORE",
    actorName: "NIRVAHA System Core",
    actorRole: "system",
    actionType: "SYSTEM_INITIALIZED",
    entityType: "system",
    entityId: "NIR-SYS",
    details: "NIRVAHA Operations Engine initialized with 24 Jharkhand districts and 10 state departments.",
    status: "SUCCESS"
  },
  {
    id: "LOG-20260912-0002",
    timestamp: "2026-09-12T08:15:22.000Z",
    timeFormatted: "08:15:22 AM",
    actorId: "CITIZEN-0101",
    actorName: "Budhram Munda",
    actorRole: "citizen",
    actionType: "PROBLEM_SUBMITTED",
    entityType: "problem",
    entityId: "NIR-2026-00001",
    details: "Citizen reported Handpump failure in Toli village (Bundu, Ranchi).",
    status: "SUCCESS"
  },
  {
    id: "LOG-20260912-0003",
    timestamp: "2026-09-12T08:16:04.000Z",
    timeFormatted: "08:16:04 AM",
    actorId: "AI-ENGINE",
    actorName: "NIRVAHA AI Classifier",
    actorRole: "system",
    actionType: "AI_TRIAGED",
    entityType: "problem",
    entityId: "NIR-2026-00001",
    previousState: "NEW",
    newState: "VERIFICATION_PENDING",
    details: "Classified to Category: Water (PHED). Priority Score: 92/100 (Critical). Confidence: 94%.",
    status: "SUCCESS"
  },
  {
    id: "LOG-20260912-0004",
    timestamp: "2026-09-12T08:30:15.000Z",
    timeFormatted: "08:30:15 AM",
    actorId: "O-101",
    actorName: "Er. Rajeshwar Prasad",
    actorRole: "department_officer",
    actionType: "EVIDENCE_VERIFIED",
    entityType: "problem",
    entityId: "NIR-2026-00001",
    previousState: "VERIFICATION_PENDING",
    newState: "VERIFIED",
    details: "Officer verified photographic evidence. Hydrogeological groundwater drop confirmed.",
    status: "SUCCESS"
  },
  {
    id: "LOG-20260912-0005",
    timestamp: "2026-09-12T08:45:00.000Z",
    timeFormatted: "08:45:00 AM",
    actorId: "DBSCAN-CLUSTERER",
    actorName: "Root Cause Engine",
    actorRole: "system",
    actionType: "PROBLEM_CLUSTERED",
    entityType: "cluster",
    entityId: "CLUSTER-101",
    previousState: "VERIFIED",
    newState: "CLUSTERED_SYSTEMIC",
    details: "NIR-2026-00001 clustered into CLUSTER-101 (47 related complaints within 24.5 km).",
    status: "SUCCESS"
  },
  {
    id: "LOG-20260912-0006",
    timestamp: "2026-09-12T09:00:10.000Z",
    timeFormatted: "09:00:10 AM",
    actorId: "O-104",
    actorName: "Smt. Meenakshi Toppo",
    actorRole: "department_officer",
    actionType: "RESOLUTION_SUBMITTED",
    entityType: "problem",
    entityId: "NIR-2026-00003",
    previousState: "IN_PROGRESS",
    newState: "RESOLUTION_SUBMITTED",
    details: "Resolution proof submitted for Simaria School bio-toilets with geotagged photo pair.",
    status: "SUCCESS"
  },
  {
    id: "LOG-20260912-0007",
    timestamp: "2026-09-12T09:30:45.000Z",
    timeFormatted: "09:30:45 AM",
    actorId: "INSP-402",
    actorName: "Sri K. Murmu (Field Inspector)",
    actorRole: "field_inspector",
    actionType: "FIELD_AUDIT_APPROVED",
    entityType: "problem",
    entityId: "NIR-2026-00003",
    previousState: "RESOLUTION_SUBMITTED",
    newState: "CITIZEN_VALIDATION_PENDING",
    details: "Independent field audit verified bio-digester flow rate and hygiene checklist.",
    status: "SUCCESS"
  },
  {
    id: "LOG-20260912-0008",
    timestamp: "2026-09-12T10:15:30.000Z",
    timeFormatted: "10:15:30 AM",
    actorId: "CITIZEN-0103",
    actorName: "Headmaster D. Soren",
    actorRole: "citizen",
    actionType: "CITIZEN_CONFIRMED_RESOLUTION",
    entityType: "problem",
    entityId: "NIR-2026-00003",
    previousState: "CITIZEN_VALIDATION_PENDING",
    newState: "VERIFIED_CLOSED",
    details: "Citizen validated resolution with 5/5 Star rating: 'Girls attendance restored to 100%'.",
    status: "SUCCESS"
  },
  {
    id: "LOG-20260912-0009",
    timestamp: "2026-09-12T10:45:12.000Z",
    timeFormatted: "10:45:12 AM",
    actorId: "CITIZEN-0108",
    actorName: "Bokaro Citizen Forum",
    actorRole: "citizen",
    actionType: "CITIZEN_DISPUTED_RESOLUTION",
    entityType: "problem",
    entityId: "NIR-2026-00008",
    previousState: "RESOLUTION_SUBMITTED",
    newState: "DISPUTED",
    details: "Citizen disputed resolution: 'Only 3 bulbs replaced in Sector 1. Sectors 4 and 5A pitch dark.'",
    status: "ESCALATION"
  },
  {
    id: "LOG-20260912-0010",
    timestamp: "2026-09-12T11:00:00.000Z",
    timeFormatted: "11:00:00 AM",
    actorId: "PREDICTIVE-RADAR",
    actorName: "Early Warning Risk Radar",
    actorRole: "system",
    actionType: "PREVENTIVE_ORDER_DISPATCHED",
    entityType: "risk",
    entityId: "RISK-101",
    details: "Predicted urban flood in Namkum Lowland Wards (88% prob). Dispatched PWO-501 to Er. Vikas Anand.",
    status: "WARNING"
  }
];


// ============================================================================
// 15. 8 IN-APP NOTIFICATIONS ACROSS ALL 6 ROLES
// ============================================================================

export const SEED_NOTIFICATIONS = [
  {
    id: "NOTIF-01",
    toRole: "citizen",
    recipientName: "Budhram Munda",
    title: "Cluster Formed for Your Report",
    message: "Your report 'Handpump failure in Toli village' was aggregated into Master Challenge MC-1024 with IIT ISM Dhanbad.",
    time: "25m ago",
    unread: true,
    severity: "info",
    linkTarget: "NIR-2026-00001"
  },
  {
    id: "NOTIF-02",
    toRole: "citizen",
    recipientName: "Warden S. Toppo",
    title: "Action Required: Confirm Resolution",
    message: "PHED has installed the 250 LPH RO water plant at KGBV Khunti. Please verify and submit your rating.",
    time: "1h ago",
    unread: true,
    severity: "urgent",
    linkTarget: "NIR-2026-00015"
  },
  {
    id: "NOTIF-03",
    toRole: "department_officer",
    recipientName: "Er. Rajeshwar Prasad",
    title: "High Priority Case Assigned",
    message: "Arsenic contamination suspected in shallow wells of Palamu (NIR-2026-00011). Response SLA: 24 hours.",
    time: "2h ago",
    unread: true,
    severity: "urgent",
    linkTarget: "NIR-2026-00011"
  },
  {
    id: "NOTIF-04",
    toRole: "district_magistrate",
    recipientName: "District Magistrate Bokaro",
    title: "Case Disputed — L2 Escalation",
    message: "Streetlight outage case NIR-2026-00008 disputed by Bokaro Citizen Forum. Review required.",
    time: "3h ago",
    unread: true,
    severity: "warning",
    linkTarget: "NIR-2026-00008"
  },
  {
    id: "NOTIF-05",
    toRole: "field_inspector",
    recipientName: "Sri K. Murmu",
    title: "Physical Audit Assigned",
    message: "Audit inspection request assigned for PDS offline app deployment in Giridih (NIR-2026-00026).",
    time: "4h ago",
    unread: false,
    severity: "info",
    linkTarget: "NIR-2026-00026"
  },
  {
    id: "NOTIF-06",
    toRole: "partner_csr",
    recipientName: "Tata Steel CSR",
    title: "Milestone Verified — Tranche Released",
    message: "Milestone 2 verified for project PROJ-001 (Bio-toilet retrofit). ₹45,000 released from escrow.",
    time: "1d ago",
    unread: false,
    severity: "success",
    linkTarget: "PROJ-001"
  },
  {
    id: "NOTIF-07",
    toRole: "knowledge_officer",
    recipientName: "Knowledge Secretariat",
    title: "New Knowledge Record Generated",
    message: "Project PROJ-002 (Solar Micro-grid Anganwadi) successfully archived as KR-102 with 96% success rating.",
    time: "2d ago",
    unread: false,
    severity: "success",
    linkTarget: "KR-102"
  },
  {
    id: "NOTIF-08",
    toRole: "department_officer",
    recipientName: "Er. Vikas Anand",
    title: "Predictive Early Warning PWO-501",
    message: "Urban flood probability 88% in Namkum lowland wards. PWO-501 issued with ₹1.5L emergency budget.",
    time: "3h ago",
    unread: true,
    severity: "warning",
    linkTarget: "PWO-501"
  }
];


// ============================================================================
// 16. INITIAL SYSTEM STATS & KPI TELEMETRY
// ============================================================================

export const INITIAL_STATS = {
  totalProblems: 12482,
  critical: 326,
  pending: 1842,
  aiPredicted: 27,
  slaAtRisk: 84,
  escalated: 31,
  verificationRate: 94.8,
  firstResponseRate: 91.2,
  slaCompliance: 87.4,
  resolutionRate: 82.6,
  satisfaction: 4.2,
  reopenedCases: 6.8,
  departments: [
    { name: "Drinking Water (PHED)", code: "PHED", cases: 1284, onTime: 84, sla: 88.4, sat: 4.1 },
    { name: "Roads & Transport (PWD)", code: "PWD", cases: 1017, onTime: 79, sla: 81.2, sat: 3.8 },
    { name: "Health & Clinics", code: "HEALTH", cases: 812, onTime: 93, sla: 94.7, sat: 4.5 },
    { name: "School Education", code: "EDU", cases: 628, onTime: 89, sla: 89.6, sat: 4.3 },
    { name: "Urban Infrastructure (UDHD)", code: "UDHD", cases: 741, onTime: 86, sla: 86.8, sat: 4.0 },
    { name: "Energy & Electricity (JUVNL)", code: "ENERGY", cases: 942, onTime: 82, sla: 82.3, sat: 3.9 }
  ],
  slaControl: {
    onTrack: 1421,
    atRisk: 84,
    breached: 22,
    extended: 17
  },
  pipeline: {
    clusters: 47,
    reviewed: 32,
    master: 18,
    open: 11,
    projects: 7,
    pilots: 4,
    deployed: 2
  }
};


