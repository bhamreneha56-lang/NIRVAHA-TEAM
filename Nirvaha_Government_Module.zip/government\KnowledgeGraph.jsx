import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { useSimulation } from '../../context/SimulationContext';
import { Search, RefreshCw, Download, X, AlertTriangle, Layers, Maximize, RotateCcw } from 'lucide-react';
import ForceGraph3D from 'react-force-graph-3d';
import SpriteText from 'three-spritetext';
import * as THREE from 'three';

// ---- Graph Data ----
const NODES = [
  { id:'P1', label:'Groundwater Contamination', type:'problem', severity:'CRITICAL', count:642, district:'Ranchi' },
  { id:'P2', label:'Waterborne Diseases', type:'problem', severity:'CRITICAL', count:418, district:'Dhanbad' },
  { id:'P3', label:'Illegal Mining Activity', type:'problem', severity:'HIGH', count:189, district:'Bokaro' },
  { id:'P4', label:'Pothole & Road Damage', type:'problem', severity:'HIGH', count:521, district:'Ranchi' },
  { id:'P5', label:'Power Outages', type:'problem', severity:'HIGH', count:312, district:'Dhanbad' },
  { id:'P6', label:'School Dropout Rate', type:'problem', severity:'MEDIUM', count:198, district:'Palamu' },
  { id:'RC1', label:'Arsenic Leaching', type:'rootcause', severity:'CRITICAL' },
  { id:'RC2', label:'Budget Underutilization', type:'rootcause', severity:'HIGH' },
  { id:'RC3', label:'Mining Nexus', type:'rootcause', severity:'HIGH' },
  { id:'CH1', label:'Safe Water (MC-1024)', type:'challenge', severity:'OPEN' },
  { id:'CH2', label:'Road Safety (MC-1025)', type:'challenge', severity:'OPEN' },
  { id:'U1', label:'IIT (ISM) Dhanbad', type:'university' },
  { id:'U2', label:'NIT Jamshedpur', type:'university' },
  { id:'CS1', label:'Tata Steel Foundation', type:'csr' },
  { id:'KR1', label:'Water Purification', type:'knowledge' },
];

const EDGES = [
  { source:'RC1', target:'P1', label:'causes' },
  { source:'RC1', target:'P2', label:'causes' },
  { source:'RC3', target:'P3', label:'contributes to' },
  { source:'RC3', target:'P1', label:'accelerates' },
  { source:'RC2', target:'P4', label:'causes' },
  { source:'RC2', target:'P5', label:'causes' },
  { source:'P1', target:'CH1', label:'linked to' },
  { source:'P2', target:'CH1', label:'linked to' },
  { source:'P4', target:'CH2', label:'linked to' },
  { source:'CH1', target:'U1', label:'assigned to' },
  { source:'CH2', target:'U2', label:'assigned to' },
  { source:'CS1', target:'CH1', label:'funding' },
  { source:'U1', target:'KR1', label:'produced' },
  { source:'P6', target:'RC2', label:'root cause' },
];

const NODE_COLORS = {
  problem: '#EF4444',     // Red
  rootcause: '#F59E0B',   // Amber
  challenge: '#8B5CF6',   // Purple
  university: '#3B82F6',  // Blue
  csr: '#10B981',         // Emerald
  knowledge: '#059669',   // Dark Green
};

export default function KnowledgeGraph() {
  const { dispatch } = useSimulation();
  const fgRef = useRef();
  const [selected, setSelected] = useState(null);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('ALL');
  const [dimensions, setDimensions] = useState({ width: 800, height: 600 });
  const containerRef = useRef(null);

  useEffect(() => {
    const updateDimensions = () => {
      if (containerRef.current) {
        setDimensions({
          width: containerRef.current.clientWidth,
          height: containerRef.current.clientHeight
        });
      }
    };
    window.addEventListener('resize', updateDimensions);
    updateDimensions();
    setTimeout(updateDimensions, 100);
    return () => window.removeEventListener('resize', updateDimensions);
  }, []);

  const types = ['ALL', 'problem', 'rootcause', 'challenge', 'university', 'csr', 'knowledge'];

  const graphData = useMemo(() => {
    const filteredNodes = NODES.filter(n => {
      const matchType = typeFilter === 'ALL' || n.type === typeFilter;
      const matchSearch = search === '' || n.label.toLowerCase().includes(search.toLowerCase());
      return matchType && matchSearch;
    });
    const filteredNodeIds = new Set(filteredNodes.map(n => n.id));
    const filteredEdges = EDGES.filter(e => filteredNodeIds.has(e.source) && filteredNodeIds.has(e.target));
    return { nodes: filteredNodes, links: filteredEdges };
  }, [search, typeFilter]);

  const handleNodeClick = useCallback(node => {
    setSelected(node);
    const distance = 120;
    const distRatio = 1 + distance/Math.hypot(node.x, node.y, node.z);
    
    fgRef.current?.cameraPosition(
      { x: node.x * distRatio, y: node.y * distRatio, z: node.z * distRatio },
      node, // lookAt
      1500  // ms transition
    );
  }, [fgRef]);

  const resetCamera = useCallback(() => {
    fgRef.current?.cameraPosition(
      { x: 0, y: 0, z: 400 },
      { x: 0, y: 0, z: 0 },
      1000
    );
  }, [fgRef]);

  const getNode = (id) => NODES.find(n => n.id === id);
  const connectedEdges = selected ? EDGES.filter(e => e.source === selected.id || e.target === selected.id) : [];

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] space-y-3">
      {/* Header */}
      <div className="flex items-center justify-between shrink-0">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">3D Intelligence Graph</h1>
          <p className="text-sm text-slate-500 font-medium">Interactive 3D network visualization of systemic root causes and interventions.</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={resetCamera} className="flex items-center gap-2 px-3 py-2 border border-slate-200 rounded-lg text-xs font-bold text-slate-700 bg-white hover:bg-slate-50"><RotateCcw size={13}/> Reset View</button>
          <button onClick={()=>dispatch({type:'ADD_TOAST',payload:{title:'Graph Exported',message:'Knowledge graph exported.',type:'success'}})} className="flex items-center gap-2 px-3 py-2 border border-slate-200 rounded-lg text-xs font-bold text-slate-700 bg-white hover:bg-slate-50"><Download size={13}/> Export</button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3 shrink-0 flex-wrap">
        <div className="relative">
          <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400"/>
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search nodes..." className="pl-8 pr-3 py-2 border border-slate-200 rounded-lg text-xs bg-white shadow-sm outline-none focus:border-blue-400 w-44"/>
        </div>
        <div className="flex gap-1 flex-wrap">
          {types.map(t => (
            <button key={t} onClick={()=>setTypeFilter(t)} className={`px-2.5 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest border transition-colors ${typeFilter===t?'bg-blue-600 text-white border-blue-600':'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'}`}>{t}</button>
          ))}
        </div>
      </div>

      {/* Main Area */}
      <div className="flex gap-4 flex-1 min-h-0">
        {/* 3D Canvas */}
        <div ref={containerRef} className="flex-1 bg-white rounded-2xl shadow-sm overflow-hidden relative border border-slate-200">
          
          {/* subtle background pattern to make it look modern and less plain white */}
          <div className="absolute inset-0 opacity-[0.03]" style={{backgroundImage: 'radial-gradient(circle at center, black 2px, transparent 2px)', backgroundSize: '40px 40px'}}></div>

          <div className="absolute top-4 left-4 z-10 pointer-events-none">
            <h3 className="text-slate-800 font-black text-lg drop-shadow-sm">Spatial Network</h3>
            <p className="text-slate-500 text-xs font-bold">Drag to rotate • Scroll to zoom</p>
          </div>

          {/* Legend */}
          <div className="absolute bottom-4 left-4 z-10 bg-white/90 backdrop-blur-md border border-slate-200 rounded-xl p-3 shadow-md pointer-events-auto">
            <div className="text-[9px] font-black uppercase tracking-widest text-slate-400 mb-2">Node Types</div>
            {Object.entries(NODE_COLORS).map(([type, color]) => (
              <div key={type} className="flex items-center gap-2 mb-1">
                <div className="w-3 h-3 rounded-full shadow-sm" style={{backgroundColor: color}}/>
                <span className="text-[10px] font-bold text-slate-700 capitalize">{type}</span>
              </div>
            ))}
          </div>

          <ForceGraph3D
            ref={fgRef}
            width={dimensions.width}
            height={dimensions.height}
            graphData={graphData}
            backgroundColor="#FFFFFF"
            nodeThreeObject={node => {
              const group = new THREE.Group();
              
              // Add a modern glowing sphere
              const geometry = new THREE.SphereGeometry(12, 32, 32);
              const material = new THREE.MeshPhysicalMaterial({
                color: NODE_COLORS[node.type] || '#CBD5E1',
                metalness: 0.1,
                roughness: 0.5,
                clearcoat: 1.0,
                clearcoatRoughness: 0.1,
                transparent: true,
                opacity: 0.9,
              });
              const sphere = new THREE.Mesh(geometry, material);
              
              // Outline effect
              const edgesGeometry = new THREE.EdgesGeometry(new THREE.SphereGeometry(12.5, 16, 16));
              const edgesMaterial = new THREE.LineBasicMaterial({ color: '#ffffff', transparent: true, opacity: 0.3 });
              const outline = new THREE.LineSegments(edgesGeometry, edgesMaterial);
              
              group.add(sphere);
              group.add(outline);

              // Add Text Label below the node
              const sprite = new SpriteText(node.label);
              sprite.color = '#334155'; // slate-700 text color
              sprite.textHeight = 4.5;
              sprite.fontWeight = 'bold';
              sprite.backgroundColor = 'rgba(255, 255, 255, 0.85)';
              sprite.borderColor = '#E2E8F0';
              sprite.borderWidth = 0.5;
              sprite.borderRadius = 4;
              sprite.padding = 3;
              sprite.position.y = -18; // position text below the sphere
              group.add(sprite);

              return group;
            }}
            linkWidth={link => link.source === selected?.id || link.target === selected?.id ? 2 : 1}
            linkColor={link => link.source === selected?.id || link.target === selected?.id ? '#3B82F6' : '#CBD5E1'}
            linkOpacity={0.8}
            linkDirectionalParticles={2}
            linkDirectionalParticleWidth={2}
            linkDirectionalParticleColor={() => '#94A3B8'}
            linkDirectionalParticleSpeed={0.008}
            onNodeClick={handleNodeClick}
            showNavInfo={false}
          />
        </div>

        {/* Detail Panel */}
        {selected ? (
          <div className="w-80 bg-white rounded-2xl border border-slate-200 shadow-xl flex flex-col overflow-hidden shrink-0 animate-in slide-in-from-right-4">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between" style={{borderTopWidth: 4, borderTopColor: NODE_COLORS[selected.type]}}>
              <div>
                <div className="text-[10px] font-black uppercase tracking-widest text-slate-500 mb-1">{selected.type}</div>
                <div className="text-lg font-black text-slate-900 leading-tight">{selected.label}</div>
                {selected.district && <div className="text-[10px] text-slate-500 mt-1">{selected.district} District</div>}
              </div>
              <button onClick={()=>setSelected(null)} className="p-1.5 bg-slate-100 hover:bg-slate-200 rounded-full text-slate-500 transition-colors"><X size={16}/></button>
            </div>
            
            <div className="flex-1 overflow-auto p-5 space-y-5">
              {selected.count && (
                <div className="bg-red-50 rounded-xl p-4 border border-red-100 flex items-center gap-4 shadow-sm">
                  <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shrink-0 border border-red-200 shadow-sm">
                    <AlertTriangle className="text-red-500" size={20}/>
                  </div>
                  <div>
                    <div className="text-2xl font-black text-red-700">{selected.count}</div>
                    <div className="text-[10px] font-bold text-red-500 uppercase tracking-widest">Citizen Reports</div>
                  </div>
                </div>
              )}
              
              {selected.severity && (
                <div>
                  <div className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-2">Severity Level</div>
                  <span className="px-3 py-1.5 bg-slate-100 text-slate-800 rounded-lg text-xs font-bold border border-slate-200 shadow-sm">{selected.severity}</span>
                </div>
              )}

              <div>
                <div className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-3 flex items-center gap-2"><Layers size={12}/> Connections ({connectedEdges.length})</div>
                <div className="space-y-2">
                  {connectedEdges.map((e, i) => {
                    const otherId = typeof e.source === 'object' ? (e.source.id === selected.id ? e.target.id : e.source.id) : (e.source === selected.id ? e.target : e.source);
                    const other = getNode(otherId);
                    if(!other) return null;
                    const direction = (typeof e.source === 'object' ? e.source.id : e.source) === selected.id ? 'out' : 'in';
                    
                    return (
                      <div key={i} className="flex items-center gap-3 p-3 bg-white rounded-xl border border-slate-200 cursor-pointer hover:border-blue-300 hover:bg-blue-50 transition-colors shadow-sm" onClick={()=>handleNodeClick(other)}>
                        <div className="w-3 h-3 rounded-full shrink-0 shadow-sm" style={{backgroundColor: NODE_COLORS[other.type]}}/>
                        <div className="flex-1 min-w-0">
                          <div className="text-xs font-bold text-slate-800 leading-tight truncate">{other.label}</div>
                          <div className="text-[10px] text-slate-500 mt-0.5 font-medium">{direction === 'out' ? '→ ' : '← '}{e.label}</div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            <div className="p-5 bg-slate-50 border-t border-slate-100 space-y-2 shrink-0">
              {selected.type === 'problem' && (
                <button onClick={()=>dispatch({type:'ADD_TOAST',payload:{title:'AI Analysis Started',message:'Tracing root cause pathways for '+selected.label,type:'info'}})} className="w-full py-2.5 text-xs font-bold rounded-xl border border-orange-200 text-orange-700 bg-orange-50 hover:bg-orange-100 shadow-sm transition-colors">Trace Root Causes</button>
              )}
              {selected.type === 'rootcause' && (
                <button onClick={()=>dispatch({type:'ADD_TOAST',payload:{title:'Policy Action',message:'Generating intervention policy draft.',type:'success'}})} className="w-full py-2.5 text-xs font-bold rounded-xl bg-blue-600 text-white hover:bg-blue-700 shadow-md transition-all">Draft Intervention</button>
              )}
              {selected.type === 'challenge' && (
                <button onClick={()=>dispatch({type:'START_WORKFLOW',payload:{action:'INVITE_UNIVERSITY',challengeId:selected.id}})} className="w-full py-2.5 text-xs font-bold rounded-xl bg-purple-600 text-white hover:bg-purple-700 shadow-md transition-all">Match Stakeholders</button>
              )}
              <button className="w-full py-2.5 text-xs font-bold rounded-xl border border-slate-200 text-slate-700 bg-white hover:bg-slate-50 shadow-sm transition-colors">Export Node Report</button>
            </div>
          </div>
        ) : (
          <div className="w-80 bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col items-center justify-center text-center p-8 shrink-0">
            <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mb-4 text-blue-500 border border-blue-100 shadow-inner">
              <Maximize size={24}/>
            </div>
            <div className="text-lg font-black text-slate-900 mb-2">Explore the Graph</div>
            <div className="text-sm text-slate-500 leading-relaxed">Rotate the 3D space and click any node to analyze systemic connections, challenges, and interventions.</div>
          </div>
        )}
      </div>
    </div>
  );
}