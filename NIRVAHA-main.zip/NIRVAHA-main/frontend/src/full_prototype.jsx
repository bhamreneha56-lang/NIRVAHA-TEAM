
const { useState, useEffect, useMemo, useRef, createContext, useContext } = React;
const {
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, AreaChart, Area,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} = Recharts;

/* ============================================================
   SEED DATA — realistic Jharkhand civic-tech dataset
   ============================================================ */
const DISTRICTS = [
  "Ranchi","Jamshedpur (East Singhbhum)","Dhanbad","Bokaro","Hazaribagh",
  "Giridih","Deoghar","Dumka","Godda","Sahebganj","Pakur","Latehar",
  "Lohardaga","Gumla","Simdega","West Singhbhum","Khunti","Ramgarh",
  "Koderma","Chatra","Palamu","Garhwa","Saraikela-Kharsawan","Shivpur (Nawadih)"
];

const CATEGORIES = [
  { key:"Water",        icon:"💧", color:"#0ea5e9" },
  { key:"Sanitation",   icon:"🚽", color:"#8b5cf6" },
  { key:"Roads",        icon:"🛣️", color:"#64748b" },
  { key:"Agriculture",  icon:"🌾", color:"#84cc16" },
  { key:"Education",    icon:"📚", color:"#f59e0b" },
  { key:"Health",       icon:"🏥", color:"#ef4444" },
  { key:"Accessibility",icon:"♿", color:"#06b6d4" },
  { key:"Environment",  icon:"🌳", color:"#16a34a" },
  { key:"Urban Infra",  icon:"🏙️", color:"#475569" },
  { key:"Public Service",icon:"🏛️",color:"#b45309" },
];

const UNIVERSITIES = [
  { id:"u1", name:"BIT Mesra",                    short:"BITM", district:"Ranchi",       type:"Technical", strength:180 },
  { id:"u2", name:"NIT Jamshedpur",               short:"NITJ", district:"Jamshedpur (East Singhbhum)", type:"Technical", strength:220 },
  { id:"u3", name:"Ranchi University",            short:"RU",   district:"Ranchi",       type:"General",   strength:260 },
  { id:"u4", name:"IIM Ranchi",                   short:"IIMR", district:"Ranchi",       type:"Management",strength:90  },
  { id:"u5", name:"Central University of Jharkhand",short:"CUJ",district:"Ranchi",       type:"Central",   strength:150 },
  { id:"u6", name:"Vinoba Bhave University",      short:"VBU",  district:"Hazaribagh",   type:"General",   strength:200 },
  { id:"u7", name:"Kolhan University",            short:"KU",   district:"West Singhbhum",type:"General",  strength:170 },
  { id:"u8", name:"ICAR - Research Complex, Ranchi",short:"ICAR",district:"Ranchi",      type:"Research",  strength:60  },
];

const INDUSTRIES = [
  { id:"i1", name:"Tata Steel CSR",        type:"Large Industry", budget: 2500000, committed: 820000 },
  { id:"i2", name:"Jindal Steel Foundation",type:"Large Industry", budget: 1800000, committed: 410000 },
  { id:"i3", name:"CCL CSR (Ranchi)",       type:"PSU",            budget: 900000,  committed: 180000 },
  { id:"i4", name:"Ranchi MSME Consortium", type:"MSME Cluster",   budget: 350000,  committed: 95000  },
  { id:"i5", name:"Jharkhand Startup Hub",  type:"Startup",        budget: 200000,  committed: 60000  },
];

const STATUSES = ["Submitted","Under Review","Routed to University","In Progress","Resolved"];

const SUBMITTER_TYPES = ["Individual","Community Group","Panchayati Raj Institution","Urban Local Body","Government Department"];

const LANGUAGES = [
  { code:"en", label:"English",  native:"English" },
  { code:"hi", label:"Hindi",    native:"हिन्दी" },
  { code:"sat",label:"Santhali", native:"ᱥᱟᱱᱛᱟᱲᱤ" },
];

// Seeded problems — 28 realistic reports across Jharkhand
const SEED_PROBLEMS = [
  { id:"p1",  title:"Handpump failure in Toli village for 3 weeks", description:"The single community handpump serving 42 households in Toli village (block: Bundu) has been dry since 12 August. Women walk 1.8 km to the river. Children missing morning school.", category:"Water", district:"Ranchi", lat:23.33, lng:85.33, submitter:"Community Group", status:"Routed to University", priority:"High", reportedOn:"2026-08-18", upvotes:34, photo:"handpump" },
  { id:"p2",  title:"Pothole cluster on NH-33 near Sikidiri", description:"Three major potholes on NH-33 stretch between Sikidiri and Godda have caused 4 two-wheeler accidents this monsoon. No signage, no barricades.", category:"Roads", district:"Godda", lat:24.84, lng:87.22, submitter:"Individual", status:"In Progress", priority:"Urgent", reportedOn:"2026-08-02", upvotes:89, photo:"road" },
  { id:"p3",  title:"Primary school without functional toilets since 2025", description:"GG+UPS Simaria has 184 students but both toilet blocks have been non-functional since October 2025. Girls' attendance dropped 28%.", category:"Sanitation", district:"Hazaribagh", lat:23.99, lng:85.35, submitter:"Government Department", status:"Resolved", priority:"High", reportedOn:"2026-06-14", upvotes:122, photo:"school" },
  { id:"p4",  title:"Fallow land conversion plan needed for 12 hectares in Patratu", description:"12 ha of community land near Patratu has lain fallow for 5 years. Farmers request soil testing + crop planning support for millets.", category:"Agriculture", district:"Ramgarh", lat:23.64, lng:85.28, submitter:"Panchayati Raj Institution", status:"Routed to University", priority:"Medium", reportedOn:"2026-08-21", upvotes:18, photo:"farm" },
  { id:"p5",  title:"PHC Chaibasa lacks functioning ECG machine", description:"The 30-bed PHC at Chaibasa has a donated ECG machine that has been non-functional for 8 months. Cardiac emergencies are referred 90 km to Jamshedpur.", category:"Health", district:"West Singhbhum", lat:22.54, lng:85.80, submitter:"Individual", status:"Under Review", priority:"Urgent", reportedOn:"2026-08-26", upvotes:67, photo:"hospital" },
  { id:"p6",  title:"Wheelchair-inaccessible entrance at District Hospital Gumla", description:"Only stairs lead to the OPD block. No ramp, no lift. Elderly and disabled patients are carried by relatives.", category:"Accessibility", district:"Gumla", lat:23.04, lng:84.54, submitter:"Individual", status:"Submitted", priority:"High", reportedOn:"2026-08-28", upvotes:12, photo:"hospital" },
  { id:"p7",  title:"Illegal mining debris blocking Koel river tributary", description:"Iron ore mining debris has narrowed the South Koel tributary near Bolnim. Flood risk for 3 villages upstream.", category:"Environment", district:"West Singhbhum", lat:22.48, lng:85.18, submitter:"Community Group", status:"In Progress", priority:"Urgent", reportedOn:"2026-07-11", upvotes:201, photo:"river" },
  { id:"p8",  title:"Streetlights non-functional in 4 wards of Bokaro Steel City", description:"Sectors 1, 2, 4 and 5A have had non-functional streetlights for 6 weeks. Women's safety helpline received 11 complaints.", category:"Urban Infra", district:"Bokaro", lat:23.67, lng:86.15, submitter:"Urban Local Body", status:"Routed to University", priority:"High", reportedOn:"2026-08-14", upvotes:156, photo:"street" },
  { id:"p9",  title:"Ration shop PDS portal down for 18 days in Dhanbad", description:"Aadhaar-based PDS authentication portal at 7 ration shops in BCCL Area has been offline since 10 Aug. 1,200 families unable to collect August grain.", category:"Public Service", district:"Dhanbad", lat:23.80, lng:86.44, submitter:"Community Group", status:"In Progress", priority:"Urgent", reportedOn:"2026-08-22", upvotes:287, photo:"shop" },
  { id:"p10", title:"Anganwadi in Dumka needs solar backup for mid-day meal", description:"Frequent power cuts (6-8 hrs/day) disrupt mid-day meal cooking at Anganwadi #42, Dumka. 68 children affected.", category:"Education", district:"Dumka", lat:24.27, lng:87.24, submitter:"Government Department", status:"Resolved", priority:"Medium", reportedOn:"2026Problem Statement Details
Problem Statement ID	
26043
Problem Statement Title	
A digital platform to crowdsource societal challenges and facilitate collaborative problem solving through universities and industry partnerships
Description	
Background:

Communities across Jharkhand encounter numerous local challenges related to education,healthcare, agriculture, water management, sanitation, environment, rural livelihoods,accessibility, urban infrastructure, and public service delivery. While citizens are often the first to identify these issues, there is currently no structured mechanism through which they can submit such problems for systematic evaluation and innovation-driven resolution.At the same time, Higher Education lnstitutions (HEIs) possess significant academic expertise,research capabilities, and a large pool of students capable of developing practical solutions.Industries and start-ups also have technical expertise, financial resources, and implementation capabilities that can complement academic research. However, collaboration among citizens,universities, and industry remains largely fragmented and project-specific.The National Education Policy (NEP) 2020 emphasizes experiential learning, multidisciplinary research, innovation, industry collaboration, and community engagement. Establishing a technology-enabled platform that connects societal challenges with academic institutions and industry partners can foster demand-driven innovation while enabling students and researchers to work on real-world problems that create measurable social impact.

Description:

Every year, citizens across Jharkhand identiff thousands of local issues that require innovative technological or process-based solutions. These challenges often remain unresolved due to the absence of a centralized platform that enables problem collection, categorization, expert evaluation, institutional assignment, and industry collaboration.There is a need to develop a digital platform capable of:

• Allowing citizens, community organizations, local bodies, and government agencies to submit societal challenges thiough an intuitive web and mobile interface, supported by photographs, videos, location details, and relevant documents.
• Automatically categorizing submitted problems based on thematic domains such as education, agriculture, healthcare, water resources, environment, energy, urban development, accessibility, public administration, and rural livelihoods using Al-enabled classification techniques.
• Routing validated problem statements to appropriate universities based on their academic disciplines, research expertise, innovation centres, incubation facilities, and faculty specialization.
• Enabling universities to evaluate submitted challenges, constitute multidisciplinary student and faculty teams, and prepare solution proposals or research projects.
• Facilitating collaboration between universities and industry partners, startups, MSMEs,CSR organizations, research laboratories, and innovation ecosystems for mentorship,funding, prototyping, testing and deployment of solutions.
• Providing workflow management for problem review, institutional allocation, project monitoring, stakeholder communication, milestone tracking, and solution validation.
• Generating dashboards and analytics for govemment departments to monitor the number of challenges received, domain-wise distribution, institutional participation, industry engagement, project progress, and measurable social outcomes.

The platform should support a transparent and scalable innovation ecosystem that transforms community-driven challenges into research, innovation, entrepreneurship, and deployable solutions.

Expected Solution:

A comprehensive Societal Innovation Collaboration Portal comprising the following components:

• A citizen engagement module enabling individuals, community groups, Panchayati Raj Institutions, Urban Local Bodies, and government departments to submit societal challenges with multimedia evidence, geographical location, and supporting information.
• An Al-enabled problem management module capable of automatically categorizing, prioritizing, deduplication, and routing validated challenges to appropriate universities based on subject expertise and institutional capabilities.
• A university collaboration module allowing Higher Education Institutions to review assigned challenges, form multidisciplinary project teams, assign faculty mentors, manage project workflows, and submit solution proposals.
• An industry partnership module facilitating participation by industries, startups, MSMEs,CSR organizations, research institutions, and innovation hubs for mentoring, co-development, funding, prototyping, pilot implementation, and technology transfer.
• A project lifecycle management system for monitoring milestones, deliverables, approvals, documentation, testing outcomes, intellectual property generation, and implementation status.
• A visual analytics dashboard providing real-time insights on challenge submissions, university participation, industry collaborations, thematic trends, project completion rates,innovation outcomes, patents, startups created, and community impact across districts and sectors.
• A notification and communication system enabling seamless interaction among citizens,universities, industry partners, mentors, and government departments throughout the project lifecycle.
Organization	Governmcnt of Jharkhand
Department	Department of Higher & Technical Education
Category	Software
Theme	Smart Education
Youtube Link	-05-09", upvotes:74, photo:"school" },
  { id:"p11", title:"Arsenic contamination suspected in shallow wells of Palamu", description:"3 families in Hussianabad block report hair-loss and skin lesions. Neighboring wells need testing.", category:"Water", district:"Palamu", lat:24.15, lng:84.05, submitter:"Individual", status:"Routed to University", priority:"Urgent", reportedOn:"2026-08-19", upvotes:41, photo:"water" },
  { id:"p12", title:"Solid waste dumping ground leaching into Damodar", description:"Unscientific dumping site 400m from Damodar at Topchanchi is leaching during monsoon. Downstream villages rely on this water.", category:"Sanitation", district:"Dhanbad", lat:23.88, lng:86.34, submitter:"Community Group", status:"In Progress", priority:"High", reportedOn:"2026-07-22", upvotes:178, photo:"waste" },
  { id:"p13", title:"Farmers need drone-based crop health survey for Kharif", description:"200+ paddy farmers in Chatra block request drone survey for blast disease early detection. Losses last year were 22%.", category:"Agriculture", district:"Chatra", lat:24.19, lng:84.87, submitter:"Panchayati Raj Institution", status:"Submitted", priority:"Medium", reportedOn:"2026-08-27", upvotes:29, photo:"farm" },
  { id:"p14", title:"Mobile tower gap in 7 villages of Simdega block", description:"7 villages in Simdega have zero mobile coverage. Emergency calls require traveling 6 km. ASHA workers cannot upload MCTS data.", category:"Urban Infra", district:"Simdega", lat:22.62, lng:84.49, submitter:"Government Department", status:"Under Review", priority:"High", reportedOn:"2026-08-25", upvotes:93, photo:"tower" },
  { id:"p15", title:"Tribal hostel in Khunti lacks drinking water RO", description:"Kasturba Gandhi Balika Vidyalaya in Khunti has hard TDS-620 water. 140 tribal girls report recurring stomach issues.", category:"Water", district:"Khunti", lat:23.07, lng:85.33, submitter:"Government Department", status:"Routed to University", priority:"High", reportedOn:"2026-08-10", upvotes:88, photo:"school" },
  { id:"p16", title:"Bus stop without shelter at Itki road junction", description:"200+ daily commuters (mostly women workers) wait at Itki road junction without shelter. No bench, no lighting.", category:"Accessibility", district:"Ranchi", lat:23.31, lng:85.20, submitter:"Individual", status:"Submitted", priority:"Low", reportedOn:"2026-08-28", upvotes:7, photo:"bus" },
  { id:"p17", title:"Forest fire risk mapping needed for Saranda", description:"Saranda forest (Asia's largest sal forest) had 3 fires last summer. Request predictive fire-risk model using satellite data.", category:"Environment", district:"West Singhbhum", lat:22.40, lng:85.70, submitter:"Government Department", status:"In Progress", priority:"High", reportedOn:"2026-07-04", upvotes:112, photo:"forest" },
  { id:"p18", title:"AI-based triage for PHCs with single doctor", description:"PHCs in Latehar block serve 25,000 population with 1 doctor. Request AI symptom-triage tool in Hindi.", category:"Health", district:"Latehar", lat:23.74, lng:84.20, submitter:"Government Department", status:"Routed to University", priority:"Medium", reportedOn:"2026-08-20", upvotes:56, photo:"hospital" },
  { id:"p19", title:"Open defecation returning in 3 villages of Garhwa", description:"Despite ODF status in 2019, 3 villages in Bardiha block have reverted to open defecation due to broken IHHL toilets.", category:"Sanitation", district:"Garhwa", lat:24.18, lng:83.81, submitter:"Panchayati Raj Institution", status:"Under Review", priority:"High", reportedOn:"2026-08-24", upvotes:64, photo:"village" },
  { id:"p20", title:"Smart classroom setup for 5 Eklavya Model Schools", description:"5 EMS schools in Pakur request smart classroom kits + teacher training. Current teaching is blackboard-only.", category:"Education", district:"Pakur", lat:24.63, lng:87.77, submitter:"Government Department", status:"In Progress", priority:"Medium", reportedOn:"2026-07-18", upvotes:47, photo:"school" },
  { id:"p21", title:"Flood-resilient raised platform design for Deoghar market", description:"Annual flooding damages ₹40L+ goods at Deoghar main market. Need raised modular platform design.", category:"Urban Infra", district:"Deoghar", lat:24.49, lng:86.69, submitter:"Urban Local Body", status:"Routed to University", priority:"Medium", reportedOn:"2026-08-15", upvotes:38, photo:"market" },
  { id:"p22", title:"Braille + audio ATMs needed at 12 SBI branches", description:"No SBI branch in Ranchi district has audio/Braille ATM. 3,400 visually-impaired account holders affected.", category:"Accessibility", district:"Ranchi", lat:23.36, lng:85.34, submitter:"Community Group", status:"Under Review", priority:"Medium", reportedOn:"2026-08-23", upvotes:103, photo:"bank" },
  { id:"p23", title:"Millet value-chain processing unit for tribal SHGs", description:"12 tribal SHGs in Lohardaga grow kodo-kutki but sell raw at ₹18/kg. Need mini processing unit design.", category:"Agriculture", district:"Lohardaga", lat:23.43, lng:84.67, submitter:"Community Group", status:"Routed to University", priority:"Medium", reportedOn:"2026-08-12", upvotes:52, photo:"farm" },
  { id:"p24", title:"Maternal mortality cluster investigation in Saraikela", description:"4 maternal deaths in 6 months in Saraikela block (state avg is much lower). Request epidemiological investigation.", category:"Health", district:"Saraikela-Kharsawan", lat:23.28, lng:85.98, submitter:"Government Department", status:"In Progress", priority:"Urgent", reportedOn:"2026-08-05", upvotes:144, photo:"hospital" },
  { id:"p25", title:"E-waste collection & safe disposal for Ranchi", description:"Ranchi has no formal e-waste collection. Informal dismantling exposes workers to lead/mercury.", category:"Environment", district:"Ranchi", lat:23.38, lng:85.36, submitter:"Individual", status:"Submitted", priority:"Medium", reportedOn:"2026-08-27", upvotes:22, photo:"waste" },
  { id:"p26", title:"Offline-first attendance app for MGNREGA sites", description:"MGNREGA sites in Giridih have 40% attendance failure due to no network. Need offline-first app with sync.", category:"Public Service", district:"Giridih", lat:24.18, lng:86.30, submitter:"Government Department", status:"Routed to University", priority:"High", reportedOn:"2026-08-17", upvotes:71, photo:"work" },
  { id:"p27", title:"EV charging corridor Ranchi-Jamshedpur", description:"Only 2 EV chargers on 130 km Ranchi-Jamshedpur corridor. Hinders EV adoption for commercial vehicles.", category:"Urban Infra", district:"Ranchi", lat:23.40, lng:85.50, submitter:"Individual", status:"Under Review", priority:"Low", reportedOn:"2026-08-26", upvotes:14, photo:"ev" },
  { id:"p28", title:"Tribal language learning app for Santhali children", description:"Santhali-medium children in Dumka struggle transitioning to Hindi/English in Class 3. Need bilingual learning app.", category:"Education", district:"Dumka", lat:24.30, lng:87.20, submitter:"Community Group", status:"Routed to University", priority:"Medium", reportedOn:"2026-08-08", upvotes:66, photo:"book" },
];

const SEED_PROJECTS = [
  { id:"pr1", problemId:"p3",  universityId:"u3", industryId:"i1", title:"Low-cost bio-toilet retrofit for rural schools", status:"In Progress", milestones:[
    { id:"m1", name:"Site survey & design", status:"Done", verifiedOn:"2026-07-10" },
    { id:"m2", name:"Prototype installation", status:"Done", verifiedOn:"2026-08-02" },
    { id:"m3", name:"3-month usage monitoring", status:"In Progress", dueOn:"2026-09-15" },
    { id:"m4", name:"Handover & training", status:"To Do", dueOn:"2026-10-01" },
  ], funding:{ ask:180000, pledged:180000, released:90000 }, ip:"Disclosure Drafted", team:{ faculty:"Dr. Anjali Verma", students:["Riya Kumari","Aarav Singh","Meenakshi Oraon"] }, impact:{ beneficiaries:184, costSaved:42000, timeSavedMonths:2 } },
  { id:"pr2", problemId:"p10", universityId:"u2", industryId:"i3", title:"Solar micro-grid for Anganwadi mid-day meal", status:"Resolved", milestones:[
    { id:"m1", name:"Load assessment", status:"Done", verifiedOn:"2026-06-01" },
    { id:"m2", name:"3 kVA solar install", status:"Done", verifiedOn:"2026-07-05" },
    { id:"m3", name:"Battery + inverter commissioning", status:"Done", verifiedOn:"2026-07-22" },
    { id:"m4", name:"6-month performance report", status:"Done", verifiedOn:"2026-08-10" },
  ], funding:{ ask:240000, pledged:240000, released:240000 }, ip:"Not Applicable", team:{ faculty:"Prof. S. Bhattacharya", students:["Topsi Murmu","Rohan Das","Priya Pandey"] }, impact:{ beneficiaries:68, costSaved:31000, timeSavedMonths:3 } },
  { id:"pr3", problemId:"p7",  universityId:"u7", industryId:"i2", title:"Sediment transport model for Koel tributary", status:"In Progress", milestones:[
    { id:"m1", name:"Hydrological data collection", status:"Done", verifiedOn:"2026-08-01" },
    { id:"m2", name:"HEC-RAS model calibration", status:"In Progress", dueOn:"2026-09-20" },
    { id:"m3", name:"Remediation design", status:"To Do", dueOn:"2026-10-30" },
    { id:"m4", name:"Pilot implementation", status:"To Do", dueOn:"2026-12-15" },
  ], funding:{ ask:520000, pledged:320000, released:120000 }, ip:"Filed", team:{ faculty:"Dr. K. Toppo", students:["Somra Hembram","Lakhan Munda","Anita Soren"] }, impact:{ beneficiaries:1800, costSaved:0, timeSavedMonths:0 } },
  { id:"pr4", problemId:"p2",  universityId:"u2", industryId:"i4", title:"AI pothole detection using smartphone mounts", status:"In Progress", milestones:[
    { id:"m1", name:"Dataset collection (500 km)", status:"Done", verifiedOn:"2026-08-18" },
    { id:"m2", name:"YOLO model training", status:"In Progress", dueOn:"2026-09-10" },
    { id:"m3", name:"Android app beta", status:"To Do", dueOn:"2026-10-05" },
    { id:"m4", name:"NHAI pilot handover", status:"To Do", dueOn:"2026-11-15" },
  ], funding:{ ask:380000, pledged:380000, released:140000 }, ip:"Disclosure Drafted", team:{ faculty:"Dr. R. Khanna", students:["Dev Sharma","Ishita Roy","Karan Mehta"] }, impact:{ beneficiaries:0, costSaved:0, timeSavedMonths:0 } },
  { id:"pr5", problemId:"p9",  universityId:"u1", industryId:"i5", title:"Offline-first PDS authentication sync", status:"In Progress", milestones:[
    { id:"m1", name:"Requirement & workflow mapping", status:"Done", verifiedOn:"2026-08-25" },
    { id:"m2", name:"SQLite-based offline module", status:"In Progress", dueOn:"2026-09-18" },
    { id:"m3", name:"Pilot at 2 shops", status:"To Do", dueOn:"2026-10-10" },
    { id:"m4", name:"Rollout to 7 shops", status:"To Do", dueOn:"2026-11-05" },
  ], funding:{ ask:220000, pledged:150000, released:60000 }, ip:"Not Applicable", team:{ faculty:"Dr. P. Sinha", students:["Neha Gupta","Arjun Yadav","Sunita Devi"] }, impact:{ beneficiaries:1200, costSaved:0, timeSavedMonths:0 } },
  { id:"pr6", problemId:"p12", universityId:"u3", industryId:"i1", title:"Leachate containment & bioremediation design", status:"In Progress", milestones:[
    { id:"m1", name:"Soil & water sampling", status:"Done", verifiedOn:"2026-08-05" },
    { id:"m2", name:"Lab analysis", status:"In Progress", dueOn:"2026-09-08" },
    { id:"m3", name:"Bioremediation pilot", status:"To Do", dueOn:"2026-11-01" },
    { id:"m4", name:"Final report to PCB", status:"To Do", dueOn:"2026-12-10" },
  ], funding:{ ask:640000, pledged:640000, released:200000 }, ip:"Filed", team:{ faculty:"Dr. M. Kerketta", students:["Bina Kujur","Ravi Tiwari","Salma Ansari"] }, impact:{ beneficiaries:4200, costSaved:0, timeSavedMonths:0 } },
  { id:"pr7", problemId:"p17", universityId:"u8", industryId:"i2", title:"Satellite-based forest fire risk prediction", status:"In Progress", milestones:[
    { id:"m1", name:"MODIS/VIIRS data pipeline", status:"Done", verifiedOn:"2026-07-28" },
    { id:"m2", name:"ML risk model", status:"In Progress", dueOn:"2026-09-25" },
    { id:"m3", name:"Forest dept dashboard", status:"To Do", dueOn:"2026-11-10" },
    { id:"m4", name:"Pre-fire season validation", status:"To Do", dueOn:"2027-02-15" },
  ], funding:{ ask:480000, pledged:480000, released:180000 }, ip:"Disclosure Drafted", team:{ faculty:"Dr. S. Lakra", students:["Duli Hasda","Vikas Oraon","Pooja Singh"] }, impact:{ beneficiaries:12000, costSaved:0, timeSavedMonths:0 } },
];

const SEED_NOTIFICATIONS = [
  { id:"n1", to:"citizen",    forUser:"You", text:"Your report 'Handpump failure in Toli village' was routed to Ranchi University.", time:"2h ago", unread:true },
  { id:"n2", to:"citizen",    forUser:"You", text:"12 others endorsed your report on NH-33 potholes.", time:"5h ago", unread:true },
  { id:"n3", to:"university", forUser:"BIT Mesra", text:"New problem assigned: 'Offline-first PDS authentication sync'. Response SLA: 5 days.", time:"1d ago", unread:true },
  { id:"n4", to:"university", forUser:"NIT Jamshedpur", text:"Milestone 2 verified for project 'AI pothole detection'. ₹1,40,000 released.", time:"2d ago", unread:false },
  { id:"n5", to:"industry",   forUser:"Tata Steel CSR", text:"Your ₹90,000 commitment for 'Low-cost bio-toilet' released on milestone verification.", time:"3d ago", unread:false },
  { id:"n6", to:"government", forUser:"Secretary", text:"Weekly summary: 47 new submissions, 12 routed, 3 resolved. Top district: Ranchi.", time:"6h ago", unread:true },
  { id:"n7", to:"citizen",    forUser:"You", text:"You earned the 'Community Champion' badge. +50 points.", time:"1d ago", unread:false },
];

/* ============================================================
   APP STATE CONTEXT
   ============================================================ */
const AppContext = createContext(null);

const initialState = {
  role: null, // 'citizen' | 'university' | 'industry' | 'government'
  currentUniversity: "u1",
  currentIndustry: "i1",
  view: "landing",
  viewParams: {},
  problems: SEED_PROBLEMS,
  projects: SEED_PROJECTS,
  notifications: SEED_NOTIFICATIONS,
  citizenPoints: 280,
  studentCredits: 140,
  language: "en",
};

function reducer(state, action) {
  switch (action.type) {
    case "SET_ROLE":       return { ...state, role: action.role, view: dashboardFor(action.role) };
    case "NAV":            return { ...state, view: action.view, viewParams: action.params || {} };
    case "ADD_PROBLEM":    return { ...state, problems: [action.problem, ...state.problems] };
    case "UPDATE_PROBLEM": return { ...state, problems: state.problems.map(p => p.id === action.id ? { ...p, ...action.patch } : p) };
    case "UPVOTE":         return { ...state, problems: state.problems.map(p => p.id === action.id ? { ...p, upvotes: p.upvotes + 1 } : p) };
    case "ADD_PROJECT":    return { ...state, projects: [action.project, ...state.projects] };
    case "UPDATE_PROJECT": return { ...state, projects: state.projects.map(p => p.id === action.id ? { ...p, ...action.patch } : p) };
    case "ADD_NOTIFICATION": return { ...state, notifications: [{ ...action.n, id: "n"+Date.now() }, ...state.notifications] };
    case "MARK_READ":      return { ...state, notifications: state.notifications.map(n => n.id === action.id ? { ...n, unread:false } : n) };
    case "SET_LANG":       return { ...state, language: action.lang };
    default: return state;
  };
}
function dashboardFor(role) {
  if (role === "citizen")    return "citizen-dashboard";
  if (role === "university") return "university-dashboard";
  if (role === "industry")   return "industry-dashboard";
  if (role === "government") return "gov-dashboard";
  return "landing";
}

/* ============================================================
   UTILITIES
   ============================================================ */
const catMeta = (key) => CATEGORIES.find(c => c.key === key) || CATEGORIES[9];

function simulateAI(problemText, category, district) {
  const text = (problemText || "").toLowerCase();
  const rules = [
    { kw:["water","handpump","drinking","well","tap","jal","arsenic","ro"], cat:"Water" },
    { kw:["toilet","sanitation","sewage","drainage","drain","defecation","odf","ihhl"], cat:"Sanitation" },
    { kw:["road","pothole","nh-","highway","street","bridge","nh "], cat:"Roads" },
    { kw:["farm","crop","paddy","millets","kodo","agri","irrigation","tractor"], cat:"Agriculture" },
    { kw:["school","anganwadi","classroom","teacher","student","ems","education","braille"], cat:"Education" },
    { kw:["hospital","phc","doctor","ecg","maternal","health","patient","medicine"], cat:"Health" },
    { kw:["wheelchair","ramp","accessib","disabled","blind","braille","divyang"], cat:"Accessibility" },
    { kw:["forest","fire","mining","river","waste","pollution","tree","sal "], cat:"Environment" },
    { kw:["streetlight","bus","market","flood","urban","ev ","charging","tower","mobile"], cat:"Urban Infra" },
    { kw:["ration","pds","mgnrega","portal","aadhaar","scheme","office"], cat:"Public Service" },
  ];
  let predicted = category;
  let confidence = 86;
  let matchedKw = [];
  for (const r of rules) {
    const hits = r.kw.filter(k => text.includes(k));
    if (hits.length > matchedKw.length) {
      matchedKw = hits;
      predicted = r.cat;
      confidence = Math.min(97, 72 + hits.length * 7);
    }
  }
  if (!predicted) predicted = category || "Public Service";
  const priority =
    /urgent|emergency|accident|death|child|children|pregnan|maternal|arsenic/.test(text) ? "Urgent" :
    /flood|fire|contamin|unsafe|broken|fail|non-functional/.test(text) ? "High" :
    /need|request|plan|survey/.test(text) ? "Medium" : "Low";

  const explanations = {
    "Water":         "Routed to Water & Sanitation — matches drinking-water / handpump keywords and location history of similar reports in this block.",
    "Sanitation":    "Routed to Sanitation — toilet / drainage keywords detected; similar reports in district resolved by civil engineering teams.",
    "Roads":         "Routed to Roads & Transport — pothole / highway keywords; geotag places it on a state/national highway segment.",
    "Agriculture":   "Routed to Agriculture & Rural Livelihoods — crop / farming keywords; ICAR-affiliated universities flagged as best match.",
    "Education":     "Routed to Education — school / classroom keywords; pedagogy & hardware partners engaged.",
    "Health":        "Routed to Health — clinical / facility keywords; medical-college universities prioritised.",
    "Accessibility": "Routed to Accessibility — divyangjan / infrastructure-access keywords; universal-design labs engaged.",
    "Environment":   "Routed to Environment — forest / pollution keywords; ecology research groups flagged.",
    "Urban Infra":   "Routed to Urban Infrastructure — civic-amenity keywords; smart-city mission alignment.",
    "Public Service":"Routed to Public Service Delivery — scheme / portal keywords; e-governance labs engaged.",
  };

  return {
    predicted,
    confidence,
    priority,
    matchedKw,
    explanation: explanations[predicted] || "Routed based on semantic similarity to prior resolved cases.",
  };
}

function findDuplicates(newTitle, newDesc, problems) {
  const text = (newTitle + " " + newDesc).toLowerCase();
  const tokens = text.split(/\s+/).filter(t => t.length > 4);
  return problems
    .map(p => {
      const pText = (p.title + " " + p.description).toLowerCase();
      const shared = tokens.filter(t => pText.includes(t)).length;
      const score = Math.round((shared / Math.max(tokens.length,1)) * 100);
      return { p, score };
    })
    .filter(x => x.score > 35)
    .sort((a,b) => b.score - a.score)
    .slice(0,2);
}

function fmtINR(n) {
  if (n === null || n === undefined) return "—";
  if (n >= 10000000) return "₹" + (n/10000000).toFixed(2) + " Cr";
  if (n >= 100000) return "₹" + (n/100000).toFixed(2) + " L";
  if (n >= 1000) return "₹" + (n/1000).toFixed(1) + "K";
  return "₹" + n;
}

/* ============================================================
   SHARED UI
   ============================================================ */
function Logo({ size=36 }) {
  return (
    <div className="flex items-center gap-2.5">
      <div style={{ width:size, height:size }} className="rounded-xl bg-gradient-to-br from-jhar-700 to-jhar-500 grid place-items-center shadow-sm">
        <svg viewBox="0 0 24 24" width={size*0.6} height={size*0.6} fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M3 20 L12 4 L21 20" />
          <path d="M7 14 H17" />
          <circle cx="12" cy="14" r="1.2" fill="white" />
        </svg>
      </div>
      <div className="leading-tight">
        <div className="display font-bold text-jhar-800 text-lg">Samadhan Setu</div>
        <div className="text-[10px] uppercase tracking-widest text-jhar-600 font-semibold">Solution Bridge · झारखण्ड</div>
      </div>
    </div>
  );
}

function Navbar() {
  const { state, dispatch } = useContext(AppContext);
  const unread = state.notifications.filter(n => n.to === state.role && n.unread).length;
  const roleLabel = { citizen:"Citizen", university:"University", industry:"Industry Partner", government:"Government Official" }[state.role] || "";

  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur border-b border-jhar-100">
      <div className="max-w-7xl mx-auto px-4 md:px-6 h-16 flex items-center gap-4">
        <button onClick={() => dispatch({ type:"NAV", view:"landing" })} className="shrink-0"><Logo /></button>
        <div className="flex-1" />
        {state.role && (
          <>
            <button onClick={() => dispatch({ type:"NAV", view: dashboardFor(state.role) })} className="hidden md:inline text-sm font-medium text-ink/70 hover:text-jhar-700">Dashboard</button>
            <button onClick={() => dispatch({ type:"NAV", view:"notifications" })} className="relative p-2 rounded-lg hover:bg-jhar-50">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M6 8a6 6 0 1 1 12 0c0 7 3 7 3 9H3c0-2 3-2 3-9z"/><path d="M10 21a2 2 0 0 0 4 0"/></svg>
              {unread > 0 && <span className="absolute top-1 right-1 min-w-[16px] h-4 px-1 text-[10px] font-bold bg-saffron-500 text-white rounded-full grid place-items-center">{unread}</span>}
            </button>
            <div className="hidden md:flex items-center gap-2 pl-3 border-l border-jhar-100">
              <div className="w-8 h-8 rounded-full bg-jhar-100 grid place-items-center text-jhar-700 font-bold text-sm">
                {roleLabel[0]}
              </div>
              <div className="leading-tight">
                <div className="text-xs text-ink/50">Signed in as</div>
                <div className="text-sm font-semibold text-ink">{roleLabel}</div>
              </div>
              <button onClick={() => dispatch({ type:"SET_ROLE", role:null })} className="ml-2 text-xs font-medium text-ink/60 hover:text-ink underline">Switch role</button>
            </div>
          </>
        )}
      </div>
    </header>
  );
}

function StatusStepper({ status }) {
  const idx = STATUSES.indexOf(status);
  return (
    <div className="flex items-center gap-2 w-full">
      {STATUSES.map((s, i) => (
        <React.Fragment key={s}>
          <div className="flex flex-col items-center gap-1 shrink-0">
            <div className={`w-7 h-7 rounded-full grid place-items-center text-xs font-bold border-2 ${i <= idx ? "bg-jhar-700 border-jhar-700 text-white" : "bg-white border-gray-300 text-gray-400"}`}>
              {i < idx ? "✓" : i+1}
            </div>
            <div className={`text-[10px] font-medium text-center leading-tight ${i <= idx ? "text-jhar-800" : "text-ink/40"}`}>{s}</div>
          </div>
          {i < STATUSES.length - 1 && (
            <div className={`stepper-line ${i < idx ? "active" : ""}`} />
          )}
        </React.Fragment>
      ))}
    </div>
  );
}

function PriorityBadge({ priority }) {
  const map = {
    Urgent: "bg-red-100 text-red-700 border-red-200",
    High:   "bg-saffron-100 text-saffron-600 border-saffron-200",
    Medium: "bg-blue-100 text-blue-700 border-blue-200",
    Low:    "bg-gray-100 text-gray-600 border-gray-200",
  };
  return <span className={`badge border ${map[priority]}`}>{priority === "Urgent" ? "⚠ " : ""}{priority}</span>;
}

function CategoryChip({ category }) {
  const m = catMeta(category);
  return <span className="chip"><span>{m.icon}</span>{category}</span>;
}

function StatCard({ label, value, delta, icon, tint="jhar" }) {
  return (
    <div className="bg-white rounded-2xl border border-jhar-100 p-5 card-hover">
      <div className="flex items-start justify-between">
        <div>
          <div className="text-xs uppercase tracking-wider text-ink/50 font-semibold">{label}</div>
          <div className="mt-2 text-3xl font-bold text-ink display">{value}</div>
        </div>
        <div className={`w-10 h-10 rounded-xl bg-${tint}-50 text-${tint}-600 grid place-items-center text-lg`}>{icon}</div>
      </div>
      {delta !== undefined && <div className="mt-2 text-xs font-medium text-jhar-700">▲ {delta} vs last month</div>}
    </div>
  );
}

/* ============================================================
   LANDING PAGE
   ============================================================ */
function Landing() {
  const { dispatch, state } = useContext(AppContext);
  const totalProblems = state.problems.length;
  const totalProjects = state.projects.length;
  const resolved = state.problems.filter(p => p.status === "Resolved").length;
  const patents = state.projects.filter(p => p.ip === "Filed" || p.ip === "Granted").length;
  const districts = new Set(state.problems.map(p => p.district)).size;

  return (
    <div className="min-h-screen">
      {/* Top bar */}
      <div className="bg-jhar-900 text-jhar-100 text-xs">
        <div className="max-w-7xl mx-auto px-4 md:px-6 h-9 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span>Government of Jharkhand</span>
            <span className="opacity-50">·</span>
            <span>Department of Higher & Technical Education</span>
          </div>
          <div className="hidden md:flex items-center gap-3">
            {LANGUAGES.map(l => (
              <button key={l.code} onClick={() => dispatch({ type:"SET_LANG", lang:l.code })}
                className={`px-2 py-0.5 rounded ${state.language === l.code ? "bg-white/15" : "hover:bg-white/10"}`}>
                {l.native}
              </button>
            ))}
          </div>
        </div>
      </div>

      <Navbar />

      {/* HERO */}
      <section className="gradient-hero">
        <div className="max-w-7xl mx-auto px-4 md:px-6 pt-12 pb-16 md:pt-20 md:pb-24 grid md:grid-cols-2 gap-10 items-center">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-jhar-50 border border-jhar-200 text-jhar-800 text-xs font-semibold">
              <span className="w-2 h-2 rounded-full bg-jhar-600 pulse-dot"></span>
              Smart India Hackathon 2026 · Problem Statement 26043
            </div>
            <h1 className="mt-5 display text-4xl md:text-5xl font-bold text-ink leading-tight">
              From a citizen's concern <br/>
              <span className="text-jhar-700">to a solved problem.</span>
            </h1>
            <p className="mt-5 text-ink/70 text-lg leading-relaxed max-w-xl">
              Samadhan Setu is the bridge between Jharkhand's people, its universities, and its industry — turning local challenges into measurable outcomes through collaboration, AI, and transparent public accountability.
            </p>

            {/* Three gaps */}
            <div className="mt-8 grid grid-cols-3 gap-3">
              {[
                { n:"01", t:"No structured channel", d:"Citizens had nowhere systematic to submit local problems." },
                { n:"02", t:"No matching mechanism", d:"Academic expertise was not matched to community needs." },
                { n:"03", t:"No collaboration layer", d:"Industry, universities & govt. worked in silos." },
              ].map(g => (
                <div key={g.n} className="bg-white/70 border border-jhar-100 rounded-xl p-3">
                  <div className="text-xs font-bold text-saffron-600">{g.n}</div>
                  <div className="text-sm font-semibold text-ink mt-1">{g.t}</div>
                  <div className="text-xs text-ink/60 mt-1 leading-snug">{g.d}</div>
                </div>
              ))}
            </div>

            <div className="mt-8 flex flex-wrap gap-3">
              <button onClick={() => dispatch({ type:"NAV", view:"login" })} className="px-5 py-3 rounded-xl bg-jhar-800 hover:bg-jhar-900 text-white font-semibold shadow-lg shadow-jhar-800/20">
                Get started →
              </button>
              <button onClick={() => document.getElementById("how").scrollIntoView({ behavior:"smooth" })} className="px-5 py-3 rounded-xl bg-white border border-jhar-200 hover:border-jhar-400 font-semibold text-jhar-800">
                See how it works
              </button>
            </div>
          </div>

          {/* Hero visual — stylized pipeline */}
          <div className="relative">
            <div className="bg-white rounded-3xl shadow-xl border border-jhar-100 p-6">
              <div className="text-xs font-semibold text-ink/50 uppercase tracking-wider">Live pipeline · Ranchi district</div>
              <div className="mt-4 space-y-3">
                {[
                  { icon:"📸", who:"Citizen · Sunita Devi", text:"Handpump dry for 3 weeks in Toli village", status:"Routed to University", color:"bg-jhar-100 text-jhar-800" },
                  { icon:"🤖", who:"AI Classifier", text:"Matched: water + handpump · Confidence 94%", status:"Priority: High", color:"bg-saffron-100 text-saffron-700" },
                  { icon:"🎓", who:"Ranchi University", text:"Team formed · 3 students + Dr. Verma", status:"Proposal approved", color:"bg-blue-100 text-blue-800" },
                  { icon:"🏭", who:"Tata Steel CSR", text:"₹1,80,000 committed · Milestone 2 verified", status:"Funds released", color:"bg-purple-100 text-purple-800" },
                ].map((s,i) => (
                  <div key={i} className="flex items-start gap-3 p-3 rounded-xl bg-jhar-50/50 border border-jhar-100">
                    <div className="w-10 h-10 rounded-lg bg-white grid place-items-center text-lg shadow-sm">{s.icon}</div>
                    <div className="flex-1 min-w-0">
                      <div className="text-[11px] font-semibold text-ink/50">{s.who}</div>
                      <div className="text-sm font-medium text-ink truncate">{s.text}</div>
                      <div className={`mt-1 inline-block px-2 py-0.5 rounded text-[10px] font-bold ${s.color}`}>{s.status}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="absolute -top-4 -right-4 bg-saffron-500 text-white rounded-2xl px-4 py-2 shadow-lg text-xs font-bold rotate-3">NEP 2020 aligned</div>
          </div>
        </div>

        {/* Stats strip */}
        <div className="max-w-7xl mx-auto px-4 md:px-6 pb-12">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            {[
              { v: totalProblems + "+", l:"Problems reported" },
              { v: totalProjects + "+", l:"University projects" },
              { v: patents, l:"Patents filed" },
              { v: districts, l:"Districts covered" },
              { v: resolved, l:"Resolved end-to-end" },
            ].map(s => (
              <div key={s.l} className="bg-white rounded-2xl border border-jhar-100 px-5 py-4 text-center">
                <div className="display text-2xl md:text-3xl font-bold text-jhar-800">{s.v}</div>
                <div className="text-xs text-ink/60 mt-1">{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section id="how" className="max-w-7xl mx-auto px-4 md:px-6 py-16">
        <div className="text-center max-w-2xl mx-auto">
          <div className="text-xs font-bold uppercase tracking-widest text-saffron-600">How it works</div>
          <h2 className="mt-2 display text-3xl md:text-4xl font-bold text-ink">Four steps. One transparent pipeline.</h2>
          <p className="mt-3 text-ink/60">From a photo on a phone to a measurable outcome — every stage is visible, auditable, and collaborative.</p>
        </div>

        <div className="mt-10 grid md:grid-cols-4 gap-5">
          {[
            { n:1, t:"Citizen reports", d:"Photo, voice, or text — in English, Hindi, or Santhali. Auto-geo-tagged.", icon:"📱", c:"bg-jhar-50" },
            { n:2, t:"AI classifies & routes", d:"Semantic deduplication, priority scoring, explainable routing to the right university.", icon:"🤖", c:"bg-saffron-50" },
            { n:3, t:"University + Industry solve", d:"Student teams + faculty mentor, funded milestone-by-milestone by CSR/industry.", icon:"🎓", c:"bg-blue-50" },
            { n:4, t:"Outcome measured", d:"Beneficiaries reached, cost saved, IP generated — with public certificate.", icon:"✅", c:"bg-green-50" },
          ].map(s => (
            <div key={s.n} className={`${s.c} rounded-2xl p-6 border border-jhar-100 card-hover`}>
              <div className="text-3xl">{s.icon}</div>
              <div className="mt-3 text-xs font-bold text-ink/50">STEP {s.n}</div>
              <div className="mt-1 display text-xl font-bold text-ink">{s.t}</div>
              <div className="mt-2 text-sm text-ink/70 leading-relaxed">{s.d}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ROLE CARDS */}
      <section className="bg-jhar-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 md:px-6">
          <div className="text-center max-w-2xl mx-auto">
            <div className="text-xs font-bold uppercase tracking-widest text-saffron-400">Join the bridge</div>
            <h2 className="mt-2 display text-3xl md:text-4xl font-bold">Choose your role</h2>
          </div>
          <div className="mt-10 grid md:grid-cols-3 gap-5">
            {[
              { role:"citizen",    t:"I am a Citizen",       d:"Report problems in my locality, track resolution, earn Jan Bhagidari points.", icon:"👤" },
              { role:"university", t:"I am a University",    d:"Receive routed problems, form student teams, submit proposals, build solutions.", icon:"🎓" },
              { role:"industry",   t:"I am Industry / CSR",  d:"Fund milestone-based projects, track disbursement, generate measurable impact.", icon:"🏭" },
            ].map(c => (
              <button key={c.role} onClick={() => { dispatch({ type:"SET_ROLE", role:c.role }); }}
                className="text-left bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl p-6 transition card-hover">
                <div className="text-4xl">{c.icon}</div>
                <div className="mt-4 display text-2xl font-bold">{c.t}</div>
                <div className="mt-2 text-white/70 text-sm leading-relaxed">{c.d}</div>
                <div className="mt-5 inline-flex items-center gap-1 text-saffron-400 text-sm font-semibold">Enter dashboard →</div>
              </button>
            ))}
          </div>
          <div className="mt-6 text-center">
            <button onClick={() => { dispatch({ type:"SET_ROLE", role:"government" }); }} className="text-saffron-300 hover:text-saffron-200 text-sm font-semibold underline underline-offset-4">
              Government Official login (Dept. of Higher & Technical Education) →
            </button>
          </div>
        </div>
      </section>

      {/* INCLUSIVITY */}
      <section className="max-w-7xl mx-auto px-4 md:px-6 py-16">
        <div className="grid md:grid-cols-2 gap-10 items-center">
          <div>
            <div className="text-xs font-bold uppercase tracking-widest text-saffron-600">Built for Bharat</div>
            <h2 className="mt-2 display text-3xl md:text-4xl font-bold text-ink">Every voice. Every language. Every connectivity level.</h2>
            <p className="mt-4 text-ink/70 leading-relaxed">
              Samadhan Setu is designed for the last mile — a farmer in Garhwa with a feature phone, a tribal SHG in Simdega speaking Santhali, a student in Ranchi on patchy 3G. Voice input, offline-first sync, USSD/IVR fallback, and regional-language interfaces ensure no one is left out.
            </p>
            <div className="mt-6 grid grid-cols-2 gap-3">
              {[
                { t:"Voice-first reporting", d:"Record in your language" },
                { t:"3 languages live", d:"EN · हिन्दी · ᱥᱟᱱᱛᱟᱲᱤ" },
                { t:"Offline-first PWA", d:"Works on 2G/3G" },
                { t:"USSD + IVR", d:"For feature phones" },
              ].map(f => (
                <div key={f.t} className="bg-jhar-50 border border-jhar-100 rounded-xl p-3">
                  <div className="text-sm font-semibold text-jhar-800">{f.t}</div>
                  <div className="text-xs text-ink/60 mt-0.5">{f.d}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="relative">
            <div className="bg-gradient-to-br from-jhar-700 to-jhar-900 rounded-3xl p-8 text-white">
              <div className="text-xs font-bold uppercase tracking-widest text-saffron-300">Multilingual demo</div>
              <div className="mt-4 space-y-3">
                <div className="bg-white/10 rounded-xl p-4">
                  <div className="text-xs text-white/60">English</div>
                  <div className="mt-1 font-semibold">"Handpump has been dry for 3 weeks in our village"</div>
                </div>
                <div className="bg-white/10 rounded-xl p-4">
                  <div className="text-xs text-white/60">हिन्दी</div>
                  <div className="mt-1 font-semibold devanagari">"गाँव में हैंडपंप तीन हफ़्तों से सूखा है"</div>
                </div>
                <div className="bg-white/10 rounded-xl p-4">
                  <div className="text-xs text-white/60">ᱥᱟᱱᱛᱟᱲᱤ (Santhali)</div>
                  <div className="mt-1 font-semibold">"ᱟᱹᱛᱩ ᱨᱮ ᱦᱟᱱᱰᱯᱟᱢᱯ ᱯᱮ ᱦᱟᱯᱛᱟ ᱞᱟᱜᱤᱫ ᱥᱩᱠᱷᱟ ᱟᱠᱟᱱᱟ"</div>
                </div>
              </div>
              <div className="mt-5 text-xs text-white/70">All three route to the same ticket — deduplicated by AI.</div>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-ink text-white/70 py-10">
        <div className="max-w-7xl mx-auto px-4 md:px-6 grid md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <Logo size={40} />
            <p className="mt-4 text-sm leading-relaxed max-w-md">
              A civic-tech initiative of the Government of Jharkhand, Department of Higher & Technical Education. Built as a Smart India Hackathon 2026 prototype.
            </p>
          </div>
          <div>
            <div className="text-white font-semibold text-sm mb-3">Platform</div>
            <ul className="space-y-2 text-sm">
              <li><button onClick={() => dispatch({ type:"NAV", view:"roadmap" })} className="hover:text-white">Roadmap</button></li>
              <li><a className="hover:text-white cursor-pointer">Open Data API</a></li>
              <li><a className="hover:text-white cursor-pointer">Documentation</a></li>
            </ul>
          </div>
          <div>
            <div className="text-white font-semibold text-sm mb-3">Partners</div>
            <ul className="space-y-2 text-sm">
              <li>BIT Mesra · NIT Jamshedpur</li>
              <li>Ranchi University · IIM Ranchi</li>
              <li>Tata Steel · Jindal Steel</li>
            </ul>
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-4 md:px-6 mt-8 pt-6 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-3 text-xs">
          <div>© 2026 Government of Jharkhand · Built for SIH 2026 · PS 26043</div>
          <div className="flex items-center gap-3">
            <span>RTI-compliant</span><span>·</span><span>MeitY-empanelled hosting</span><span>·</span><span>WCAG 2.1 AA</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

/* ============================================================
   LOGIN / ROLE SWITCHER
   ============================================================ */
function Login() {
  const { dispatch } = useContext(AppContext);
  return (
    <div className="min-h-[calc(100vh-64px)] grid place-items-center px-4 py-10">
      <div className="max-w-3xl w-full">
        <div className="text-center mb-8">
          <div className="text-xs font-bold uppercase tracking-widest text-saffron-600">Demo access</div>
          <h1 className="mt-2 display text-3xl font-bold text-ink">Choose your role to explore</h1>
          <p className="text-ink/60 mt-2">No real auth in this prototype — pick a role to see its tailored dashboard.</p>
        </div>
        <div className="grid md:grid-cols-2 gap-4">
          {[
            { role:"citizen",    t:"Citizen",             d:"Report problems, track status, earn points.", icon:"👤", tint:"jhar" },
            { role:"university", t:"University / Faculty",d:"Review problems, form teams, submit proposals.", icon:"🎓", tint:"blue" },
            { role:"industry",   t:"Industry / CSR",      d:"Browse fundable projects, commit funding.", icon:"🏭", tint:"saffron" },
            { role:"government", t:"Government Official", d:"State-wide analytics & oversight.", icon:"🏛️", tint:"purple" },
          ].map(r => (
            <button key={r.role} onClick={() => dispatch({ type:"SET_ROLE", role:r.role })}
              className="text-left bg-white rounded-2xl border border-jhar-100 p-6 card-hover hover:border-jhar-400">
              <div className="flex items-start justify-between">
                <div className="text-3xl">{r.icon}</div>
                <span className="text-xs font-bold text-jhar-700 bg-jhar-50 px-2 py-1 rounded">DEMO</span>
              </div>
              <div className="mt-4 display text-xl font-bold text-ink">{r.t}</div>
              <div className="mt-1 text-sm text-ink/60">{r.d}</div>
              <div className="mt-4 text-jhar-700 text-sm font-semibold">Enter →</div>
            </button>
          ))}
        </div>
        <div className="text-center mt-6">
          <button onClick={() => dispatch({ type:"NAV", view:"landing" })} className="text-sm text-ink/60 hover:text-ink underline">← Back to home</button>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   CITIZEN MODULE
   ============================================================ */
function CitizenLayout({ children, active }) {
  const { dispatch } = useContext(AppContext);
  const tabs = [
    { k:"citizen-dashboard", t:"My Reports",   icon:"📋" },
    { k:"citizen-report",    t:"Report New",   icon:"➕" },
    { k:"citizen-feed",      t:"Community Feed", icon:"🌐" },
    { k:"citizen-profile",   t:"My Profile",   icon:"🏅" },
  ];
  return (
    <div className="max-w-7xl mx-auto px-4 md:px-6 py-6">
      <div className="flex items-center gap-2 overflow-x-auto scrollbar-thin pb-2 mb-6 border-b border-jhar-100">
        {tabs.map(t => (
          <button key={t.k} onClick={() => dispatch({ type:"NAV", view:t.k })}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-sm font-semibold whitespace-nowrap transition ${active===t.k ? "bg-jhar-800 text-white" : "text-ink/70 hover:bg-jhar-50"}`}>
            <span>{t.icon}</span>{t.t}
          </button>
        ))}
      </div>
      {children}
    </div>
  );
}

function CitizenDashboard() {
  const { state } = useContext(AppContext);
  const myReports = state.problems.slice(0, 6); // simulate "mine"
  return (
    <CitizenLayout active="citizen-dashboard">
      <div className="grid md:grid-cols-4 gap-4 mb-6">
        <StatCard label="My reports" value={myReports.length} icon="📋" />
        <StatCard label="In progress" value={myReports.filter(p => ["Routed to University","In Progress"].includes(p.status)).length} icon="⚙️" tint="saffron" />
        <StatCard label="Resolved" value={myReports.filter(p => p.status === "Resolved").length} icon="✅" tint="green" />
        <StatCard label="Points earned" value={state.citizenPoints} icon="🏅" tint="saffron" />
      </div>

      <div className="bg-white rounded-2xl border border-jhar-100 overflow-hidden">
        <div className="px-5 py-4 border-b border-jhar-100 flex items-center justify-between">
          <div className="font-bold text-ink">My Reports</div>
          <div className="text-xs text-ink/50">Most recent first</div>
        </div>
        <div className="divide-y divide-jhar-50">
          {myReports.map(p => (
            <button key={p.id} onClick={() => {}} className="w-full text-left px-5 py-4 hover:bg-jhar-50/50">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-lg bg-jhar-50 grid place-items-center text-lg shrink-0">{catMeta(p.category).icon}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <div className="font-semibold text-ink truncate">{p.title}</div>
                    <PriorityBadge priority={p.priority} />
                  </div>
                  <div className="text-xs text-ink/50 mt-0.5">{p.district} · {p.reportedOn} · {p.upvotes} endorsements</div>
                  <div className="mt-3">
                    <StatusStepper status={p.status} />
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </CitizenLayout>
  );
}

function CitizenReport() {
  const { state, dispatch } = useContext(AppContext);
  const [step, setStep] = useState(1); // 1: form, 2: AI analysis, 3: success
  const [form, setForm] = useState({
    title:"", description:"", category:"", district:"Ranchi", submitter:"Individual",
    lat:23.36, lng:85.34, photo:null, language: state.language,
  });
  const [ai, setAi] = useState(null);
  const [duplicates, setDuplicates] = useState([]);
  const [recording, setRecording] = useState(false);
  const mapRef = useRef(null);
  const mapEl = useRef(null);

  useEffect(() => {
    if (step === 1 && mapEl.current && !mapRef.current) {
      mapRef.current = L.map(mapEl.current, { zoomControl:true }).setView([form.lat, form.lng], 9);
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { attribution:"© OSM" }).addTo(mapRef.current);
      const marker = L.marker([form.lat, form.lng], { draggable:true }).addTo(mapRef.current);
      marker.on("dragend", e => {
        const ll = e.target.getLatLng();
        setForm(f => ({ ...f, lat: ll.lat.toFixed(3)*1, lng: ll.lng.toFixed(3)*1 }));
      });
    }
  }, [step]);

  function runAI() {
    setStep(1.5); // loading
    setTimeout(() => {
      const result = simulateAI(form.title + " " + form.description, form.category, form.district);
      setAi(result);
      setDuplicates(findDuplicates(form.title, form.description, state.problems));
      setStep(2);
    }, 1400);
  }

  function submit() {
    const newProblem = {
      id: "p" + Date.now(),
      title: form.title, description: form.description,
      category: ai.predicted, district: form.district,
      lat: form.lat, lng: form.lng,
      submitter: form.submitter, status: "Submitted",
      priority: ai.priority, reportedOn: new Date().toISOString().slice(0,10),
      upvotes: 0, photo: "user",
    };
    dispatch({ type:"ADD_PROBLEM", problem: newProblem });
    dispatch({ type:"ADD_NOTIFICATION", n:{ to:"citizen", forUser:"You", text:`Your report "${form.title}" submitted. AI routed it to ${ai.predicted}.`, time:"just now", unread:true }});
    dispatch({ type:"ADD_NOTIFICATION", n:{ to:"government", forUser:"Secretary", text:`New submission from Ranchi: "${form.title}"`, time:"just now", unread:true }});
    setStep(3);
  }

  return (
    <CitizenLayout active="citizen-report">
      <div className="grid md:grid-cols-3 gap-6">
        {/* LEFT: form / AI / success */}
        <div className="md:col-span-2">
          <div className="bg-white rounded-2xl border border-jhar-100 p-6">
            <div className="flex items-center gap-3 mb-5">
              <div className="flex items-center gap-2">
                {[1,2,3].map(n => (
                  <div key={n} className={`w-8 h-8 rounded-full grid place-items-center text-xs font-bold ${step >= n ? "bg-jhar-700 text-white" : "bg-gray-100 text-gray-500"}`}>{n}</div>
                ))}
              </div>
              <div className="text-sm text-ink/60">
                {step === 1 && "Describe the problem"}
                {step === 1.5 && "AI is analysing…"}
                {step === 2 && "AI classification result"}
                {step === 3 && "Report submitted!"}
              </div>
            </div>

            {step === 1 && (
              <div className="space-y-4">
                {/* Language + Voice */}
                <div className="flex items-center justify-between p-3 bg-jhar-50 rounded-xl">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-jhar-800">Language:</span>
                    {LANGUAGES.map(l => (
                      <button key={l.code} onClick={() => setForm(f => ({ ...f, language:l.code }))}
                        className={`px-3 py-1 rounded-lg text-xs font-semibold ${form.language === l.code ? "bg-jhar-800 text-white" : "bg-white text-jhar-800 border border-jhar-200"}`}>
                        {l.native}
                      </button>
                    ))}
                  </div>
                  <button onClick={() => setRecording(r => !r)}
                    className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold ${recording ? "bg-red-500 text-white" : "bg-white text-jhar-800 border border-jhar-200"}`}>
                    <span className={`w-2 h-2 rounded-full ${recording ? "bg-white pulse-dot" : "bg-red-500"}`}></span>
                    {recording ? "Recording… (tap to stop)" : "🎤 Record instead of type"}
                  </button>
                </div>

                <div>
                  <label className="text-sm font-semibold text-ink">Title of the problem</label>
                  <input value={form.title} onChange={e => setForm({ ...form, title: e.target.value })}
                    placeholder="e.g. Handpump dry for 3 weeks in Toli village"
                    className="mt-1 w-full px-4 py-3 rounded-xl border border-jhar-200 focus:border-jhar-600 focus:ring-2 focus:ring-jhar-100 outline-none" />
                </div>

                <div>
                  <label className="text-sm font-semibold text-ink">Description</label>
                  <textarea value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} rows={4}
                    placeholder="Describe what you're seeing, who is affected, and since when…"
                    className="mt-1 w-full px-4 py-3 rounded-xl border border-jhar-200 focus:border-jhar-600 focus:ring-2 focus:ring-jhar-100 outline-none" />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-semibold text-ink">Category (AI will verify)</label>
                    <select value={form.category} onChange={e => setForm({ ...form, category: e.target.value })}
                      className="mt-1 w-full px-4 py-3 rounded-xl border border-jhar-200 bg-white">
                      <option value="">— Let AI decide —</option>
                      {CATEGORIES.map(c => <option key={c.key} value={c.key}>{c.icon} {c.key}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="text-sm font-semibold text-ink">District</label>
                    <select value={form.district} onChange={e => setForm({ ...form, district: e.target.value })}
                      className="mt-1 w-full px-4 py-3 rounded-xl border border-jhar-200 bg-white">
                      {DISTRICTS.map(d => <option key={d} value={d}>{d}</option>)}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-sm font-semibold text-ink">Submitted as</label>
                  <div className="mt-1 flex flex-wrap gap-2">
                    {SUBMITTER_TYPES.map(s => (
                      <button key={s} onClick={() => setForm({ ...form, submitter:s })}
                        className={`px-3 py-1.5 rounded-lg text-xs font-semibold border ${form.submitter === s ? "bg-jhar-800 text-white border-jhar-800" : "bg-white text-ink border-jhar-200"}`}>
                        {s}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-sm font-semibold text-ink">Photo / video evidence</label>
                  <div className="mt-1 border-2 border-dashed border-jhar-200 rounded-xl p-5 text-center bg-jhar-50/50">
                    <div className="text-2xl">📷</div>
                    <div className="text-sm font-semibold text-ink mt-1">Tap to upload or drag photo here</div>
                    <div className="text-xs text-ink/50 mt-1">Geo-tagged automatically · Max 20 MB</div>
                    <button className="mt-3 px-4 py-2 rounded-lg bg-jhar-800 text-white text-xs font-semibold">Choose file</button>
                  </div>
                </div>

                <div>
                  <label className="text-sm font-semibold text-ink">Location (drag pin to adjust)</label>
                  <div ref={mapEl} className="mt-1 h-64 rounded-xl border border-jhar-200 overflow-hidden"></div>
                  <div className="mt-2 text-xs text-ink/60">📍 {form.lat}, {form.lng} · Auto-detected from your device</div>
                </div>

                <button disabled={!form.title || !form.description} onClick={runAI}
                  className="w-full py-3.5 rounded-xl bg-jhar-800 hover:bg-jhar-900 disabled:bg-gray-300 text-white font-semibold">
                  Submit & let AI classify →
                </button>
              </div>
            )}

            {step === 1.5 && (
              <div className="py-10 text-center">
                <div className="inline-block w-12 h-12 rounded-full border-4 border-jhar-200 border-t-jhar-700 animate-spin"></div>
                <div className="mt-4 font-semibold text-ink">Analysing your submission…</div>
                <div className="text-sm text-ink/60 mt-1">Running semantic classification + deduplication against 2,400+ prior reports.</div>
                <div className="mt-6 max-w-md mx-auto space-y-2">
                  {["Tokenising text…","Matching 10 semantic categories…","Checking for duplicates…","Scoring priority…"].map((t,i) => (
                    <div key={i} className="flex items-center gap-3 text-left">
                      <div className="w-4 h-4 rounded-full shimmer"></div>
                      <div className="h-3 flex-1 rounded shimmer"></div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {step === 2 && ai && (
              <div className="space-y-5">
                <div className="bg-gradient-to-br from-jhar-50 to-white border border-jhar-200 rounded-2xl p-5">
                  <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-jhar-700">
                    <span className="w-2 h-2 rounded-full bg-jhar-600 pulse-dot"></span>
                    AI Classification Result
                  </div>
                  <div className="mt-4 grid md:grid-cols-3 gap-4">
                    <div>
                      <div className="text-xs text-ink/50">Predicted category</div>
                      <div className="mt-1 flex items-center gap-2">
                        <span className="text-2xl">{catMeta(ai.predicted).icon}</span>
                        <span className="display text-xl font-bold text-ink">{ai.predicted}</span>
                      </div>
                      <div className="mt-2 flex items-center gap-2">
                        <div className="flex-1 h-2 bg-jhar-100 rounded-full overflow-hidden">
                          <div className="h-full bg-jhar-700" style={{ width: ai.confidence + "%" }}></div>
                        </div>
                        <span className="text-xs font-bold text-jhar-700">{ai.confidence}%</span>
                      </div>
                    </div>
                    <div>
                      <div className="text-xs text-ink/50">Priority</div>
                      <div className="mt-2"><PriorityBadge priority={ai.priority} /></div>
                    </div>
                    <div>
                      <div className="text-xs text-ink/50">Matched keywords</div>
                      <div className="mt-2 flex flex-wrap gap-1">
                        {ai.matchedKw.slice(0,5).map(k => <span key={k} className="chip">{k}</span>)}
                        {ai.matchedKw.length === 0 && <span className="text-xs text-ink/50">Semantic match (no exact keyword)</span>}
                      </div>
                    </div>
                  </div>
                  <div className="mt-4 p-3 bg-white rounded-xl border border-jhar-100">
                    <div className="text-xs font-semibold text-ink/60">🧠 Why this classification?</div>
                    <div className="mt-1 text-sm text-ink leading-relaxed">{ai.explanation}</div>
                  </div>
                </div>

                {duplicates.length > 0 && (
                  <div className="bg-saffron-50 border border-saffron-200 rounded-2xl p-5">
                    <div className="flex items-start gap-3">
                      <div className="text-2xl">🔍</div>
                      <div className="flex-1">
                        <div className="font-semibold text-saffron-700">This looks similar to an existing report</div>
                        <div className="text-sm text-ink/70 mt-1">Before submitting, would you like to endorse an existing report instead? This strengthens the case.</div>
                        <div className="mt-3 space-y-2">
                          {duplicates.map(d => (
                            <div key={d.p.id} className="bg-white rounded-xl p-3 border border-saffron-200 flex items-center justify-between">
                              <div className="min-w-0">
                                <div className="text-sm font-semibold text-ink truncate">{d.p.title}</div>
                                <div className="text-xs text-ink/50">{d.p.district} · {d.p.upvotes} endorsements · {d.p.status}</div>
                              </div>
                              <div className="flex items-center gap-2 shrink-0">
                                <span className="text-xs font-bold text-saffron-700">{d.score}% similar</span>
                                <button className="px-3 py-1 rounded-lg bg-saffron-500 text-white text-xs font-semibold">Endorse</button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                <div className="flex gap-3">
                  <button onClick={() => setStep(1)} className="px-5 py-3 rounded-xl border border-jhar-200 font-semibold text-ink/70 hover:bg-jhar-50">← Edit</button>
                  <button onClick={submit} className="flex-1 py-3 rounded-xl bg-jhar-800 hover:bg-jhar-900 text-white font-semibold">Confirm & submit ✓</button>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="py-8 text-center">
                <div className="w-16 h-16 mx-auto rounded-full bg-jhar-100 grid place-items-center text-3xl">✅</div>
                <div className="mt-4 display text-2xl font-bold text-ink">Report submitted successfully</div>
                <div className="text-sm text-ink/60 mt-1">Reference ID: <span className="font-mono font-bold text-ink">SS-{Date.now().toString().slice(-8)}</span></div>
                <div className="mt-6 max-w-md mx-auto bg-jhar-50 rounded-xl p-4 text-left text-sm text-ink/70">
                  <div className="font-semibold text-ink mb-2">What happens next?</div>
                  <ol className="space-y-1.5 list-decimal list-inside">
                    <li>Government reviewer validates within 48 hrs.</li>
                    <li>AI routes to the best-fit university.</li>
                    <li>University forms a student team + faculty mentor.</li>
                    <li>Industry/CSR partner may commit funding.</li>
                    <li>You get notified at every milestone.</li>
                  </ol>
                </div>
                <div className="mt-6 flex gap-3 justify-center">
                  <button onClick={() => dispatch({ type:"NAV", view:"citizen-dashboard" })} className="px-5 py-2.5 rounded-xl bg-jhar-800 text-white font-semibold">View my reports</button>
                  <button onClick={() => { setStep(1); setForm({ ...form, title:"", description:"", category:"" }); }} className="px-5 py-2.5 rounded-xl border border-jhar-200 font-semibold">Report another</button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* RIGHT: helper */}
        <div className="space-y-4">
          <div className="bg-white rounded-2xl border border-jhar-100 p-5">
            <div className="text-xs font-bold uppercase tracking-wider text-saffron-600">Voice-first demo</div>
            <div className="mt-2 display text-lg font-bold text-ink">Speak in your language</div>
            <div className="mt-3 space-y-2">
              <button onClick={() => setRecording(r => !r)} className={`w-full py-3 rounded-xl font-semibold flex items-center justify-center gap-2 ${recording ? "bg-red-500 text-white" : "bg-jhar-800 text-white"}`}>
                <span className={`w-2 h-2 rounded-full ${recording ? "bg-white pulse-dot" : "bg-white"}`}></span>
                {recording ? "Recording… tap to stop" : "🎤 Start voice input"}
              </button>
              <div className="text-xs text-ink/60 leading-relaxed">
                Your voice is transcribed in real-time (Hindi, English, or Santhali) and translated to a text report.
              </div>
            </div>
          </div>
          <div className="bg-white rounded-2xl border border-jhar-100 p-5">
            <div className="text-xs font-bold uppercase tracking-wider text-jhar-700">🔊 Accessibility</div>
            <button className="mt-3 w-full py-2.5 rounded-xl bg-jhar-50 text-jhar-800 font-semibold text-sm hover:bg-jhar-100">
              🔊 Read form instructions aloud
            </button>
            <div className="text-xs text-ink/60 mt-2">Text-to-speech available in all 3 languages.</div>
          </div>
          <div className="bg-gradient-to-br from-jhar-800 to-jhar-900 text-white rounded-2xl p-5">
            <div className="text-xs font-bold uppercase tracking-wider text-saffron-300">Tip</div>
            <div className="mt-2 text-sm leading-relaxed">Photos with clear geo-tagging get routed 3× faster. Make sure location access is on.</div>
          </div>
        </div>
      </div>
    </CitizenLayout>
  );
}

function CitizenFeed() {
  const { state, dispatch } = useContext(AppContext);
  const [filter, setFilter] = useState("All");
  const filtered = filter === "All" ? state.problems : state.problems.filter(p => p.category === filter);
  return (
    <CitizenLayout active="citizen-feed">
      <div className="flex items-center gap-2 flex-wrap mb-4">
        <button onClick={() => setFilter("All")} className={`chip ${filter==="All" ? "bg-jhar-800 text-white border-jhar-800" : ""}`}>All</button>
        {CATEGORIES.map(c => (
          <button key={c.key} onClick={() => setFilter(c.key)} className={`chip ${filter===c.key ? "bg-jhar-800 text-white border-jhar-800" : ""}`}>
            <span>{c.icon}</span>{c.key}
          </button>
        ))}
      </div>
      <div className="grid md:grid-cols-2 gap-4">
        {filtered.map(p => (
          <div key={p.id} className="bg-white rounded-2xl border border-jhar-100 p-5 card-hover">
            <div className="flex items-start gap-3">
              <div className="w-12 h-12 rounded-xl grid place-items-center text-xl" style={{ background: catMeta(p.category).color + "22", color: catMeta(p.category).color }}>{catMeta(p.category).icon}</div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <CategoryChip category={p.category} />
                  <PriorityBadge priority={p.priority} />
                </div>
                <div className="mt-2 font-semibold text-ink leading-snug">{p.title}</div>
                <div className="text-xs text-ink/50 mt-1">{p.district} · {p.reportedOn} · {p.submitter}</div>
                <div className="mt-3 text-sm text-ink/70 line-clamp-2">{p.description}</div>
                <div className="mt-4 flex items-center justify-between">
                  <button onClick={() => dispatch({ type:"UPVOTE", id:p.id })} className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-jhar-50 hover:bg-jhar-100 text-jhar-800 text-sm font-semibold">
                    <span>▲</span> Endorse · {p.upvotes}
                  </button>
                  <div className="text-xs text-ink/50">{p.status}</div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </CitizenLayout>
  );
}

function CitizenProfile() {
  const { state } = useContext(AppContext);
  const badges = [
    { n:"First Report", i:"🌱", got:true },
    { n:"Community Champion", i:"🏅", got:true },
    { n:"District Hero", i:"🏆", got:true },
    { n:"Problem Solver", i:"💡", got:false },
    { n:"Voice Pioneer", i:"🎤", got:false },
    { n:"Top 100 Citizen", i:"⭐", got:false },
  ];
  const leaderboard = [
    { r:1, n:"Sunita Devi", d:"Ranchi", p:1420 },
    { r:2, n:"Ramesh Oraon", d:"West Singhbhum", p:1280 },
    { r:3, n:"Meena Kumari", d:"Hazaribagh", p:1150 },
    { r:4, n:"You", d:"Ranchi", p:state.citizenPoints, me:true },
    { r:5, n:"Arjun Singh", d:"Dhanbad", p:240 },
  ];
  return (
    <CitizenLayout active="citizen-profile">
      <div className="grid md:grid-cols-3 gap-5">
        <div className="md:col-span-1 bg-white rounded-2xl border border-jhar-100 p-6 text-center">
          <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-br from-jhar-600 to-jhar-800 grid place-items-center text-white text-3xl font-bold">SD</div>
          <div className="mt-3 display text-xl font-bold text-ink">Sunita Devi</div>
          <div className="text-xs text-ink/50">Ranchi · Member since Jan 2026</div>
          <div className="mt-4 bg-gradient-to-br from-saffron-50 to-white border border-saffron-200 rounded-xl p-4">
            <div className="text-xs font-bold uppercase tracking-wider text-saffron-600">Jan Bhagidari Points</div>
            <div className="mt-1 display text-4xl font-bold text-ink">{state.citizenPoints}</div>
            <div className="text-xs text-ink/60 mt-1">Rank #4 in Ranchi district</div>
          </div>
        </div>

        <div className="md:col-span-2 space-y-5">
          <div className="bg-white rounded-2xl border border-jhar-100 p-6">
            <div className="font-bold text-ink">Badges earned</div>
            <div className="mt-4 grid grid-cols-3 md:grid-cols-6 gap-3">
              {badges.map(b => (
                <div key={b.n} className={`text-center p-3 rounded-xl border ${b.got ? "bg-jhar-50 border-jhar-200" : "bg-gray-50 border-gray-200 opacity-50"}`}>
                  <div className="text-2xl">{b.i}</div>
                  <div className="mt-1 text-[11px] font-semibold text-ink">{b.n}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-jhar-100 p-6">
            <div className="flex items-center justify-between">
              <div className="font-bold text-ink">🏆 Leaderboard — Top contributors this month</div>
              <div className="text-xs text-ink/50">By Jan Bhagidari points</div>
            </div>
            <div className="mt-4 divide-y divide-jhar-50">
              {leaderboard.map(u => (
                <div key={u.r} className={`flex items-center gap-3 py-3 ${u.me ? "bg-saffron-50 -mx-3 px-3 rounded-lg" : ""}`}>
                  <div className={`w-8 h-8 rounded-full grid place-items-center text-xs font-bold ${u.r === 1 ? "bg-saffron-500 text-white" : u.r === 2 ? "bg-gray-400 text-white" : u.r === 3 ? "bg-amber-700 text-white" : "bg-jhar-100 text-jhar-800"}`}>{u.r}</div>
                  <div className="flex-1">
                    <div className="font-semibold text-ink">{u.n} {u.me && <span className="text-xs text-saffron-600">(you)</span>}</div>
                    <div className="text-xs text-ink/50">{u.d}</div>
                  </div>
                  <div className="font-bold text-jhar-700">{u.p}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </CitizenLayout>
  );
}

/* ============================================================
   UNIVERSITY MODULE
   ============================================================ */
function UniversityLayout({ children, active }) {
  const { dispatch, state } = useContext(AppContext);
  const uni = UNIVERSITIES.find(u => u.id === state.currentUniversity);
  const tabs = [
    { k:"university-dashboard", t:"Assigned Problems", icon:"📥" },
    { k:"university-projects",  t:"My Projects",       icon:"📊" },
    { k:"university-kanban",    t:"Kanban Board",      icon:"🗂️" },
    { k:"university-students",  t:"Students & Credits",icon:"🎓" },
  ];
  return (
    <div className="max-w-7xl mx-auto px-4 md:px-6 py-6">
      <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
        <div>
          <div className="text-xs font-bold uppercase tracking-wider text-jhar-700">University partner</div>
          <div className="display text-2xl font-bold text-ink">{uni.name}</div>
        </div>
        <select value={state.currentUniversity} onChange={e => { /* in real app would switch */ }}
          className="px-3 py-2 rounded-lg border border-jhar-200 bg-white text-sm">
          {UNIVERSITIES.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
        </select>
      </div>
      <div className="flex items-center gap-2 overflow-x-auto scrollbar-thin pb-2 mb-6 border-b border-jhar-100">
        {tabs.map(t => (
          <button key={t.k} onClick={() => dispatch({ type:"NAV", view:t.k })}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-sm font-semibold whitespace-nowrap transition ${active===t.k ? "bg-jhar-800 text-white" : "text-ink/70 hover:bg-jhar-50"}`}>
            <span>{t.icon}</span>{t.t}
          </button>
        ))}
      </div>
      {children}
    </div>
  );
}

function UniversityDashboard() {
  const { state, dispatch } = useContext(AppContext);
  const assigned = state.problems.filter(p => ["Routed to University","In Progress","Resolved"].includes(p.status));
  const [showForm, setShowForm] = useState(null);
  return (
    <UniversityLayout active="university-dashboard">
      <div className="grid md:grid-cols-4 gap-4 mb-6">
        <StatCard label="Awaiting response" value={assigned.filter(p => p.status === "Routed to University").length} icon="📥" tint="saffron" />
        <StatCard label="Active projects" value={state.projects.length} icon="⚙️" />
        <StatCard label="Students engaged" value={state.projects.reduce((a,p) => a + p.team.students.length, 0)} icon="🎓" tint="blue" />
        <StatCard label="Funding released" value={fmtINR(state.projects.reduce((a,p) => a + p.funding.released, 0))} icon="💰" tint="saffron" />
      </div>

      <div className="bg-white rounded-2xl border border-jhar-100 overflow-hidden">
        <div className="px-5 py-4 border-b border-jhar-100 flex items-center justify-between">
          <div className="font-bold text-ink">Problems routed to your university</div>
          <div className="text-xs text-ink/50">SLA: respond within 5 working days</div>
        </div>
        <div className="divide-y divide-jhar-50">
          {assigned.map(p => (
            <div key={p.id} className="p-5 hover:bg-jhar-50/50">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl grid place-items-center text-xl" style={{ background: catMeta(p.category).color + "22", color: catMeta(p.category).color }}>{catMeta(p.category).icon}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <div className="font-semibold text-ink">{p.title}</div>
                    <PriorityBadge priority={p.priority} />
                    <CategoryChip category={p.category} />
                  </div>
                  <div className="text-xs text-ink/50 mt-1">{p.district} · {p.reportedOn} · {p.upvotes} endorsements · {p.submitter}</div>
                  <div className="mt-2 text-sm text-ink/70">{p.description}</div>
                  <div className="mt-3 flex items-center gap-2 flex-wrap">
                    <StatusStepper status={p.status} />
                  </div>
                  <div className="mt-4 flex items-center gap-2">
                    <button onClick={() => setShowForm(p.id)} className="px-4 py-2 rounded-lg bg-jhar-800 text-white text-sm font-semibold">Form a team</button>
                    <button onClick={() => dispatch({ type:"NAV", view:"project-detail", params:{ id: p.id }})} className="px-4 py-2 rounded-lg border border-jhar-200 text-sm font-semibold">View details</button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {showForm && <TeamFormationModal problemId={showForm} onClose={() => setShowForm(null)} />}
    </UniversityLayout>
  );
}

function TeamFormationModal({ problemId, onClose }) {
  const { state, dispatch } = useContext(AppContext);
  const problem = state.problems.find(p => p.id === problemId);
  const [faculty, setFaculty] = useState("Dr. Anjali Verma");
  const [students, setStudents] = useState(["Riya Kumari","Aarav Singh"]);
  const [timeline, setTimeline] = useState("3 months");
  const [approach, setApproach] = useState("");
  const [expected, setExpected] = useState("");
  const [ask, setAsk] = useState(150000);

  function submit() {
    const newProject = {
      id: "pr" + Date.now(),
      problemId: problem.id,
      universityId: state.currentUniversity,
      industryId: null,
      title: "Solution for: " + problem.title,
      status: "In Progress",
      milestones: [
        { id:"m1", name:"Inception & baseline survey", status:"To Do", dueOn:"2026-09-15" },
        { id:"m2", name:"Prototype / pilot", status:"To Do", dueOn:"2026-10-20" },
        { id:"m3", name:"Field validation", status:"To Do", dueOn:"2026-11-25" },
        { id:"m4", name:"Handover & report", status:"To Do", dueOn:"2026-12-20" },
      ],
      funding:{ ask, pledged:0, released:0 },
      ip:"Not Applicable",
      team:{ faculty, students },
      impact:{ beneficiaries:0, costSaved:0, timeSavedMonths:0 },
    };
    dispatch({ type:"ADD_PROJECT", project:newProject });
    dispatch({ type:"UPDATE_PROBLEM", id:problem.id, patch:{ status:"In Progress" }});
    dispatch({ type:"ADD_NOTIFICATION", n:{ to:"university", forUser:UNIVERSITIES.find(u=>u.id===state.currentUniversity).name, text:`Team formed for "${problem.title}". Proposal submitted for funding.`, time:"just now", unread:true }});
    onClose();
  }

  return (
    <div className="fixed inset-0 z-50 bg-ink/50 backdrop-blur-sm grid place-items-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto scrollbar-thin" onClick={e => e.stopPropagation()}>
        <div className="sticky top-0 bg-white border-b border-jhar-100 px-6 py-4 flex items-center justify-between">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-jhar-700">Form a team & submit proposal</div>
            <div className="font-semibold text-ink mt-1">{problem.title}</div>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-lg hover:bg-jhar-50">✕</button>
        </div>
        <div className="p-6 space-y-4">
          <div>
            <label className="text-sm font-semibold text-ink">Faculty mentor</label>
            <select value={faculty} onChange={e => setFaculty(e.target.value)} className="mt-1 w-full px-4 py-2.5 rounded-xl border border-jhar-200 bg-white">
              {["Dr. Anjali Verma","Prof. S. Bhattacharya","Dr. K. Toppo","Dr. R. Khanna","Dr. P. Sinha","Dr. M. Kerketta"].map(f => <option key={f}>{f}</option>)}
            </select>
          </div>
          <div>
            <label className="text-sm font-semibold text-ink">Student team members</label>
            <div className="mt-1 flex flex-wrap gap-2">
              {students.map((s,i) => (
                <span key={i} className="chip">{s} <button onClick={() => setStudents(students.filter((_,j) => j!==i))} className="ml-1 text-jhar-700">×</button></span>
              ))}
              <button onClick={() => setStudents([...students, "New Student"])} className="chip bg-white border-dashed">+ Add student</button>
            </div>
          </div>
          <div>
            <label className="text-sm font-semibold text-ink">Target timeline</label>
            <select value={timeline} onChange={e => setTimeline(e.target.value)} className="mt-1 w-full px-4 py-2.5 rounded-xl border border-jhar-200 bg-white">
              {["6 weeks","3 months","6 months","9 months","12 months"].map(t => <option key={t}>{t}</option>)}
            </select>
          </div>
          <div>
            <label className="text-sm font-semibold text-ink">Proposed approach</label>
            <textarea value={approach} onChange={e => setApproach(e.target.value)} rows={3} placeholder="Brief methodology…"
              className="mt-1 w-full px-4 py-3 rounded-xl border border-jhar-200" />
          </div>
          <div>
            <label className="text-sm font-semibold text-ink">Expected outcome</label>
            <textarea value={expected} onChange={e => setExpected(e.target.value)} rows={2} placeholder="What will be delivered?"
              className="mt-1 w-full px-4 py-3 rounded-xl border border-jhar-200" />
          </div>
          <div>
            <label className="text-sm font-semibold text-ink">Funding ask (₹)</label>
            <input type="number" value={ask} onChange={e => setAsk(+e.target.value)} className="mt-1 w-full px-4 py-2.5 rounded-xl border border-jhar-200" />
          </div>
        </div>
        <div className="sticky bottom-0 bg-white border-t border-jhar-100 px-6 py-4 flex items-center justify-end gap-2">
          <button onClick={onClose} className="px-4 py-2 rounded-lg border border-jhar-200 font-semibold">Cancel</button>
          <button onClick={submit} className="px-5 py-2 rounded-lg bg-jhar-800 text-white font-semibold">Submit proposal</button>
        </div>
      </div>
    </div>
  );
}

function UniversityProjects() {
  const { state, dispatch } = useContext(AppContext);
  return (
    <UniversityLayout active="university-projects">
      <div className="grid md:grid-cols-3 gap-4">
        {state.projects.map(p => {
          const problem = state.problems.find(pr => pr.id === p.problemId);
          const progress = Math.round((p.milestones.filter(m => m.status === "Done").length / p.milestones.length) * 100);
          return (
            <div key={p.id} className="bg-white rounded-2xl border border-jhar-100 p-5 card-hover">
              <div className="flex items-center justify-between">
                <CategoryChip category={problem?.category || "Other"} />
                <PriorityBadge priority={problem?.priority || "Medium"} />
              </div>
              <div className="mt-3 font-semibold text-ink leading-snug">{p.title}</div>
              <div className="text-xs text-ink/50 mt-1">{problem?.district} · {UNIVERSITIES.find(u => u.id === p.universityId)?.short}</div>
              <div className="mt-4">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-ink/60">Progress</span>
                  <span className="font-bold text-jhar-700">{progress}%</span>
                </div>
                <div className="mt-1 h-2 bg-jhar-100 rounded-full overflow-hidden">
                  <div className="h-full bg-jhar-700" style={{ width: progress + "%" }}></div>
                </div>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-2 text-xs">
                <div className="bg-jhar-50 rounded-lg p-2">
                  <div className="text-ink/50">Funding</div>
                  <div className="font-bold text-ink">{fmtINR(p.funding.released)} / {fmtINR(p.funding.ask)}</div>
                </div>
                <div className="bg-jhar-50 rounded-lg p-2">
                  <div className="text-ink/50">IP Status</div>
                  <div className="font-bold text-ink">{p.ip}</div>
                </div>
              </div>
              <button onClick={() => dispatch({ type:"NAV", view:"project-detail", params:{ id:p.id }})}
                className="mt-4 w-full py-2 rounded-lg bg-jhar-800 text-white text-sm font-semibold">Open project →</button>
            </div>
          );
        })}
      </div>
    </UniversityLayout>
  );
}

function UniversityKanban() {
  const { state, dispatch } = useContext(AppContext);
  const cols = [
    { k:"To Do",       color:"bg-gray-100 text-gray-700" },
    { k:"In Progress", color:"bg-blue-100 text-blue-700" },
    { k:"Review",      color:"bg-saffron-100 text-saffron-700" },
    { k:"Done",        color:"bg-jhar-100 text-jhar-800" },
  ];
  // Build cards from milestones across all projects
  const cards = [];
  state.projects.forEach(p => {
    p.milestones.forEach(m => {
      const statusKey = m.status === "Done" ? "Done" : m.status === "In Progress" ? "In Progress" : "To Do";
      cards.push({ id: p.id + "-" + m.id, projectId:p.id, projectName:p.title, name:m.name, status: statusKey, dueOn:m.dueOn });
    });
  });
  return (
    <UniversityLayout active="university-kanban">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {cols.map(c => (
          <div key={c.k} className="kanban-col">
            <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-lg text-xs font-bold ${c.color}`}>
              {c.k} <span className="opacity-60">· {cards.filter(x => x.status === c.k).length}</span>
            </div>
            <div className="mt-3 space-y-3">
              {cards.filter(x => x.status === c.k).map(card => (
                <div key={card.id} className="bg-white rounded-xl border border-jhar-100 p-3 card-hover">
                  <div className="text-xs text-ink/50 truncate">{card.projectName}</div>
                  <div className="mt-1 text-sm font-semibold text-ink">{card.name}</div>
                  {card.dueOn && <div className="mt-2 text-[11px] text-ink/50">Due: {card.dueOn}</div>}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </UniversityLayout>
  );
}

function UniversityStudents() {
  const { state } = useContext(AppContext);
  const students = [];
  state.projects.forEach(p => {
    p.team.students.forEach(s => students.push({ name:s, project:p.title, credits: 20 + Math.floor(Math.random()*40) }));
  });
  return (
    <UniversityLayout active="university-students">
      <div className="bg-white rounded-2xl border border-jhar-100 overflow-hidden">
        <div className="px-5 py-4 border-b border-jhar-100 flex items-center justify-between">
          <div>
            <div className="font-bold text-ink">Students & Innovation Credits</div>
            <div className="text-xs text-ink/50 mt-0.5">Credits are exportable as shareable certificate cards.</div>
          </div>
          <button className="px-4 py-2 rounded-lg bg-jhar-800 text-white text-sm font-semibold">Export certificate</button>
        </div>
        <table className="w-full text-sm">
          <thead className="bg-jhar-50 text-ink/60 text-xs uppercase tracking-wider">
            <tr><th className="text-left px-5 py-3">Student</th><th className="text-left px-5 py-3">Project</th><th className="text-left px-5 py-3">Credits</th><th className="px-5 py-3"></th></tr>
          </thead>
          <tbody className="divide-y divide-jhar-50">
            {students.map((s,i) => (
              <tr key={i}>
                <td className="px-5 py-3 font-semibold text-ink">{s.name}</td>
                <td className="px-5 py-3 text-ink/70">{s.project}</td>
                <td className="px-5 py-3"><span className="chip bg-saffron-50 text-saffron-700 border-saffron-200">⭐ {s.credits}</span></td>
                <td className="px-5 py-3 text-right"><button className="text-xs text-jhar-700 font-semibold underline">View</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </UniversityLayout>
  );
}

/* ============================================================
   INDUSTRY MODULE
   ============================================================ */
function IndustryLayout({ children, active }) {
  const { dispatch, state } = useContext(AppContext);
  const ind = INDUSTRIES.find(i => i.id === state.currentIndustry);
  const tabs = [
    { k:"industry-dashboard",  t:"My Commitments", icon:"💼" },
    { k:"industry-marketplace",t:"Funding Marketplace", icon:"🏪" },
    { k:"industry-onboarding", t:"Partner Profile", icon:"🏢" },
  ];
  return (
    <div className="max-w-7xl mx-auto px-4 md:px-6 py-6">
      <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
        <div>
          <div className="text-xs font-bold uppercase tracking-wider text-saffron-600">Industry / CSR partner</div>
          <div className="display text-2xl font-bold text-ink">{ind.name}</div>
        </div>
        <select value={state.currentIndustry} onChange={e => dispatch({ type:"SET_ROLE", role:"industry" })}
          className="px-3 py-2 rounded-lg border border-jhar-200 bg-white text-sm">
          {INDUSTRIES.map(i => <option key={i.id} value={i.id}>{i.name}</option>)}
        </select>
      </div>
      <div className="flex items-center gap-2 overflow-x-auto scrollbar-thin pb-2 mb-6 border-b border-jhar-100">
        {tabs.map(t => (
          <button key={t.k} onClick={() => dispatch({ type:"NAV", view:t.k })}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-sm font-semibold whitespace-nowrap transition ${active===t.k ? "bg-jhar-800 text-white" : "text-ink/70 hover:bg-jhar-50"}`}>
            <span>{t.icon}</span>{t.t}
          </button>
        ))}
      </div>
      {children}
    </div>
  );
}

function IndustryDashboard() {
  const { state } = useContext(AppContext);
  const ind = INDUSTRIES.find(i => i.id === state.currentIndustry);
  const myProjects = state.projects.filter(p => p.industryId === ind.id);
  const totalPledged = myProjects.reduce((a,p) => a + p.funding.pledged, 0);
  const totalReleased = myProjects.reduce((a,p) => a + p.funding.released, 0);
  const totalBeneficiaries = myProjects.reduce((a,p) => a + (p.impact.beneficiaries || 0), 0);
  return (
    <IndustryLayout active="industry-dashboard">
      <div className="grid md:grid-cols-4 gap-4 mb-6">
        <StatCard label="CSR budget" value={fmtINR(ind.budget)} icon="💰" tint="saffron" />
        <StatCard label="Pledged" value={fmtINR(totalPledged)} icon="🤝" />
        <StatCard label="Released" value={fmtINR(totalReleased)} icon="✅" tint="green" />
        <StatCard label="Beneficiaries reached" value={totalBeneficiaries.toLocaleString("en-IN")} icon="👥" tint="blue" />
      </div>
      <div className="bg-white rounded-2xl border border-jhar-100 overflow-hidden">
        <div className="px-5 py-4 border-b border-jhar-100 font-bold text-ink">My committed projects</div>
        <div className="divide-y divide-jhar-50">
          {myProjects.map(p => {
            const problem = state.problems.find(pr => pr.id === p.problemId);
            const progress = Math.round((p.milestones.filter(m => m.status === "Done").length / p.milestones.length) * 100);
            return (
              <div key={p.id} className="p-5 hover:bg-jhar-50/50">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl grid place-items-center text-xl" style={{ background: catMeta(problem?.category).color + "22", color: catMeta(problem?.category).color }}>{catMeta(problem?.category).icon}</div>
                  <div className="flex-1">
                    <div className="font-semibold text-ink">{p.title}</div>
                    <div className="text-xs text-ink/50 mt-0.5">{UNIVERSITIES.find(u => u.id === p.universityId)?.name} · {problem?.district}</div>
                    <div className="mt-3 grid grid-cols-3 gap-3">
                      <div>
                        <div className="text-xs text-ink/50">Pledged</div>
                        <div className="font-bold text-ink">{fmtINR(p.funding.pledged)}</div>
                      </div>
                      <div>
                        <div className="text-xs text-ink/50">Released</div>
                        <div className="font-bold text-jhar-700">{fmtINR(p.funding.released)}</div>
                      </div>
                      <div>
                        <div className="text-xs text-ink/50">Progress</div>
                        <div className="font-bold text-ink">{progress}%</div>
                      </div>
                    </div>
                    <div className="mt-3 h-2 bg-jhar-100 rounded-full overflow-hidden">
                      <div className="h-full bg-jhar-700" style={{ width: progress + "%" }}></div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </IndustryLayout>
  );
}

function IndustryMarketplace() {
  const { state, dispatch } = useContext(AppContext);
  const fundable = state.projects.filter(p => p.funding.pledged < p.funding.ask);
  const [commitTo, setCommitTo] = useState(null);
  return (
    <IndustryLayout active="industry-marketplace">
      <div className="mb-4 bg-gradient-to-br from-saffron-50 to-white border border-saffron-200 rounded-2xl p-5">
        <div className="text-xs font-bold uppercase tracking-wider text-saffron-600">Funding marketplace</div>
        <div className="mt-1 display text-xl font-bold text-ink">University-approved projects seeking CSR/industry funding</div>
        <div className="text-sm text-ink/60 mt-1">All disbursements are milestone-based — funds release only on verified progress.</div>
      </div>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {fundable.map(p => {
          const problem = state.problems.find(pr => pr.id === p.problemId);
          const remaining = p.funding.ask - p.funding.pledged;
          return (
            <div key={p.id} className="bg-white rounded-2xl border border-jhar-100 p-5 card-hover">
              <div className="flex items-center justify-between">
                <CategoryChip category={problem?.category} />
                <span className="text-xs font-bold text-jhar-700">{UNIVERSITIES.find(u => u.id === p.universityId)?.short}</span>
              </div>
              <div className="mt-3 font-semibold text-ink leading-snug">{p.title}</div>
              <div className="text-xs text-ink/50 mt-1">{problem?.district} · {p.milestones.length} milestones</div>
              <div className="mt-3 text-sm text-ink/70 line-clamp-2">{problem?.description}</div>
              <div className="mt-4 grid grid-cols-2 gap-2 text-xs">
                <div className="bg-jhar-50 rounded-lg p-2">
                  <div className="text-ink/50">Total ask</div>
                  <div className="font-bold text-ink">{fmtINR(p.funding.ask)}</div>
                </div>
                <div className="bg-saffron-50 rounded-lg p-2">
                  <div className="text-ink/50">Still needed</div>
                  <div className="font-bold text-saffron-700">{fmtINR(remaining)}</div>
                </div>
              </div>
              <button onClick={() => setCommitTo(p.id)} className="mt-4 w-full py-2 rounded-lg bg-saffron-500 hover:bg-saffron-600 text-white text-sm font-semibold">Commit funding →</button>
            </div>
          );
        })}
      </div>
      {commitTo && <CommitFundingModal projectId={commitTo} onClose={() => setCommitTo(null)} />}
    </IndustryLayout>
  );
}

function CommitFundingModal({ projectId, onClose }) {
  const { state, dispatch } = useContext(AppContext);
  const project = state.projects.find(p => p.id === projectId);
  const [milestoneId, setMilestoneId] = useState(project.milestones.find(m => m.status !== "Done")?.id);
  const [amount, setAmount] = useState(100000);
  function commit() {
    const newPledged = project.funding.pledged + amount;
    dispatch({ type:"UPDATE_PROJECT", id:projectId, patch:{ funding:{ ...project.funding, pledged: Math.min(newPledged, project.funding.ask) }}});
    dispatch({ type:"ADD_NOTIFICATION", n:{ to:"industry", forUser:INDUSTRIES.find(i => i.id === state.currentIndustry).name, text:`You committed ${fmtINR(amount)} to "${project.title}" against milestone.`, time:"just now", unread:true }});
    onClose();
  }
  return (
    <div className="fixed inset-0 z-50 bg-ink/50 backdrop-blur-sm grid place-items-center p-4" onClick={onClose}>
      <div className="bg-white rounded-2xl max-w-lg w-full" onClick={e => e.stopPropagation()}>
        <div className="px-6 py-4 border-b border-jhar-100 flex items-center justify-between">
          <div className="font-bold text-ink">Commit funding</div>
          <button onClick={onClose} className="w-8 h-8 rounded-lg hover:bg-jhar-50">✕</button>
        </div>
        <div className="p-6 space-y-4">
          <div className="text-sm text-ink/70">Project: <span className="font-semibold text-ink">{project.title}</span></div>
          <div>
            <label className="text-sm font-semibold text-ink">Against milestone</label>
            <select value={milestoneId} onChange={e => setMilestoneId(e.target.value)} className="mt-1 w-full px-4 py-2.5 rounded-xl border border-jhar-200 bg-white">
              {project.milestones.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
            </select>
          </div>
          <div>
            <label className="text-sm font-semibold text-ink">Amount (₹)</label>
            <input type="number" value={amount} onChange={e => setAmount(+e.target.value)} className="mt-1 w-full px-4 py-2.5 rounded-xl border border-jhar-200" />
          </div>
          <div className="bg-jhar-50 rounded-xl p-3 text-xs text-ink/70">
            💡 Funds will be marked as <b>pledged</b> and released only when this milestone is verified by the university and government reviewer.
          </div>
        </div>
        <div className="px-6 py-4 border-t border-jhar-100 flex justify-end gap-2">
          <button onClick={onClose} className="px-4 py-2 rounded-lg border border-jhar-200 font-semibold">Cancel</button>
          <button onClick={commit} className="px-5 py-2 rounded-lg bg-saffron-500 text-white font-semibold">Commit {fmtINR(amount)}</button>
        </div>
      </div>
    </div>
  );
}

function IndustryOnboarding() {
  const { state } = useContext(AppContext);
  const ind = INDUSTRIES.find(i => i.id === state.currentIndustry);
  return (
    <IndustryLayout active="industry-onboarding">
      <div className="grid md:grid-cols-3 gap-5">
        <div className="md:col-span-1 bg-white rounded-2xl border border-jhar-100 p-6 text-center">
          <div className="w-20 h-20 mx-auto rounded-2xl bg-gradient-to-br from-saffron-500 to-saffron-600 grid place-items-center text-white text-3xl font-bold">{ind.name[0]}</div>
          <div className="mt-3 display text-xl font-bold text-ink">{ind.name}</div>
          <div className="text-xs text-ink/50 mt-0.5">{ind.type}</div>
          <div className="mt-4 bg-saffron-50 border border-saffron-200 rounded-xl p-4">
            <div className="text-xs font-bold uppercase tracking-wider text-saffron-600">Annual CSR budget on platform</div>
            <div className="mt-1 display text-3xl font-bold text-ink">{fmtINR(ind.budget)}</div>
          </div>
        </div>
        <div className="md:col-span-2 space-y-5">
          <div className="bg-white rounded-2xl border border-jhar-100 p-6">
            <div className="font-bold text-ink">Partner profile</div>
            <div className="mt-4 grid md:grid-cols-2 gap-4 text-sm">
              {[
                ["Registered name", ind.name],
                ["Type", ind.type],
                ["CIN / Regn.", "JH-2024-PLC-08" + ind.id.slice(1)],
                ["CSR mandate year", "2021"],
                ["Focus domains", "Water · Education · Agriculture"],
                ["Geography", "Jharkhand (all 24 districts)"],
              ].map(([k,v]) => (
                <div key={k}>
                  <div className="text-xs text-ink/50">{k}</div>
                  <div className="font-semibold text-ink mt-0.5">{v}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="bg-white rounded-2xl border border-jhar-100 p-6">
            <div className="font-bold text-ink">Impact summary (FY 2025–26)</div>
            <div className="mt-4 grid grid-cols-3 gap-3">
              <div className="bg-jhar-50 rounded-xl p-3 text-center">
                <div className="display text-2xl font-bold text-jhar-800">12</div>
                <div className="text-xs text-ink/60 mt-0.5">Projects funded</div>
              </div>
              <div className="bg-jhar-50 rounded-xl p-3 text-center">
                <div className="display text-2xl font-bold text-jhar-800">18,400</div>
                <div className="text-xs text-ink/60 mt-0.5">Beneficiaries</div>
              </div>
              <div className="bg-jhar-50 rounded-xl p-3 text-center">
                <div className="display text-2xl font-bold text-jhar-800">3</div>
                <div className="text-xs text-ink/60 mt-0.5">Patents supported</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </IndustryLayout>
  );
}

/* ============================================================
   PROJECT DETAIL (shared across roles)
   ============================================================ */
function ProjectDetail() {
  const { state, dispatch } = useContext(AppContext);
  const id = state.viewParams.id;
  const project = state.projects.find(p => p.id === id) || state.projects[0];
  const problem = state.problems.find(pr => pr.id === project.problemId);
  const uni = UNIVERSITIES.find(u => u.id === project.universityId);
  const ind = INDUSTRIES.find(i => i.id === project.industryId);
  const progress = Math.round((project.milestones.filter(m => m.status === "Done").length / project.milestones.length) * 100);
  const isResolved = project.status === "Resolved" || progress === 100;

  function verifyMilestone(mid) {
    const newMs = project.milestones.map(m => m.id === mid ? { ...m, status:"Done", verifiedOn: new Date().toISOString().slice(0,10) } : m);
    const newProgress = Math.round((newMs.filter(m => m.status === "Done").length / newMs.length) * 100);
    const portion = project.funding.ask / newMs.length;
    const newReleased = Math.min(project.funding.released + portion, project.funding.pledged);
    dispatch({ type:"UPDATE_PROJECT", id:project.id, patch:{ milestones:newMs, funding:{ ...project.funding, released:newReleased }, status: newProgress === 100 ? "Resolved" : "In Progress" }});
    dispatch({ type:"ADD_NOTIFICATION", n:{ to:"university", forUser:uni.name, text:`Milestone verified. ${fmtINR(portion)} released.`, time:"just now", unread:true }});
    if (ind) dispatch({ type:"ADD_NOTIFICATION", n:{ to:"industry", forUser:ind.name, text:`Milestone verified on "${project.title}". ${fmtINR(portion)} released from your pledge.`, time:"just now", unread:true }});
  }

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-6 py-6">
      <button onClick={() => dispatch({ type:"NAV", view: dashboardFor(state.role) })} className="text-sm text-ink/60 hover:text-ink mb-4">← Back to dashboard</button>

      <div className="grid md:grid-cols-3 gap-5">
        <div className="md:col-span-2 space-y-5">
          <div className="bg-white rounded-2xl border border-jhar-100 p-6">
            <div className="flex items-center gap-2 flex-wrap">
              <CategoryChip category={problem?.category} />
              <PriorityBadge priority={problem?.priority} />
              <span className="chip">{project.ip === "Filed" ? "📄 Patent filed" : project.ip === "Disclosure Drafted" ? "📝 IP disclosure drafted" : "🚫 IP N/A"}</span>
            </div>
            <h1 className="mt-3 display text-2xl md:text-3xl font-bold text-ink">{project.title}</h1>
            <div className="mt-2 text-sm text-ink/60">{problem?.district} · Reported {problem?.reportedOn} · {problem?.upvotes} endorsements</div>
            <div className="mt-4 text-ink/80 leading-relaxed">{problem?.description}</div>

            <div className="mt-5">
              <StatusStepper status={project.status === "Resolved" ? "Resolved" : "In Progress"} />
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-jhar-100 p-6">
            <div className="flex items-center justify-between">
              <div className="font-bold text-ink">Milestones</div>
              <div className="text-xs text-ink/50">{progress}% complete</div>
            </div>
            <div className="mt-4 h-2 bg-jhar-100 rounded-full overflow-hidden">
              <div className="h-full bg-jhar-700" style={{ width: progress + "%" }}></div>
            </div>
            <div className="mt-5 space-y-3">
              {project.milestones.map((m, i) => (
                <div key={m.id} className={`flex items-start gap-3 p-3 rounded-xl border ${m.status === "Done" ? "bg-jhar-50 border-jhar-200" : "bg-white border-jhar-100"}`}>
                  <div className={`w-8 h-8 rounded-full grid place-items-center text-xs font-bold shrink-0 ${m.status === "Done" ? "bg-jhar-700 text-white" : "bg-gray-100 text-gray-500"}`}>
                    {m.status === "Done" ? "✓" : i+1}
                  </div>
                  <div className="flex-1">
                    <div className="font-semibold text-ink">{m.name}</div>
                    <div className="text-xs text-ink/50 mt-0.5">
                      {m.status === "Done" ? `Verified on ${m.verifiedOn}` : m.dueOn ? `Due ${m.dueOn}` : "No due date"}
                    </div>
                  </div>
                  {m.status !== "Done" && state.role !== "citizen" && (
                    <button onClick={() => verifyMilestone(m.id)} className="px-3 py-1.5 rounded-lg bg-jhar-800 text-white text-xs font-semibold shrink-0">Verify</button>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-jhar-100 p-6">
            <div className="font-bold text-ink">Team</div>
            <div className="mt-3 grid md:grid-cols-2 gap-4">
              <div>
                <div className="text-xs text-ink/50">Faculty mentor</div>
                <div className="mt-1 font-semibold text-ink">{project.team.faculty}</div>
                <div className="text-xs text-ink/50 mt-0.5">{uni?.name}</div>
              </div>
              <div>
                <div className="text-xs text-ink/50">Student team</div>
                <div className="mt-1 flex flex-wrap gap-1">
                  {project.team.students.map(s => <span key={s} className="chip">{s}</span>)}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-5">
          <div className="bg-white rounded-2xl border border-jhar-100 p-5">
            <div className="text-xs font-bold uppercase tracking-wider text-saffron-600">Funding</div>
            <div className="mt-3 space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-ink/60">Ask</span><span className="font-bold">{fmtINR(project.funding.ask)}</span></div>
              <div className="flex justify-between"><span className="text-ink/60">Pledged</span><span className="font-bold text-jhar-700">{fmtINR(project.funding.pledged)}</span></div>
              <div className="flex justify-between"><span className="text-ink/60">Released</span><span className="font-bold text-jhar-700">{fmtINR(project.funding.released)}</span></div>
              {ind && <div className="flex justify-between"><span className="text-ink/60">Partner</span><span className="font-bold">{ind.name}</span></div>}
            </div>
          </div>

          {isResolved && <ImpactScorecard project={project} problem={problem} />}

          <div className="bg-white rounded-2xl border border-jhar-100 p-5">
            <div className="text-xs font-bold uppercase tracking-wider text-jhar-700">IP / Patent status</div>
            <div className="mt-3">
              <div className="font-semibold text-ink">{project.ip}</div>
              <div className="mt-3 flex items-center gap-2 text-xs">
                {["Not Applicable","Disclosure Drafted","Filed","Granted"].map((s,i) => (
                  <React.Fragment key={s}>
                    <div className={`w-6 h-6 rounded-full grid place-items-center text-[10px] font-bold ${["Not Applicable","Disclosure Drafted","Filed","Granted"].indexOf(project.ip) >= i ? "bg-jhar-700 text-white" : "bg-gray-100 text-gray-500"}`}>{i+1}</div>
                    {i < 3 && <div className="flex-1 h-0.5 bg-gray-200"></div>}
                  </React.Fragment>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ImpactScorecard({ project, problem }) {
  const [showCert, setShowCert] = useState(false);
  const score = (project.impact.beneficiaries * 10) + (project.impact.costSaved / 100) + (project.impact.timeSavedMonths * 50);
  return (
    <>
      <div className="bg-gradient-to-br from-jhar-700 to-jhar-900 text-white rounded-2xl p-5">
        <div className="text-xs font-bold uppercase tracking-wider text-saffron-300">🎯 Social Impact Scorecard</div>
        <div className="mt-3 grid grid-cols-3 gap-3">
          <div>
            <div className="display text-2xl font-bold">{project.impact.beneficiaries.toLocaleString("en-IN")}</div>
            <div className="text-xs text-white/70">Beneficiaries</div>
          </div>
          <div>
            <div className="display text-2xl font-bold">{fmtINR(project.impact.costSaved)}</div>
            <div className="text-xs text-white/70">Cost saved</div>
          </div>
          <div>
            <div className="display text-2xl font-bold">{project.impact.timeSavedMonths} mo</div>
            <div className="text-xs text-white/70">Faster than manual</div>
          </div>
        </div>
        <div className="mt-4 pt-4 border-t border-white/20 flex items-center justify-between">
          <div>
            <div className="text-xs text-white/70">Composite impact score</div>
            <div className="display text-3xl font-bold text-saffron-300">{Math.round(score)}</div>
          </div>
          <button onClick={() => setShowCert(true)} className="px-4 py-2 rounded-lg bg-saffron-500 hover:bg-saffron-600 text-white text-sm font-semibold">Generate certificate →</button>
        </div>
      </div>
      {showCert && (
        <div className="fixed inset-0 z-50 bg-ink/60 backdrop-blur-sm grid place-items-center p-4" onClick={() => setShowCert(false)}>
          <div className="bg-white rounded-2xl max-w-2xl w-full p-8 border-4 border-jhar-700" onClick={e => e.stopPropagation()}>
            <div className="text-center">
              <div className="text-xs font-bold uppercase tracking-widest text-saffron-600">Government of Jharkhand</div>
              <div className="display text-3xl font-bold text-jhar-800 mt-1">Certificate of Social Impact</div>
              <div className="mt-1 text-xs text-ink/60">Samadhan Setu · Problem Statement 26043</div>
              <div className="my-6 h-0.5 bg-gradient-to-r from-transparent via-jhar-300 to-transparent"></div>
              <div className="text-sm text-ink/70">This certificate is proudly presented to</div>
              <div className="display text-2xl font-bold text-ink mt-2">{project.team.students.join(", ")}</div>
              <div className="text-sm text-ink/70 mt-1">under the mentorship of <b>{project.team.faculty}</b></div>
              <div className="text-sm text-ink/70 mt-1">of <b>{UNIVERSITIES.find(u => u.id === project.universityId)?.name}</b></div>
              <div className="mt-5 text-sm text-ink/80 leading-relaxed max-w-md mx-auto">
                for successfully delivering the project <b>"{project.title}"</b>, reaching <b>{project.impact.beneficiaries.toLocaleString("en-IN")}</b> beneficiaries and saving an estimated <b>{fmtINR(project.impact.costSaved)}</b> in public cost.
              </div>
              <div className="mt-6 flex items-center justify-between text-xs text-ink/50">
                <div>
                  <div className="font-mono">SS-{project.id.toUpperCase()}</div>
                  <div>Issue date: {new Date().toISOString().slice(0,10)}</div>
                </div>
                <div className="text-right">
                  <div className="display font-bold text-jhar-800">Secretary</div>
                  <div>Dept. of Higher & Technical Education</div>
                </div>
              </div>
              <div className="mt-6 flex justify-center gap-2">
                <button className="px-5 py-2 rounded-lg bg-jhar-800 text-white font-semibold">Download PDF</button>
                <button onClick={() => setShowCert(false)} className="px-5 py-2 rounded-lg border border-jhar-200 font-semibold">Close</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

/* ============================================================
   GOVERNMENT DASHBOARD
   ============================================================ */
function GovDashboard() {
  const { state, dispatch } = useContext(AppContext);
  const [district, setDistrict] = useState("All");

  const filteredProblems = district === "All" ? state.problems : state.problems.filter(p => p.district === district);
  const total = filteredProblems.length;
  const resolved = filteredProblems.filter(p => p.status === "Resolved").length;
  const urgent = filteredProblems.filter(p => p.priority === "Urgent").length;
  const resolutionRate = total ? Math.round((resolved/total)*100) : 0;

  const byCategory = useMemo(() => {
    const m = {};
    filteredProblems.forEach(p => { m[p.category] = (m[p.category] || 0) + 1; });
    return CATEGORIES.map(c => ({ name:c.key, value: m[c.key] || 0, fill: c.color })).filter(x => x.value > 0);
  }, [filteredProblems]);

  const byDistrict = useMemo(() => {
    const m = {};
    state.problems.forEach(p => { m[p.district] = (m[p.district] || 0) + 1; });
    return Object.entries(m).map(([k,v]) => ({ name:k.length > 14 ? k.slice(0,12)+"…" : k, full:k, value:v })).sort((a,b) => b.value - a.value);
  }, [state.problems]);

  const overTime = [
    { month:"Mar", submissions:42, resolved:18 },
    { month:"Apr", submissions:58, resolved:24 },
    { month:"May", submissions:71, resolved:31 },
    { month:"Jun", submissions:89, resolved:42 },
    { month:"Jul", submissions:124, resolved:58 },
    { month:"Aug", submissions:156, resolved:71 },
  ];

  const patents = state.projects.filter(p => p.ip === "Filed" || p.ip === "Granted").length;
  const startups = 5;

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-6 py-6">
      <div className="flex items-center justify-between flex-wrap gap-3 mb-6">
        <div>
          <div className="text-xs font-bold uppercase tracking-wider text-jhar-700">Government of Jharkhand · Dept. of Higher & Technical Education</div>
          <div className="display text-2xl md:text-3xl font-bold text-ink">State-wide oversight dashboard</div>
          <div className="text-sm text-ink/60 mt-1">Real-time view of the entire citizen → university → industry pipeline.</div>
        </div>
        <div className="flex items-center gap-2">
          <select value={district} onChange={e => setDistrict(e.target.value)} className="px-3 py-2 rounded-lg border border-jhar-200 bg-white text-sm">
            <option value="All">All districts</option>
            {DISTRICTS.map(d => <option key={d} value={d}>{d}</option>)}
          </select>
          <button className="px-4 py-2 rounded-lg bg-jhar-800 text-white text-sm font-semibold">Export report</button>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
        <StatCard label="Total submissions" value={total} delta="18%" icon="📥" />
        <StatCard label="Resolution rate" value={resolutionRate + "%"} delta="4%" icon="✅" tint="green" />
        <StatCard label="Urgent open" value={urgent} icon="⚠️" tint="saffron" />
        <StatCard label="Patents filed" value={patents} icon="📄" tint="blue" />
        <StatCard label="Startups spawned" value={startups} icon="🚀" tint="saffron" />
      </div>

      <div className="grid md:grid-cols-3 gap-5 mb-6">
        <div className="md:col-span-2 bg-white rounded-2xl border border-jhar-100 p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="font-bold text-ink">Submissions vs Resolutions over time</div>
            <div className="text-xs text-ink/50">Last 6 months</div>
          </div>
          <ResponsiveContainer width="100%" height={260}>
            <AreaChart data={overTime}>
              <defs>
                <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#166534" stopOpacity={0.4}/>
                  <stop offset="100%" stopColor="#166534" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="g2" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#f59e0b" stopOpacity={0.4}/>
                  <stop offset="100%" stopColor="#f59e0b" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="month" stroke="#64748b" fontSize={12} />
              <YAxis stroke="#64748b" fontSize={12} />
              <Tooltip contentStyle={{ borderRadius:12, border:"1px solid #dceee1" }} />
              <Legend />
              <Area type="monotone" dataKey="submissions" stroke="#166534" fill="url(#g1)" strokeWidth={2} />
              <Area type="monotone" dataKey="resolved" stroke="#f59e0b" fill="url(#g2)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-2xl border border-jhar-100 p-5">
          <div className="font-bold text-ink mb-3">By domain</div>
          <ResponsiveContainer width="100%" height={260}>
            <PieChart>
              <Pie data={byCategory} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={50} outerRadius={90} paddingAngle={2}>
                {byCategory.map((e,i) => <Cell key={i} fill={e.fill} />)}
              </Pie>
              <Tooltip contentStyle={{ borderRadius:12, border:"1px solid #dceee1" }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="mt-2 flex flex-wrap gap-1.5">
            {byCategory.slice(0,6).map(c => (
              <span key={c.name} className="chip" style={{ background: c.fill + "22", color: c.fill, borderColor: c.fill + "44" }}>
                {c.name} · {c.value}
              </span>
            ))}
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-5 mb-6">
        <div className="md:col-span-2 bg-white rounded-2xl border border-jhar-100 p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="font-bold text-ink">Submissions by district</div>
            <div className="text-xs text-ink/50">Top 10 districts</div>
          </div>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={byDistrict.slice(0,10)} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis type="number" stroke="#64748b" fontSize={12} />
              <YAxis dataKey="name" type="category" stroke="#64748b" fontSize={11} width={110} />
              <Tooltip contentStyle={{ borderRadius:12, border:"1px solid #dceee1" }} />
              <Bar dataKey="value" fill="#166534" radius={[0,6,6,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-2xl border border-jhar-100 p-5">
          <div className="font-bold text-ink mb-3">🗺️ GIS Heatmap — Jharkhand</div>
          <GISMap problems={filteredProblems} />
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-jhar-100 p-5">
        <div className="flex items-center justify-between mb-3">
          <div className="font-bold text-ink">Recent activity across the state</div>
          <button onClick={() => dispatch({ type:"NAV", view:"notifications" })} className="text-xs text-jhar-700 font-semibold underline">View all →</button>
        </div>
        <div className="divide-y divide-jhar-50">
          {state.notifications.slice(0,6).map(n => (
            <div key={n.id} className="py-3 flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-jhar-50 grid place-items-center text-sm">
                {n.to === "citizen" ? "👤" : n.to === "university" ? "🎓" : n.to === "industry" ? "🏭" : "🏛️"}
              </div>
              <div className="flex-1">
                <div className="text-sm text-ink">{n.text}</div>
                <div className="text-xs text-ink/50 mt-0.5">{n.forUser} · {n.time}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   GIS MAP
   ============================================================ */
function GISMap({ problems }) {
  const mapEl = useRef(null);
  const mapRef = useRef(null);
  useEffect(() => {
    if (!mapEl.current) return;
    if (mapRef.current) { mapRef.current.remove(); mapRef.current = null; }
    const map = L.map(mapEl.current, { zoomControl:true, scrollWheelZoom:false }).setView([23.6, 85.3], 7);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { attribution:"© OSM" }).addTo(map);

    // Heatmap-like: use circle markers sized by upvotes
    problems.forEach(p => {
      const r = Math.max(6, Math.min(22, 4 + Math.sqrt(p.upvotes) * 1.2));
      const color = catMeta(p.category).color;
      L.circleMarker([p.lat, p.lng], { radius:r, color, fillColor:color, fillOpacity:0.55, weight:1 }).addTo(map)
        .bindPopup(`<b>${p.title}</b><br/>${p.district}<br/>${p.category} · ${p.upvotes} endorsements`);
    });

    // Predicted hotspot overlays
    const hotspots = [
      { lat:23.33, lng:85.33, label:"Predicted hotspot · Water scarcity · High risk Apr–Jun", color:"#ef4444" },
      { lat:24.18, lng:86.30, label:"Predicted hotspot · PDS sync failure · Recurring", color:"#f59e0b" },
      { lat:22.40, lng:85.70, label:"Predicted hotspot · Forest fire · Saranda", color:"#ef4444" },
    ];
    hotspots.forEach(h => {
      L.circle([h.lat, h.lng], { radius: 25000, color:h.color, fillColor:h.color, fillOpacity:0.12, weight:2, dashArray:"4 6" }).addTo(map)
        .bindPopup(`<b>🔮 ${h.label}</b>`);
    });

    mapRef.current = map;
    setTimeout(() => map.invalidateSize(), 100);
    return () => { if (mapRef.current) { mapRef.current.remove(); mapRef.current = null; } };
  }, [problems]);
  return <div ref={mapEl} className="h-72 rounded-xl border border-jhar-200 overflow-hidden"></div>;
}

/* ============================================================
   NOTIFICATIONS
   ============================================================ */
function Notifications() {
  const { state, dispatch } = useContext(AppContext);
  const mine = state.notifications.filter(n => n.to === state.role);
  return (
    <div className="max-w-4xl mx-auto px-4 md:px-6 py-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <div className="text-xs font-bold uppercase tracking-wider text-jhar-700">Inbox</div>
          <div className="display text-2xl font-bold text-ink">Notifications</div>
        </div>
        <button className="text-sm text-jhar-700 font-semibold underline">Mark all as read</button>
      </div>
      <div className="bg-white rounded-2xl border border-jhar-100 overflow-hidden">
        <div className="divide-y divide-jhar-50">
          {mine.map(n => (
            <div key={n.id} className={`p-4 flex items-start gap-3 ${n.unread ? "bg-saffron-50/40" : ""}`}>
              <div className="w-10 h-10 rounded-lg bg-jhar-50 grid place-items-center text-lg shrink-0">
                {n.to === "citizen" ? "👤" : n.to === "university" ? "🎓" : n.to === "industry" ? "🏭" : "🏛️"}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm text-ink">{n.text}</div>
                <div className="text-xs text-ink/50 mt-1">{n.forUser} · {n.time}</div>
              </div>
              {n.unread && <div className="w-2 h-2 rounded-full bg-saffron-500 mt-2"></div>}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   ROADMAP
   ============================================================ */
function Roadmap() {
  const { dispatch } = useContext(AppContext);
  const items = [
    { i:"⛓️",  t:"Blockchain-backed audit trail", d:"Immutable record of every action, fund release, and verification." },
    { i:"🧬",  t:"Digital twin / simulation sandbox", d:"Simulate infrastructure fixes before deploying." },
    { i:"🧠",  t:"Explainable-AI transparency reports", d:"Public audit of every AI routing decision." },
    { i:"🎓",  t:"Faculty expertise graph & smart matchmaking", d:"Auto-match problems to the most relevant researchers." },
    { i:"📜",  t:"IP & patent facilitation pipeline", d:"End-to-end support from disclosure to grant." },
    { i:"📊",  t:"Open data API for researchers", d:"Anonymised datasets for academic study." },
    { i:"📞",  t:"SMS / USSD / IVR access", d:"Feature-phone access for the last mile." },
    { i:"📴",  t:"Offline-first sync", d:"Work without internet, sync when back online." },
    { i:"⏱️",  t:"SLA-based notification escalation", d:"Auto-escalate overdue items to higher authorities." },
    { i:"🔗",  t:"Govt. scheme auto-linkage", d:"Link problems to Jal Jeevan, PMAY, MGNREGA automatically." },
    { i:"⚖️",  t:"Predictive university workload balancing", d:"Distribute problems based on institutional capacity." },
    { i:"👥",  t:"Peer-review quality assurance", d:"Academic peer review for submitted solutions." },
    { i:"⭐",  t:"Trust & reputation ratings", d:"Rate institutions and industry partners." },
    { i:"🆔",  t:"Verified digital identity", d:"DigiLocker / Aadhaar SSO integration." },
    { i:"🎥",  t:"Virtual demo-day marketplace", d:"Live-stream project demo days to investors." },
    { i:"🧩",  t:"No-code workflow rule builder", d:"Admins build routing rules without code." },
    { i:"🤝",  t:"Cross-institutional collaboration", d:"Multi-university teams on big problems." },
    { i:"🏁",  t:"Year-round themed innovation sprints", d:"Monsoon, harvest, exam-season sprints." },
    { i:"📑",  t:"Auto-generated govt. reports", d:"PDF/PPT reports for secretaries & MLAs." },
  ];
  return (
    <div className="max-w-7xl mx-auto px-4 md:px-6 py-10">
      <button onClick={() => dispatch({ type:"NAV", view:"landing" })} className="text-sm text-ink/60 hover:text-ink mb-4">← Back to home</button>
      <div className="text-center max-w-2xl mx-auto">
        <div className="text-xs font-bold uppercase tracking-widest text-saffron-600">Platform roadmap</div>
        <h1 className="mt-2 display text-3xl md:text-4xl font-bold text-ink">What's coming next</h1>
        <p className="mt-3 text-ink/60">Samadhan Setu is a living platform. These are the next capabilities we're building — each designed to deepen trust, expand access, and multiply impact.</p>
      </div>
      <div className="mt-10 grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {items.map(x => (
          <div key={x.t} className="bg-white rounded-2xl border border-jhar-100 p-5 card-hover relative">
            <span className="absolute top-3 right-3 badge bg-saffron-50 text-saffron-700 border border-saffron-200">Coming soon</span>
            <div className="text-3xl">{x.i}</div>
            <div className="mt-3 font-semibold text-ink">{x.t}</div>
            <div className="mt-1 text-sm text-ink/60 leading-relaxed">{x.d}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ============================================================
   APP ROOT
   ============================================================ */
function App() {
  const [state, dispatch] = React.useReducer(reducer, initialState);

  const view = state.view;
  let body;
  if (view === "landing") body = <Landing />;
  else if (view === "login") body = <><Navbar /><Login /></>;
  else if (view === "citizen-dashboard") body = <><Navbar /><CitizenDashboard /></>;
  else if (view === "citizen-report") body = <><Navbar /><CitizenReport /></>;
  else if (view === "citizen-feed") body = <><Navbar /><CitizenFeed /></>;
  else if (view === "citizen-profile") body = <><Navbar /><CitizenProfile /></>;
  else if (view === "university-dashboard") body = <><Navbar /><UniversityDashboard /></>;
  else if (view === "university-projects") body = <><Navbar /><UniversityProjects /></>;
  else if (view === "university-kanban") body = <><Navbar /><UniversityKanban /></>;
  else if (view === "university-students") body = <><Navbar /><UniversityStudents /></>;
  else if (view === "industry-dashboard") body = <><Navbar /><IndustryDashboard /></>;
  else if (view === "industry-marketplace") body = <><Navbar /><IndustryMarketplace /></>;
  else if (view === "industry-onboarding") body = <><Navbar /><IndustryOnboarding /></>;
  else if (view === "gov-dashboard") body = <><Navbar /><GovDashboard /></>;
  else if (view === "project-detail") body = <><Navbar /><ProjectDetail /></>;
  else if (view === "notifications") body = <><Navbar /><Notifications /></>;
  else if (view === "roadmap") body = <><Navbar /><Roadmap /></>;
  else body = <><Navbar /><Landing /></>;

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      <div className="min-h-screen">{body}</div>
    </AppContext.Provider>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
